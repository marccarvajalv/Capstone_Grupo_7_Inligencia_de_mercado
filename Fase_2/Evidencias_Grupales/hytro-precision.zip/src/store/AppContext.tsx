import {
  createContext,
  useCallback,
  useContext,
  useEffect,
  useMemo,
  useRef,
  useState,
  type ReactNode,
} from 'react'
import {
  createUserWithEmailAndPassword,
  onAuthStateChanged,
  signInWithEmailAndPassword,
  signInWithPopup,
  signOut,
  updateProfile,
  type User,
} from 'firebase/auth'
import { EXERCISES } from '../data/exercises'
import {
  apiDeleteAccount,
  apiLogin,
  apiLogout,
  apiMe,
  apiSignup,
  getApiToken,
  hydrateApiTokens,
  isApiBackendConfigured,
  setApiToken,
  setRefreshToken,
} from '../lib/apiClient'
import { backendModeLabel, isCloudSyncEnabled } from '../lib/backendMode'
import { getFirebaseAuth, googleProvider, isFirebaseConfigured } from '../lib/firebase'
import { enqueueStateMutation, flushSyncQueue, pullCloudState, ensureUserDoc } from '../lib/firestoreSync'
import { migrateLocalToCloudIfNeeded } from '../lib/migrateLocal'
import { canEnqueueNotification } from '../lib/notificationsPolicy'
import { clearQueue } from '../lib/syncQueue'
import {
  clearAllData,
  createEmptyState,
  ensureExerciseCache,
  isTrainingBlocked,
  loadState,
  saveState,
} from '../lib/storage'
import { todayIso, uid } from '../lib/utils'
import type {
  AppState,
  ConnectedDevice,
  CuffCheck,
  EquipmentInventory,
  LocalUser,
  MedicalScreening,
  PhysicalProfile,
  TrainingGoal,
  UserPreferences,
  WearableProvider,
  WorkoutSession,
} from '../types'

type AuthMode = 'demo' | 'firebase'

interface AppContextValue {
  state: AppState
  blocked: boolean
  authReady: boolean
  authMode: AuthMode
  firebaseEnabled: boolean
  syncOnline: boolean
  lastSyncMessage: string
  firebaseModeLabel: string
  startLocalAccount: (displayName: string, email: string) => void
  signUpEmail: (email: string, password: string, displayName: string) => Promise<void>
  signInEmail: (email: string, password: string) => Promise<void>
  signInGoogle: () => Promise<void>
  signOutUser: () => Promise<void>
  setOnboardingStep: (step: number) => void
  completeOnboarding: () => void
  saveProfile: (profile: PhysicalProfile) => void
  submitScreening: (
    answers: Omit<MedicalScreening, 'id' | 'medicalClearance' | 'submittedAt'>,
  ) => MedicalScreening
  saveGoal: (goal: Omit<TrainingGoal, 'id' | 'isActive' | 'createdAt'>) => void
  saveEquipment: (inventory: Omit<EquipmentInventory, 'updatedAt'>) => void
  toggleDevice: (provider: WearableProvider) => void
  addCuffCheck: (check: Omit<CuffCheck, 'id' | 'createdAt'>) => CuffCheck
  addSession: (session: Omit<WorkoutSession, 'id' | 'createdAt'>) => void
  selectExercise: (id: string | null) => void
  startProteinWindow: (seconds: number) => void
  clearProteinWindow: () => void
  updatePreferences: (prefs: Partial<UserPreferences>) => void
  markNotificationRead: (id: string) => void
  markAllNotificationsRead: () => void
  deleteAccount: (confirmation: string) => Promise<boolean>
  resetDemo: () => void
}

const AppContext = createContext<AppContextValue | null>(null)

export function AppProvider({ children }: { children: ReactNode }) {
  const [state, setState] = useState<AppState>(() => {
    ensureExerciseCache()
    return loadState()
  })
  const [authReady, setAuthReady] = useState(!isCloudSyncEnabled())
  const [authMode, setAuthMode] = useState<AuthMode>(() =>
    isCloudSyncEnabled() ? 'firebase' : 'demo',
  )
  const [syncOnline, setSyncOnline] = useState(
    typeof navigator !== 'undefined' ? navigator.onLine : true,
  )
  const [lastSyncMessage, setLastSyncMessage] = useState('')
  const authUidRef = useRef<string | null>(null)
  const hydratingRef = useRef(false)

  useEffect(() => {
    saveState(state)
  }, [state])

  const tryFlush = useCallback(async (uidValue: string) => {
    if (!isCloudSyncEnabled() || !navigator.onLine) return
    const result = await flushSyncQueue(uidValue)
    if (result.flushed || result.failed) {
      setLastSyncMessage(
        `Sync: ${result.flushed} ok` + (result.failed ? `, ${result.failed} pendientes` : ''),
      )
    }
  }, [])

  const hydrateFromAuth = useCallback(
    async (fbUser: User) => {
      if (hydratingRef.current) return
      hydratingRef.current = true
      authUidRef.current = fbUser.uid
      setAuthMode('firebase')
      try {
        await ensureUserDoc(fbUser.uid, {
          email: fbUser.email ?? '',
          displayName: fbUser.displayName || fbUser.email?.split('@')[0] || 'Atleta',
        })

        const local = loadState()
        const mig = await migrateLocalToCloudIfNeeded(fbUser.uid, local)
        if (mig.migrated) {
          setLastSyncMessage('Datos locales migrados a la nube')
        }

        const cloud = await pullCloudState(fbUser.uid)
        if (cloud?.user) {
          setState((s) => ({
            ...createEmptyState(),
            ...cloud,
            selectedExerciseId: s.selectedExerciseId,
          }))
        } else {
          setState((s) => ({
            ...s,
            user: {
              id: fbUser.uid,
              email: fbUser.email ?? '',
              displayName: fbUser.displayName || 'Atleta',
              onboardingComplete: s.user?.onboardingComplete ?? false,
              onboardingStep: s.user?.onboardingStep ?? 0,
              createdAt: s.user?.createdAt ?? todayIso(),
            },
          }))
        }
        await tryFlush(fbUser.uid)
      } catch (e) {
        setLastSyncMessage(
          `Auth OK; sync limitado: ${e instanceof Error ? e.message : 'error'}`,
        )
        setState((s) => ({
          ...s,
          user: {
            id: fbUser.uid,
            email: fbUser.email ?? s.user?.email ?? '',
            displayName: fbUser.displayName || s.user?.displayName || 'Atleta',
            onboardingComplete: s.user?.onboardingComplete ?? false,
            onboardingStep: s.user?.onboardingStep ?? 0,
            createdAt: s.user?.createdAt ?? todayIso(),
          },
        }))
      } finally {
        hydratingRef.current = false
        setAuthReady(true)
      }
    },
    [tryFlush],
  )

  const hydrateFromApiUser = useCallback(
    async (apiUser: LocalUser) => {
      if (hydratingRef.current) {
        // Avoid deadlock: a concurrent hydrate must not leave Splash stuck on loading.
        setAuthReady(true)
        return
      }
      hydratingRef.current = true
      authUidRef.current = apiUser.id
      setAuthMode('firebase')
      try {
        const local = loadState()
        const mig = await migrateLocalToCloudIfNeeded(apiUser.id, local)
        if (mig.migrated) setLastSyncMessage('Datos locales migrados a la API')
        const cloud = await pullCloudState(apiUser.id)
        const base = createEmptyState()
        if (cloud?.user) {
          setState((s) => ({
            ...base,
            ...cloud,
            user: cloud.user ?? apiUser,
            equipment: cloud.equipment ?? base.equipment,
            devices: cloud.devices?.length ? cloud.devices : base.devices,
            medicalHistory: cloud.medicalHistory ?? [],
            goalHistory: cloud.goalHistory ?? [],
            sessions: cloud.sessions ?? [],
            cuffChecks: cloud.cuffChecks ?? [],
            notifications: cloud.notifications?.length
              ? cloud.notifications
              : base.notifications,
            preferences: { ...base.preferences, ...cloud.preferences },
            selectedExerciseId: s.selectedExerciseId,
          }))
        } else {
          setState((s) => ({
            ...s,
            user: {
              id: apiUser.id,
              email: apiUser.email,
              displayName: apiUser.displayName || 'Atleta',
              onboardingComplete: s.user?.onboardingComplete ?? apiUser.onboardingComplete,
              onboardingStep: s.user?.onboardingStep ?? apiUser.onboardingStep,
              createdAt: s.user?.createdAt ?? apiUser.createdAt,
            },
            equipment: s.equipment ?? base.equipment,
          }))
        }
        await tryFlush(apiUser.id)
      } catch (e) {
        setLastSyncMessage(
          `Auth OK; sync limitado: ${e instanceof Error ? e.message : 'error'}`,
        )
        setState((s) => ({
          ...s,
          user: apiUser,
          equipment: s.equipment ?? createEmptyState().equipment,
        }))
      } finally {
        hydratingRef.current = false
        setAuthReady(true)
      }
    },
    [tryFlush],
  )

  useEffect(() => {
    if (isApiBackendConfigured()) {
      let cancelled = false
      void (async () => {
        await hydrateApiTokens()
        if (cancelled) return
        const token = getApiToken()
        if (!token) {
          setAuthReady(true)
          return
        }
        try {
          const res = await apiMe()
          if (!cancelled) await hydrateFromApiUser(res.user)
        } catch {
          if (cancelled) return
          setApiToken(null)
          setAuthReady(true)
        } finally {
          if (!cancelled) window.setTimeout(() => setAuthReady(true), 0)
        }
      })()
      const failSafe = window.setTimeout(() => {
        if (!cancelled) setAuthReady(true)
      }, 15_000)
      return () => {
        cancelled = true
        window.clearTimeout(failSafe)
      }
    }

    if (!isFirebaseConfigured()) {
      setAuthReady(true)
      return
    }
    const auth = getFirebaseAuth()
    if (!auth) {
      setAuthReady(true)
      return
    }
    const unsub = onAuthStateChanged(auth, (user) => {
      if (user) {
        void hydrateFromAuth(user)
      } else {
        authUidRef.current = null
        setAuthReady(true)
        setState((s) => {
          if (s.user && authMode === 'demo') return s
          if (s.user?.id && !s.user.id.startsWith('user_')) {
            return createEmptyState()
          }
          return s
        })
      }
    })
    return () => unsub()
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [hydrateFromAuth, hydrateFromApiUser])

  useEffect(() => {
    const on = () => {
      setSyncOnline(true)
      if (authUidRef.current) void tryFlush(authUidRef.current)
    }
    const off = () => setSyncOnline(false)
    window.addEventListener('online', on)
    window.addEventListener('offline', off)
    return () => {
      window.removeEventListener('online', on)
      window.removeEventListener('offline', off)
    }
  }, [tryFlush])

  const blocked = isTrainingBlocked(state)
  const firebaseEnabled = isCloudSyncEnabled()

  const startLocalAccount = useCallback((displayName: string, email: string) => {
    const user: LocalUser = {
      id: uid('user'),
      displayName: displayName.trim() || email.split('@')[0] || 'Atleta',
      email: email.trim().toLowerCase(),
      onboardingComplete: false,
      onboardingStep: 0,
      createdAt: todayIso(),
    }
    setAuthMode('demo')
    setApiToken(null)
    setState((s) => ({ ...s, user }))
  }, [])

  const signUpEmail = useCallback(async (email: string, password: string, displayName: string) => {
    if (isApiBackendConfigured()) {
      const { user } = await apiSignup(email.trim(), password, displayName.trim())
      if (user) await hydrateFromApiUser(user)
      return
    }
    const auth = getFirebaseAuth()
    if (!auth) throw new Error('Backend no configurado')
    const cred = await createUserWithEmailAndPassword(auth, email.trim(), password)
    if (displayName.trim()) {
      await updateProfile(cred.user, { displayName: displayName.trim() })
    }
  }, [hydrateFromApiUser])

  const signInEmail = useCallback(async (email: string, password: string) => {
    if (isApiBackendConfigured()) {
      const { user } = await apiLogin(email.trim(), password)
      if (user) await hydrateFromApiUser(user)
      return
    }
    const auth = getFirebaseAuth()
    if (!auth) throw new Error('Backend no configurado')
    await signInWithEmailAndPassword(auth, email.trim(), password)
  }, [hydrateFromApiUser])

  const signInGoogle = useCallback(async () => {
    if (isApiBackendConfigured()) {
      throw new Error('Google Sign-In no disponible en la API Capstone; usa email/password')
    }
    const auth = getFirebaseAuth()
    if (!auth) throw new Error('Backend no configurado')
    await signInWithPopup(auth, googleProvider)
  }, [])

  const signOutUser = useCallback(async () => {
    if (isApiBackendConfigured()) {
      await apiLogout()
    } else {
      const auth = getFirebaseAuth()
      if (auth) await signOut(auth)
    }
    authUidRef.current = null
    setAuthMode('demo')
    clearQueue()
    setState(createEmptyState())
  }, [])

  const setOnboardingStep = useCallback((step: number) => {
    setState((s) => {
      if (!s.user) return s
      const user = { ...s.user, onboardingStep: step }
      enqueueStateMutation('user', {
        onboardingStep: step,
        onboardingComplete: user.onboardingComplete,
        email: user.email,
        displayName: user.displayName,
        createdAt: user.createdAt,
      })
      if (authUidRef.current) void tryFlush(authUidRef.current)
      return { ...s, user }
    })
  }, [tryFlush])

  const completeOnboarding = useCallback(() => {
    setState((s) => {
      if (!s.user) return s
      const notif = {
        id: uid('notif'),
        category: 'activity' as const,
        title: 'Onboarding completado',
        description: 'Tu perfil BFR está listo. Empieza con un Cuff Check.',
        read: false,
        createdAt: todayIso(),
      }
      enqueueStateMutation('user', {
        onboardingComplete: true,
        onboardingStep: 5,
        email: s.user.email,
        displayName: s.user.displayName,
        createdAt: s.user.createdAt,
      })
      const allow = canEnqueueNotification(
        s.notifications,
        notif,
        s.preferences,
        s.goal?.archetype ?? 'general_fitness',
      )
      if (allow) enqueueStateMutation('notification', notif, notif.id)
      if (authUidRef.current) void tryFlush(authUidRef.current)
      return {
        ...s,
        user: { ...s.user, onboardingComplete: true, onboardingStep: 5 },
        notifications: allow ? [notif, ...s.notifications] : s.notifications,
      }
    })
  }, [tryFlush])

  const saveProfile = useCallback(
    (profile: PhysicalProfile) => {
      setState((s) => ({ ...s, profile }))
      enqueueStateMutation('profile', { ...profile })
      if (authUidRef.current) void tryFlush(authUidRef.current)
    },
    [tryFlush],
  )

  const submitScreening = useCallback(
    (answers: Omit<MedicalScreening, 'id' | 'medicalClearance' | 'submittedAt'>) => {
      const medicalClearance = !(
        answers.dvt ||
        answers.highBloodPressure ||
        answers.pregnant ||
        answers.recentSurgery ||
        answers.clottingDisorders
      )
      const record: MedicalScreening = {
        id: uid('med'),
        ...answers,
        medicalClearance,
        submittedAt: todayIso(),
      }
      setState((s) => {
        const blockedNotif = medicalClearance
          ? null
          : {
              id: uid('notif'),
              category: 'recovery' as const,
              title: 'Entrenamiento bloqueado',
              description:
                'El screening médico detectó una contraindicación. Consulta a un profesional antes de usar BFR.',
              read: false,
              createdAt: todayIso(),
            }
        enqueueStateMutation('screening', { ...record }, record.id)
        if (blockedNotif) enqueueStateMutation('notification', blockedNotif, blockedNotif.id)
        if (authUidRef.current) void tryFlush(authUidRef.current)
        return {
          ...s,
          medicalHistory: [record, ...s.medicalHistory],
          notifications: blockedNotif ? [blockedNotif, ...s.notifications] : s.notifications,
        }
      })
      return record
    },
    [tryFlush],
  )

  const saveGoal = useCallback(
    (goalInput: Omit<TrainingGoal, 'id' | 'isActive' | 'createdAt'>) => {
      setState((s) => {
        const next: TrainingGoal = {
          ...goalInput,
          id: uid('goal'),
          isActive: true,
          createdAt: todayIso(),
        }
        const history = s.goal
          ? [{ ...s.goal, isActive: false }, ...s.goalHistory]
          : s.goalHistory
        if (s.goal) {
          enqueueStateMutation('goal', { ...s.goal, isActive: false }, s.goal.id)
        }
        enqueueStateMutation('goal', { ...next }, next.id)
        if (authUidRef.current) void tryFlush(authUidRef.current)
        return { ...s, goal: next, goalHistory: history }
      })
    },
    [tryFlush],
  )

  const saveEquipment = useCallback(
    (inventory: Omit<EquipmentInventory, 'updatedAt'>) => {
      const equipmentLevels = inventory.equipment.includes('bodyweight')
        ? inventory.equipment
        : ([...inventory.equipment, 'bodyweight'] as EquipmentInventory['equipment'])
      const equipment = {
        garments: inventory.garments,
        equipment: equipmentLevels,
        updatedAt: todayIso(),
      }
      setState((s) => ({ ...s, equipment }))
      enqueueStateMutation('equipment', { ...equipment })
      if (authUidRef.current) void tryFlush(authUidRef.current)
    },
    [tryFlush],
  )

  const toggleDevice = useCallback(
    (provider: WearableProvider) => {
      setState((s) => {
        const devices = s.devices.map((d: ConnectedDevice) =>
          d.provider === provider
            ? {
                ...d,
                status: d.status === 'disconnected' ? ('mock' as const) : ('disconnected' as const),
                lastSynced: d.status === 'disconnected' ? todayIso() : undefined,
              }
            : d,
        )
        const updated = devices.find((d) => d.provider === provider)
        if (updated) enqueueStateMutation('device', { ...updated })
        if (authUidRef.current) void tryFlush(authUidRef.current)
        return { ...s, devices }
      })
    },
    [tryFlush],
  )

  const addCuffCheck = useCallback(
    (check: Omit<CuffCheck, 'id' | 'createdAt'>) => {
      const record: CuffCheck = { ...check, id: uid('cuff'), createdAt: todayIso() }
      setState((s) => ({ ...s, cuffChecks: [record, ...s.cuffChecks] }))
      enqueueStateMutation('cuff', { ...record }, record.id)
      if (authUidRef.current) void tryFlush(authUidRef.current)
      return record
    },
    [tryFlush],
  )

  const addSession = useCallback(
    (session: Omit<WorkoutSession, 'id' | 'createdAt'>) => {
      const record: WorkoutSession = {
        ...session,
        id: uid('sess'),
        createdAt: todayIso(),
      }
      const notif = {
        id: uid('notif'),
        category: 'nutrition' as const,
        title: 'Ventana de nutrición abierta',
        description: 'Prioriza proteína en los próximos 30 minutos.',
        read: false,
        createdAt: todayIso(),
      }
      setState((s) => {
        const allow = canEnqueueNotification(
          s.notifications,
          notif,
          s.preferences,
          s.goal?.archetype ?? 'general_fitness',
        )
        if (allow) enqueueStateMutation('notification', notif, notif.id)
        return {
          ...s,
          sessions: [record, ...s.sessions],
          notifications: allow ? [notif, ...s.notifications] : s.notifications,
        }
      })
      enqueueStateMutation('session', { ...record }, record.id)
      if (authUidRef.current) void tryFlush(authUidRef.current)
    },
    [tryFlush],
  )

  const selectExercise = useCallback((id: string | null) => {
    setState((s) => ({ ...s, selectedExerciseId: id }))
  }, [])

  const startProteinWindow = useCallback(
    (seconds: number) => {
      const ends = new Date(Date.now() + seconds * 1000).toISOString()
      setState((s) => ({ ...s, proteinTimerEndsAt: ends }))
      enqueueStateMutation('user', { proteinTimerEndsAt: ends })
      if (authUidRef.current) void tryFlush(authUidRef.current)
    },
    [tryFlush],
  )

  const clearProteinWindow = useCallback(() => {
    setState((s) => ({ ...s, proteinTimerEndsAt: null }))
    enqueueStateMutation('user', { proteinTimerEndsAt: null })
    if (authUidRef.current) void tryFlush(authUidRef.current)
  }, [tryFlush])

  const updatePreferences = useCallback(
    (prefs: Partial<UserPreferences>) => {
      setState((s) => {
        const preferences = {
          ...s.preferences,
          ...prefs,
          notifications: { ...s.preferences.notifications, ...prefs.notifications },
          quietHours: { ...s.preferences.quietHours, ...prefs.quietHours },
        }
        enqueueStateMutation('user', { preferences })
        if (authUidRef.current) void tryFlush(authUidRef.current)
        return { ...s, preferences }
      })
    },
    [tryFlush],
  )

  const markNotificationRead = useCallback(
    (id: string) => {
      setState((s) => {
        const notifications = s.notifications.map((n) =>
          n.id === id ? { ...n, read: true } : n,
        )
        const n = notifications.find((x) => x.id === id)
        if (n) enqueueStateMutation('notification', { ...n }, n.id)
        if (authUidRef.current) void tryFlush(authUidRef.current)
        return { ...s, notifications }
      })
    },
    [tryFlush],
  )

  const markAllNotificationsRead = useCallback(() => {
    setState((s) => {
      const notifications = s.notifications.map((n) => ({ ...n, read: true }))
      for (const n of notifications) {
        enqueueStateMutation('notification', { ...n }, n.id)
      }
      if (authUidRef.current) void tryFlush(authUidRef.current)
      return { ...s, notifications }
    })
  }, [tryFlush])

  const deleteAccount = useCallback(async (confirmation: string) => {
    const okWord = isApiBackendConfigured() ? 'ELIMINAR' : 'DELETE'
    if (confirmation !== okWord) return false
    if (isApiBackendConfigured()) {
      await apiDeleteAccount(confirmation)
      setApiToken(null)
      setRefreshToken(null)
    } else {
      const auth = getFirebaseAuth()
      if (auth?.currentUser) {
        try {
          await auth.currentUser.delete()
        } catch {
          await signOut(auth)
        }
      }
    }
    clearAllData()
    clearQueue()
    ensureExerciseCache()
    authUidRef.current = null
    setState(createEmptyState())
    return true
  }, [])

  const resetDemo = useCallback(() => {
    setApiToken(null)
    setRefreshToken(null)
    clearAllData()
    clearQueue()
    ensureExerciseCache()
    authUidRef.current = null
    setAuthMode('demo')
    setAuthReady(true)
    setState(createEmptyState())
  }, [])

  const value = useMemo(
    () => ({
      state,
      blocked,
      authReady,
      authMode,
      firebaseEnabled,
      syncOnline,
      lastSyncMessage,
      firebaseModeLabel: backendModeLabel(),
      startLocalAccount,
      signUpEmail,
      signInEmail,
      signInGoogle,
      signOutUser,
      setOnboardingStep,
      completeOnboarding,
      saveProfile,
      submitScreening,
      saveGoal,
      saveEquipment,
      toggleDevice,
      addCuffCheck,
      addSession,
      selectExercise,
      startProteinWindow,
      clearProteinWindow,
      updatePreferences,
      markNotificationRead,
      markAllNotificationsRead,
      deleteAccount,
      resetDemo,
    }),
    [
      state,
      blocked,
      authReady,
      authMode,
      firebaseEnabled,
      syncOnline,
      lastSyncMessage,
      startLocalAccount,
      signUpEmail,
      signInEmail,
      signInGoogle,
      signOutUser,
      setOnboardingStep,
      completeOnboarding,
      saveProfile,
      submitScreening,
      saveGoal,
      saveEquipment,
      toggleDevice,
      addCuffCheck,
      addSession,
      selectExercise,
      startProteinWindow,
      clearProteinWindow,
      updatePreferences,
      markNotificationRead,
      markAllNotificationsRead,
      deleteAccount,
      resetDemo,
    ],
  )

  return <AppContext.Provider value={value}>{children}</AppContext.Provider>
}

export function useApp() {
  const ctx = useContext(AppContext)
  if (!ctx) throw new Error('useApp debe usarse dentro de AppProvider')
  return ctx
}

export function useExerciseCatalog() {
  return EXERCISES
}