export type GoalArchetype =
  | 'rehabilitation'
  | 'hypertrophy'
  | 'endurance'
  | 'general_fitness'
  | 'sport_specific'

export type MuscleGroup =
  | 'chest'
  | 'back'
  | 'shoulders'
  | 'arms'
  | 'core'
  | 'quads'
  | 'posterior'

export type LimbType = 'left_arm' | 'right_arm' | 'left_leg' | 'right_leg'
export type LimbRegion = 'upper_body' | 'lower_body'
export type GarmentId = 'hytro_upper' | 'hytro_lower' | 'pneumatic' | 'manual_band'
export type EquipmentLevel = 'full_gym' | 'home_gym' | 'bands_only' | 'bodyweight'
export type WearableProvider =
  | 'apple_health'
  | 'google_fit'
  | 'oura'
  | 'whoop'
  | 'garmin'
  | 'fitbit'
  | 'samsung'

export type CrtAssessment = 'too_loose' | 'ideal' | 'danger'
export type ZoneStatus = 'in_safe_zone' | 'too_low' | 'not_detected'
export type Units = 'metric' | 'imperial'

export interface PhysicalProfile {
  gender: 'male' | 'female' | 'other'
  weightKg: number
  heightCm: number
  systolicMmHg: number
  diastolicMmHg: number
  limbCircumferences: {
    leftArmCm: number
    rightArmCm: number
    leftLegCm: number
    rightLegCm: number
  }
}

export interface MedicalScreening {
  id: string
  dvt: boolean
  highBloodPressure: boolean
  pregnant: boolean
  recentSurgery: boolean
  clottingDisorders: boolean
  medicalClearance: boolean
  physicianClearanceNote?: string
  submittedAt: string
}

export interface TrainingGoal {
  id: string
  archetype: GoalArchetype
  milestones: Array<{
    description: string
    targetValue: number
    unit: string
    targetDate?: string
  }>
  timeline: { startDate: string; endDate: string; weekCount: number }
  constraints: Array<
    'no_impact' | 'bodyweight_only' | 'upper_body_only' | 'lower_body_only' | 'seated_only'
  >
  sport?: string
  isActive: boolean
  createdAt: string
}

export interface EquipmentInventory {
  garments: GarmentId[]
  equipment: EquipmentLevel[]
  updatedAt: string
}

export interface ConnectedDevice {
  provider: WearableProvider
  status: 'connected' | 'disconnected' | 'mock'
  lastSynced?: string
}

export interface Exercise {
  id: string
  name: string
  muscleGroup: MuscleGroup
  cuffZone: LimbRegion
  repSchemeDefault: string
  difficulty: 1 | 2 | 3 | 4 | 5
  equipmentTags: EquipmentLevel[]
  goalRelevance: Record<GoalArchetype, number>
  description: string
  formCues: string[]
}

export interface WorkoutSet {
  setNumber: number
  reps: number
  durationSeconds: number
  restSeconds: number
  targetReps: number
}

export interface WorkoutSession {
  id: string
  exerciseId: string
  exerciseName: string
  muscleGroup: MuscleGroup
  sets: WorkoutSet[]
  totalDurationSeconds: number
  avgHeartRate?: number
  maxHeartRate?: number
  avgTensionScore: number
  pressureMmhg: number
  crtSeconds?: number
  type: 'standard' | 'finisher'
  goalArchetype: GoalArchetype
  createdAt: string
}

export interface CuffCheck {
  id: string
  limbType: LimbType
  zoneStatus: ZoneStatus
  crtSeconds?: number
  crtAssessment?: CrtAssessment
  garmentId?: GarmentId
  createdAt: string
}

export interface AppNotification {
  id: string
  category: 'cycle' | 'calories' | 'recovery' | 'activity' | 'nutrition' | 'goal'
  title: string
  description: string
  read: boolean
  createdAt: string
}

export interface UserPreferences {
  units: Units
  notifications: {
    cycles: boolean
    calories: boolean
    recovery: boolean
    activity: boolean
    nutrition: boolean
    goals: boolean
  }
  quietHours: { enabled: boolean; start: string; end: string }
}

export interface LocalUser {
  id: string
  email: string
  displayName: string
  onboardingComplete: boolean
  onboardingStep: number
  createdAt: string
  clientId?: string
  role?: 'admin' | 'auditor' | 'trainer' | 'user'
  plan?: 'basic' | 'premium'
  permissions?: string[]
  features?: string[]
  emailVerified?: boolean
}

export interface AppState {
  user: LocalUser | null
  profile: PhysicalProfile | null
  medicalHistory: MedicalScreening[]
  goal: TrainingGoal | null
  goalHistory: TrainingGoal[]
  equipment: EquipmentInventory
  devices: ConnectedDevice[]
  sessions: WorkoutSession[]
  cuffChecks: CuffCheck[]
  notifications: AppNotification[]
  preferences: UserPreferences
  selectedExerciseId: string | null
  proteinTimerEndsAt: string | null
}

export const STORAGE_KEY = 'hytro.precision.v1'
export const EXERCISE_CACHE_KEY = 'hytro.exercises.v1'
export const EXERCISE_CATALOG_VERSION = '1.0.0'
