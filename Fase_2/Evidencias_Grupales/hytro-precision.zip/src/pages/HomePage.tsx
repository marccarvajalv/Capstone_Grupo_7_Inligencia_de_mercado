import { Link } from 'react-router-dom'
import { Armchair, Bell, Map, Timer, Zap } from 'lucide-react'
import { Badge, Button, Panel, ProgressBar, SectionTitle } from '../components/ui'
import { useI18n } from '../i18n'
import { computeReadiness } from '../lib/readiness'
import { getProtocol } from '../lib/protocols'
import { useApp } from '../store/AppContext'
import { useState } from 'react'

export function HomePage() {
  const { state, markNotificationRead, markAllNotificationsRead } = useApp()
  const { t } = useI18n()
  const archetype = state.goal?.archetype ?? 'general_fitness'
  const protocol = getProtocol(archetype)
  const readiness = computeReadiness(state.devices, archetype)
  const [showNotifs, setShowNotifs] = useState(false)

  const sessionsDone = state.sessions.length
  const target = state.goal?.milestones[0]?.targetValue ?? 16
  const progressPct = Math.min(100, Math.round((sessionsDone / target) * 100))
  const unread = state.notifications.filter((n) => !n.read).length

  const weekStart = new Date()
  const day = weekStart.getDay()
  weekStart.setDate(weekStart.getDate() + (day === 0 ? -6 : 1 - day))
  weekStart.setHours(0, 0, 0, 0)
  const weekSessions = state.sessions.filter((s) => new Date(s.createdAt) >= weekStart)

  const weekDays = [
    t('home.dayMon'),
    t('home.dayTue'),
    t('home.dayWed'),
    t('home.dayThu'),
    t('home.dayFri'),
    t('home.daySat'),
    t('home.daySun'),
  ]

  const readinessLevelLabel =
    readiness.level === 'ALTO'
      ? t('home.levelHigh')
      : readiness.level === 'BAJO'
        ? t('home.levelLow')
        : t('home.levelMid')

  const weekNum = Math.min(
    state.goal?.timeline.weekCount ?? 1,
    Math.ceil(
      (Date.now() - new Date(state.goal?.timeline.startDate ?? Date.now()).getTime()) /
        (7 * 24 * 3600 * 1000),
    ) || 1,
  )

  return (
    <div className="space-y-4 animate-slide-up">
      <div className="flex items-start justify-between gap-3">
        <SectionTitle
          title={t('home.goal', { label: protocol.label })}
          subtitle={protocol.progressionNote}
        />
        <button
          type="button"
          onClick={() => setShowNotifs(true)}
          className="relative rounded-xl border border-border p-2 text-ghost"
          aria-label={t('home.notifications')}
        >
          <Bell className="h-5 w-5" />
          {unread > 0 ? (
            <span className="absolute -right-1 -top-1 flex h-4 min-w-4 items-center justify-center rounded-full bg-arterial px-1 text-[10px] text-white">
              {unread}
            </span>
          ) : null}
        </button>
      </div>

      <Panel>
        <div className="flex items-center justify-between">
          <p className="text-sm text-ghost">{t('home.planProgress')}</p>
          <span className="num text-plasma">{progressPct}%</span>
        </div>
        <div className="mt-2">
          <ProgressBar value={progressPct} />
        </div>
        <p className="mt-2 text-xs text-muted">
          {t('home.sessionsWeek', {
            done: sessionsDone,
            target,
            week: weekNum,
            total: state.goal?.timeline.weekCount ?? '—',
          })}
        </p>
      </Panel>

      <Panel>
        <p className="font-medium">{t('home.preTrainTitle')}</p>
        <p className="mt-1 text-sm text-ghost">{t('home.preTrainBody')}</p>
        <p className="mt-2 text-[11px] text-muted">{t('home.preTrainDisclaimer')}</p>
      </Panel>

      <Panel className="relative overflow-hidden">
        <div className="absolute -right-6 -top-6 h-24 w-24 rounded-full bg-plasma/10 blur-2xl" />
        <div className="flex items-end justify-between">
          <div>
            <p className="text-sm text-ghost">{t('home.readinessTitle')}</p>
            <p className="num mt-1 text-4xl text-bone">{readiness.total}</p>
            <Badge tone={readiness.level === 'ALTO' ? 'bio' : readiness.level === 'BAJO' ? 'arterial' : 'plasma'}>
              {readinessLevelLabel}
            </Badge>
          </div>
          <Zap className="h-8 w-8 text-plasma animate-breathe" />
        </div>
        <p className="mt-3 text-sm text-ghost">{readiness.recommendation}</p>
        <div className="mt-4 grid grid-cols-5 gap-2 text-center text-[10px] text-muted">
          {[
            [t('home.readinessHrv'), readiness.hrv],
            [t('home.readinessSleep'), readiness.sleep],
            [t('home.readinessRhr'), readiness.rhr],
            [t('home.readinessSpo2'), readiness.spo2],
            [t('home.readinessMuscle'), readiness.muscleRecovery],
          ].map(([label, value]) => (
            <div key={label as string}>
              <p className="num text-sm text-bone">{Math.round(value as number)}</p>
              <p>{label}</p>
            </div>
          ))}
        </div>
      </Panel>

      <div className="grid grid-cols-3 gap-2">
        <Link to="/app/train" className="rounded-2xl border border-border bg-bg-panel p-3 text-center hover:border-plasma/40">
          <Map className="mx-auto h-5 w-5 text-plasma" />
          <p className="mt-2 text-xs">{t('home.bodyMap')}</p>
        </Link>
        <Link to="/app/cuff" className="rounded-2xl border border-border bg-bg-panel p-3 text-center hover:border-plasma/40">
          <Armchair className="mx-auto h-5 w-5 text-plasma" />
          <p className="mt-2 text-xs">{t('home.cuffCheck')}</p>
        </Link>
        <Link to="/app/workout?finisher=1" className="rounded-2xl border border-border bg-bg-panel p-3 text-center hover:border-plasma/40">
          <Timer className="mx-auto h-5 w-5 text-plasma" />
          <p className="mt-2 text-xs">{t('home.finisher')}</p>
        </Link>
      </div>

      <Panel>
        <div className="flex items-center justify-between">
          <p className="font-medium">{t('home.myKit')}</p>
          <Badge>{t('home.garments', { count: state.equipment?.garments?.length ?? 0 })}</Badge>
        </div>
        <p className="mt-1 text-sm text-ghost">
          {state.equipment?.equipment?.join(' · ') || t('home.noEquipment')}
        </p>
      </Panel>

      <Panel>
        <p className="font-medium">{t('home.thisWeek')}</p>
        <div className="mt-3 flex items-end gap-1">
          {Array.from({ length: 7 }).map((_, i) => {
            const d = new Date(weekStart)
            d.setDate(weekStart.getDate() + i)
            const count = weekSessions.filter(
              (s) => new Date(s.createdAt).toDateString() === d.toDateString(),
            ).length
            return (
              <div key={i} className="flex flex-1 flex-col items-center gap-1">
                <div
                  className="w-full rounded-md bg-plasma/80"
                  style={{ height: `${Math.max(6, count * 18)}px` }}
                />
                <span className="text-[10px] text-muted">{weekDays[i]}</span>
              </div>
            )
          })}
        </div>
      </Panel>

      <Panel>
        <p className="mb-2 font-medium">{t('home.recentSessions')}</p>
        {state.sessions.length === 0 ? (
          <p className="text-sm text-muted">{t('home.noSessions')}</p>
        ) : (
          <ul className="space-y-2">
            {state.sessions.slice(0, 4).map((s) => (
              <li key={s.id} className="flex items-center justify-between text-sm">
                <span>{s.exerciseName}</span>
                <span className="num text-ghost">
                  {Math.round(s.totalDurationSeconds / 60)} min
                </span>
              </li>
            ))}
          </ul>
        )}
      </Panel>

      {showNotifs && (
        <div className="fixed inset-0 z-50 flex items-end bg-black/70 p-4 sm:items-center sm:justify-center">
          <Panel className="max-h-[70vh] w-full max-w-md overflow-auto">
            <div className="mb-3 flex items-center justify-between">
              <h3 className="font-semibold">{t('home.notifications')}</h3>
              <Button size="sm" variant="ghost" onClick={markAllNotificationsRead}>
                {t('home.markRead')}
              </Button>
            </div>
            <ul className="space-y-2">
              {state.notifications.map((n) => (
                <li
                  key={n.id}
                  className={`rounded-xl border px-3 py-2 ${n.read ? 'border-border opacity-60' : 'border-plasma/30'}`}
                >
                  <button
                    type="button"
                    className="w-full text-left"
                    onClick={() => markNotificationRead(n.id)}
                  >
                    <p className="text-sm font-medium">{n.title}</p>
                    <p className="text-xs text-ghost">{n.description}</p>
                  </button>
                </li>
              ))}
            </ul>
            <Button className="mt-4 w-full" variant="secondary" onClick={() => setShowNotifs(false)}>
              {t('common.close')}
            </Button>
          </Panel>
        </div>
      )}
    </div>
  )
}
