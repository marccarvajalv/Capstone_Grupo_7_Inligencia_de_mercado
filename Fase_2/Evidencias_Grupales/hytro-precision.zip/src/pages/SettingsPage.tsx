import { useEffect, useState } from 'react'
import { useNavigate } from 'react-router-dom'
import { Button, Input, Label, Panel, SectionTitle, ToggleChip } from '../components/ui'
import { useI18n, type Locale } from '../i18n'
import { getApiBase, isApiBackendConfigured, setApiBase } from '../lib/apiClient'
import { getBackendMode } from '../lib/backendMode'
import {
  getEmulatorHost,
  getFirebaseMode,
  setEmulatorHost,
} from '../lib/firebase'
import { getProtocol } from '../lib/protocols'
import { useApp } from '../store/AppContext'
import { useTheme, type Theme } from '../theme'
import type {
  EquipmentLevel,
  GarmentId,
  GoalArchetype,
  PhysicalProfile,
  WearableProvider,
} from '../types'

const ARCHETYPES: GoalArchetype[] = [
  'rehabilitation',
  'hypertrophy',
  'endurance',
  'general_fitness',
  'sport_specific',
]

const GARMENT_IDS: GarmentId[] = ['hytro_upper', 'hytro_lower', 'pneumatic', 'manual_band']
const EQUIPMENT_IDS: EquipmentLevel[] = ['bodyweight', 'bands_only', 'home_gym', 'full_gym']

const WEARABLES: { id: WearableProvider; label: string }[] = [
  { id: 'apple_health', label: 'Apple Health' },
  { id: 'google_fit', label: 'Google Fit' },
  { id: 'oura', label: 'Oura' },
  { id: 'whoop', label: 'WHOOP' },
  { id: 'garmin', label: 'Garmin' },
  { id: 'fitbit', label: 'Fitbit' },
  { id: 'samsung', label: 'Samsung' },
]

export function SettingsPage() {
  const {
    state,
    saveProfile,
    saveGoal,
    saveEquipment,
    submitScreening,
    toggleDevice,
    updatePreferences,
    deleteAccount,
    resetDemo,
    signOutUser,
    firebaseEnabled,
    authMode,
    syncOnline,
    lastSyncMessage,
    firebaseModeLabel,
  } = useApp()
  const { t, locale, setLocale } = useI18n()
  const { theme, setTheme } = useTheme()
  const navigate = useNavigate()
  const [section, setSection] = useState<string | null>(null)
  const [deleteText, setDeleteText] = useState('')
  const [med, setMed] = useState({
    dvt: false,
    highBloodPressure: false,
    pregnant: false,
    recentSurgery: false,
    clottingDisorders: false,
    physicianClearanceNote: '',
  })
  const [profile, setProfile] = useState<PhysicalProfile>(
    state.profile ?? {
      gender: 'other',
      weightKg: 70,
      heightCm: 170,
      systolicMmHg: 120,
      diastolicMmHg: 80,
      limbCircumferences: {
        leftArmCm: 32,
        rightArmCm: 32,
        leftLegCm: 55,
        rightLegCm: 55,
      },
    },
  )
  const [garments, setGarments] = useState(state.equipment?.garments ?? ['hytro_upper'])
  const [equipment, setEquipment] = useState(
    state.equipment?.equipment ?? (['bodyweight'] as typeof state.equipment.equipment),
  )
  const [message, setMessage] = useState('')
  const [emulatorHost, setEmulatorHostInput] = useState(() => getEmulatorHost())
  const [apiBaseInput, setApiBaseInput] = useState(() => getApiBase())
  const emulatorMode = getFirebaseMode() === 'emulator' && !isApiBackendConfigured()
  const apiMode = getBackendMode() === 'api'

  const questions = [
    { key: 'dvt' as const, label: t('settings.qDvt') },
    { key: 'highBloodPressure' as const, label: t('settings.qHbp') },
    { key: 'pregnant' as const, label: t('settings.qPregnant') },
    { key: 'recentSurgery' as const, label: t('settings.qSurgery') },
    { key: 'clottingDisorders' as const, label: t('settings.qClotting') },
  ]

  const garmentLabels: Record<GarmentId, string> = {
    hytro_upper: t('settings.garmentUpper'),
    hytro_lower: t('settings.garmentLower'),
    pneumatic: t('settings.garmentPneumatic'),
    manual_band: t('settings.garmentBand'),
  }

  const equipmentLabels: Record<EquipmentLevel, string> = {
    bodyweight: t('settings.equipBodyweight'),
    bands_only: t('settings.equipBands'),
    home_gym: t('settings.equipHome'),
    full_gym: t('settings.equipFull'),
  }

  const sections = [
    { id: 'goal', label: t('settings.sectionGoal') },
    { id: 'profile', label: t('settings.sectionProfile') },
    { id: 'kit', label: t('settings.sectionKit') },
    { id: 'devices', label: t('settings.sectionDevices') },
    { id: 'medical', label: t('settings.sectionMedical') },
    { id: 'notifications', label: t('settings.sectionNotifications') },
    { id: 'units', label: t('settings.sectionUnits') },
    ...((emulatorMode || apiMode) ? [{ id: 'backend', label: t('settings.sectionBackend') }] : []),
    { id: 'account', label: t('settings.sectionAccount') },
  ]

  const openSection = (id: string) => {
    setSection((prev) => (prev === id ? null : id))
  }

  useEffect(() => {
    if (!section) return
    // Panel renders below the accordion list — scroll it into view on mobile.
    window.requestAnimationFrame(() => {
      document.getElementById('settings-section-panel')?.scrollIntoView({
        behavior: 'smooth',
        block: 'nearest',
      })
    })
  }, [section])

  const localeOptions: { id: Locale; label: string }[] = [
    { id: 'en', label: t('settings.langEn') },
    { id: 'es', label: t('settings.langEs') },
    { id: 'fr', label: t('settings.langFr') },
  ]

  const themeOptions: { id: Theme; label: string }[] = [
    { id: 'light', label: t('settings.themeLight') },
    { id: 'dark', label: t('settings.themeDark') },
    { id: 'high-contrast', label: t('settings.themeHighContrast') },
  ]

  const syncSuffix = firebaseEnabled
    ? syncOnline
      ? ` · ${t('settings.syncOnline')}`
      : ` · ${t('settings.syncOffline')}`
    : ''

  return (
    <div className="space-y-4 animate-slide-up">
      <SectionTitle title={t('settings.title')} subtitle={t('settings.subtitle')} />
      <Panel className="text-sm text-ghost">
        <p>
          {firebaseModeLabel} · {t('settings.session', { mode: authMode })}
          {syncSuffix}
        </p>
        {lastSyncMessage ? <p className="mt-1 text-xs text-muted">{lastSyncMessage}</p> : null}
      </Panel>
      {message && <p className="text-sm text-bio">{message}</p>}

      {/* Language + theme always visible (were buried under accordion / off-screen) */}
      <Panel className="space-y-3">
        <p className="text-sm font-medium text-bone">{t('settings.sectionLanguage')}</p>
        <p className="text-sm text-ghost">{t('settings.languageHint')}</p>
        <div className="flex flex-wrap gap-2">
          {localeOptions.map((opt) => (
            <ToggleChip
              key={opt.id}
              selected={locale === opt.id}
              onClick={() => setLocale(opt.id)}
            >
              {opt.label}
            </ToggleChip>
          ))}
        </div>
      </Panel>

      <Panel className="space-y-3">
        <p className="text-sm font-medium text-bone">{t('settings.sectionTheme')}</p>
        <p className="text-sm text-ghost">{t('settings.themeHint')}</p>
        <div className="grid grid-cols-1 gap-2 sm:grid-cols-3">
          {themeOptions.map((opt) => (
            <ToggleChip
              key={opt.id}
              selected={theme === opt.id}
              onClick={() => {
                setTheme(opt.id)
                setMessage(`${t('settings.sectionTheme')}: ${opt.label}`)
              }}
            >
              {opt.label}
            </ToggleChip>
          ))}
        </div>
      </Panel>

      <div className="grid gap-2">
        {sections.map((s) => (
          <button
            key={s.id}
            type="button"
            onClick={() => openSection(s.id)}
            className="flex w-full items-center justify-between rounded-xl border border-border bg-bg-panel px-4 py-3 text-left text-sm hover:border-plasma/40"
          >
            {s.label}
            <span className="text-muted" aria-hidden>
              {section === s.id ? '−' : '+'}
            </span>
          </button>
        ))}
      </div>

      <div id="settings-section-panel" className="scroll-mt-24">
      {section === 'backend' && apiMode && (
        <Panel>
          <p className="mb-3 text-sm text-ghost">{t('settings.apiHint')}</p>
          <Label>{t('settings.apiBase')}</Label>
          <Input
            value={apiBaseInput}
            onChange={(e) => setApiBaseInput(e.target.value)}
            placeholder="https://….trycloudflare.com"
          />
          <Button
            type="button"
            className="mt-3"
            onClick={() => {
              setApiBase(apiBaseInput)
              setMessage(t('settings.apiSaved'))
              window.setTimeout(() => window.location.reload(), 400)
            }}
          >
            {t('settings.saveReload')}
          </Button>
        </Panel>
      )}

      {section === 'backend' && emulatorMode && (
        <Panel>
          <p className="mb-3 text-sm text-ghost">{t('settings.emulatorHint')}</p>
          <Label>{t('settings.emulatorHost')}</Label>
          <Input
            value={emulatorHost}
            onChange={(e) => setEmulatorHostInput(e.target.value)}
            placeholder="192.168.1.20 o 10.0.2.2"
          />
          <div className="mt-3 flex flex-wrap gap-2">
            <Button
              type="button"
              onClick={() => {
                setEmulatorHost(emulatorHost)
                setMessage(t('settings.hostSaved'))
                window.setTimeout(() => window.location.reload(), 400)
              }}
            >
              {t('settings.saveReload')}
            </Button>
            <Button
              type="button"
              variant="ghost"
              onClick={() => {
                setEmulatorHostInput('10.0.2.2')
                setEmulatorHost('10.0.2.2')
                setMessage(t('settings.hostAndroidSaved'))
                window.setTimeout(() => window.location.reload(), 400)
              }}
            >
              {t('settings.androidEmulator')}
            </Button>
            <Button
              type="button"
              variant="ghost"
              onClick={() => {
                setEmulatorHostInput('127.0.0.1')
                setEmulatorHost('127.0.0.1')
                setMessage(t('settings.hostLocalSaved'))
                window.setTimeout(() => window.location.reload(), 400)
              }}
            >
              {t('settings.localhost')}
            </Button>
          </div>
        </Panel>
      )}

      {section === 'goal' && (
        <Panel>
          <p className="mb-3 text-sm text-ghost">{t('settings.goalHint')}</p>
          <div className="grid gap-2">
            {ARCHETYPES.map((a) => (
              <ToggleChip
                key={a}
                selected={state.goal?.archetype === a}
                onClick={() => {
                  const start = new Date()
                  const end = new Date()
                  end.setDate(end.getDate() + 56)
                  saveGoal({
                    archetype: a,
                    milestones: [
                      {
                        description: t('settings.milestoneSessions'),
                        targetValue: 16,
                        unit: 'sesiones',
                      },
                    ],
                    timeline: {
                      startDate: start.toISOString(),
                      endDate: end.toISOString(),
                      weekCount: 8,
                    },
                    constraints: [],
                    sport: a === 'sport_specific' ? t('settings.sport') : undefined,
                  })
                  setMessage(t('settings.goalUpdated', { label: getProtocol(a).label }))
                }}
              >
                {getProtocol(a).label}
              </ToggleChip>
            ))}
          </div>
        </Panel>
      )}

      {section === 'profile' && (
        <Panel className="space-y-2">
          <div>
            <Label>{t('settings.weightKg')}</Label>
            <Input
              type="number"
              value={profile.weightKg}
              onChange={(e) => setProfile({ ...profile, weightKg: Number(e.target.value) })}
            />
          </div>
          <div>
            <Label>{t('settings.heightCm')}</Label>
            <Input
              type="number"
              value={profile.heightCm}
              onChange={(e) => setProfile({ ...profile, heightCm: Number(e.target.value) })}
            />
          </div>
          <div className="grid grid-cols-2 gap-2">
            <div>
              <Label>{t('settings.sys')}</Label>
              <Input
                type="number"
                value={profile.systolicMmHg}
                onChange={(e) => setProfile({ ...profile, systolicMmHg: Number(e.target.value) })}
              />
            </div>
            <div>
              <Label>{t('settings.dia')}</Label>
              <Input
                type="number"
                value={profile.diastolicMmHg}
                onChange={(e) => setProfile({ ...profile, diastolicMmHg: Number(e.target.value) })}
              />
            </div>
          </div>
          <Button
            className="w-full"
            onClick={() => {
              saveProfile(profile)
              setMessage(t('settings.profileSaved'))
            }}
          >
            {t('settings.saveProfile')}
          </Button>
        </Panel>
      )}

      {section === 'kit' && (
        <Panel className="space-y-3">
          <div className="grid grid-cols-2 gap-2">
            {GARMENT_IDS.map((id) => (
              <ToggleChip
                key={id}
                selected={garments.includes(id)}
                onClick={() =>
                  setGarments((prev) =>
                    prev.includes(id) ? prev.filter((x) => x !== id) : [...prev, id],
                  )
                }
              >
                {garmentLabels[id]}
              </ToggleChip>
            ))}
          </div>
          <div className="grid grid-cols-2 gap-2">
            {EQUIPMENT_IDS.map((id) => (
              <ToggleChip
                key={id}
                selected={equipment.includes(id)}
                onClick={() =>
                  setEquipment((prev) =>
                    id === 'bodyweight'
                      ? prev.includes('bodyweight')
                        ? prev
                        : [...prev, 'bodyweight']
                      : prev.includes(id)
                        ? prev.filter((x) => x !== id)
                        : [...prev, id],
                  )
                }
              >
                {equipmentLabels[id]}
              </ToggleChip>
            ))}
          </div>
          <Button
            className="w-full"
            onClick={() => {
              saveEquipment({ garments, equipment })
              setMessage(t('settings.kitUpdated'))
            }}
          >
            {t('settings.saveKit')}
          </Button>
        </Panel>
      )}

      {section === 'devices' && (
        <Panel className="space-y-2">
          {WEARABLES.map((w) => {
            const d = state.devices.find((x) => x.provider === w.id)
            return (
              <ToggleChip
                key={w.id}
                selected={d?.status !== 'disconnected'}
                onClick={() => toggleDevice(w.id)}
              >
                {w.label} —{' '}
                {d?.status === 'disconnected'
                  ? t('settings.deviceOff')
                  : t('settings.deviceMockOn')}
              </ToggleChip>
            )
          })}
        </Panel>
      )}

      {section === 'medical' && (
        <Panel className="space-y-3">
          <p className="text-sm text-ghost">
            {t('settings.lastClearance')}{' '}
            {state.medicalHistory[0]
              ? state.medicalHistory[0].medicalClearance
                ? t('settings.clearanceOk')
                : t('settings.clearanceBlocked')
              : t('settings.noScreening')}
          </p>
          {questions.map((q) => (
            <div key={q.key} className="flex items-center justify-between gap-2 text-sm">
              <span>{q.label}</span>
              <div className="flex gap-2">
                <ToggleChip selected={!med[q.key]} onClick={() => setMed({ ...med, [q.key]: false })}>
                  {t('common.no')}
                </ToggleChip>
                <ToggleChip selected={med[q.key]} onClick={() => setMed({ ...med, [q.key]: true })}>
                  {t('common.yes')}
                </ToggleChip>
              </div>
            </div>
          ))}
          <div>
            <Label>{t('settings.medicalNote')}</Label>
            <Input
              value={med.physicianClearanceNote}
              onChange={(e) => setMed({ ...med, physicianClearanceNote: e.target.value })}
            />
          </div>
          <Button
            className="w-full"
            onClick={() => {
              const r = submitScreening(med)
              setMessage(
                r.medicalClearance
                  ? t('settings.clearanceGranted')
                  : t('settings.trainingBlocked'),
              )
            }}
          >
            {t('settings.resubmitScreening')}
          </Button>
        </Panel>
      )}

      {section === 'notifications' && (
        <Panel className="space-y-2">
          {(
            [
              ['cycles', 'settings.notifCycles'],
              ['calories', 'settings.notifCalories'],
              ['recovery', 'settings.notifRecovery'],
              ['activity', 'settings.notifActivity'],
              ['nutrition', 'settings.notifNutrition'],
              ['goals', 'settings.notifGoals'],
            ] as const
          ).map(([key, labelKey]) => (
            <ToggleChip
              key={key}
              selected={state.preferences.notifications[key]}
              onClick={() =>
                updatePreferences({
                  notifications: {
                    ...state.preferences.notifications,
                    [key]: !state.preferences.notifications[key],
                  },
                })
              }
            >
              {t(labelKey)}
            </ToggleChip>
          ))}
        </Panel>
      )}

      {section === 'units' && (
        <Panel className="flex gap-2">
          <ToggleChip
            selected={state.preferences.units === 'metric'}
            onClick={() => updatePreferences({ units: 'metric' })}
          >
            {t('settings.unitsMetric')}
          </ToggleChip>
          <ToggleChip
            selected={state.preferences.units === 'imperial'}
            onClick={() => updatePreferences({ units: 'imperial' })}
          >
            {t('settings.unitsImperial')}
          </ToggleChip>
        </Panel>
      )}

      {section === 'account' && (
        <Panel className="space-y-3">
          <p className="text-sm text-ghost">
            {state.user?.displayName} · {state.user?.email}
          </p>
          {firebaseEnabled && authMode === 'firebase' ? (
            <Button
              variant="secondary"
              className="w-full"
              onClick={() => {
                void signOutUser().then(() => navigate('/'))
              }}
            >
              {t('settings.signOut')}
            </Button>
          ) : null}
          <Button
            variant="secondary"
            className="w-full"
            onClick={() => {
              resetDemo()
              navigate('/')
            }}
          >
            {t('settings.resetDemo')}
          </Button>
          <div className="flex gap-2 text-xs">
            <button
              type="button"
              className="text-plasma underline"
              onClick={() => navigate('/legal/privacy')}
            >
              {t('settings.privacy')}
            </button>
            <button
              type="button"
              className="text-plasma underline"
              onClick={() => navigate('/legal/terms')}
            >
              {t('settings.terms')}
            </button>
          </div>
          <div>
            <Label>
              {apiMode ? t('settings.deletePromptApi') : t('settings.deletePromptLocal')}
            </Label>
            <Input value={deleteText} onChange={(e) => setDeleteText(e.target.value)} />
          </div>
          <Button
            variant="danger"
            className="w-full"
            onClick={() => {
              void deleteAccount(deleteText).then((ok) => {
                if (ok) navigate('/')
                else
                  setMessage(
                    t('settings.deleteConfirmWrong', {
                      word: apiMode ? 'ELIMINAR' : 'DELETE',
                    }),
                  )
              })
            }}
          >
            {t('settings.deleteAccount')}
          </Button>
        </Panel>
      )}
      </div>
    </div>
  )
}
