import { Link, Navigate, useNavigate } from 'react-router-dom'
import { Button, Input, Label } from '../components/ui'
import {
  isApiBackendConfigured,
  setApiToken,
} from '../lib/apiClient'
import { useI18n } from '../i18n'
import { validatePassword } from '../lib/passwordPolicy'
import { useApp } from '../store/AppContext'
import { useEffect, useState } from 'react'

const DEMO_NAME = 'Demo Hytro'
const DEMO_EMAIL = 'demo@hytro.local'

export function SplashPage() {
  const {
    state,
    authReady,
    firebaseEnabled,
    firebaseModeLabel,
    startLocalAccount,
    signUpEmail,
    signInEmail,
    signInGoogle,
    resetDemo,
  } = useApp()
  const { t, locale, setLocale } = useI18n()
  const navigate = useNavigate()
  const [mode, setMode] = useState<'login' | 'signup'>('signup')
  const [name, setName] = useState('')
  const [email, setEmail] = useState('')
  const [password, setPassword] = useState('')
  const [error, setError] = useState('')
  const [busy, setBusy] = useState(false)
  const [stuck, setStuck] = useState(false)

  useEffect(() => {
    if (authReady) {
      setStuck(false)
      return
    }
    const timer = window.setTimeout(() => setStuck(true), 8000)
    return () => window.clearTimeout(timer)
  }, [authReady])

  if (!authReady) {
    return (
      <div className="mx-auto flex min-h-dvh max-w-lg flex-col items-center justify-center gap-4 px-5 text-center text-ghost">
        <p className="text-bone">{t('splash.loadingSession')}</p>
        <p className="text-xs text-muted">{firebaseModeLabel}</p>
        {stuck ? (
          <div className="mt-2 w-full max-w-sm space-y-2">
            <p className="text-sm text-arterial">{t('splash.stuckCloud')}</p>
            <Button
              type="button"
              className="w-full"
              onClick={() => window.location.reload()}
            >
              {t('common.retry')}
            </Button>
            <Button
              type="button"
              variant="secondary"
              className="w-full"
              onClick={() => {
                setApiToken(null)
                resetDemo()
                window.location.reload()
              }}
            >
              {t('splash.clearCloudRestart')}
            </Button>
            <Button
              type="button"
              variant="outline"
              className="w-full"
              onClick={() => {
                setApiToken(null)
                startLocalAccount(DEMO_NAME, DEMO_EMAIL)
                navigate('/onboarding')
              }}
            >
              {t('splash.continueDemo')}
            </Button>
          </div>
        ) : null}
      </div>
    )
  }

  if (state.user?.onboardingComplete) {
    return <Navigate to="/app/home" replace />
  }
  if (state.user && !state.user.onboardingComplete) {
    return <Navigate to="/onboarding" replace />
  }

  const beginDemo = () => {
    startLocalAccount(DEMO_NAME, DEMO_EMAIL)
    navigate('/onboarding')
  }

  const beginLocal = () => {
    const trimmedName = name.trim()
    const trimmedEmail = email.trim().toLowerCase()
    if (trimmedName.length < 2) {
      setError(t('splash.errNameShort'))
      return
    }
    if (!trimmedEmail.includes('@') || trimmedEmail.length < 5) {
      setError(t('splash.errEmail'))
      return
    }
    setError('')
    startLocalAccount(trimmedName, trimmedEmail)
    navigate('/onboarding')
  }

  const beginAuth = async () => {
    setBusy(true)
    setError('')
    try {
      if (mode === 'signup') {
        if (name.trim().length < 2) throw new Error(t('splash.errNameRequired'))
        const pwErr = validatePassword(password)
        if (pwErr) throw new Error(pwErr)
        await signUpEmail(email, password, name)
      } else {
        await signInEmail(email, password)
      }
      navigate('/onboarding')
    } catch (e) {
      setError(e instanceof Error ? e.message : t('splash.errAuth'))
    } finally {
      setBusy(false)
    }
  }

  return (
    <div className="relative mx-auto flex min-h-dvh max-w-lg flex-col justify-end overflow-hidden px-5 pb-10 pt-16">
      <div className="pointer-events-none absolute inset-0 -z-10" aria-hidden>
        <div className="absolute -left-20 top-10 h-72 w-72 rounded-full bg-plasma/20 blur-3xl animate-breathe" />
        <div className="absolute -right-10 bottom-40 h-64 w-64 rounded-full bg-arterial/10 blur-3xl" />
        <div className="absolute inset-x-8 top-24 aspect-[4/5] rounded-[2rem] border border-plasma/20 bg-gradient-to-b from-plasma/10 to-transparent" />
        <div className="absolute left-1/2 top-44 h-40 w-40 -translate-x-1/2 rounded-full border border-plasma/40 animate-pulse-ring" />
      </div>

      <div className="relative z-20 animate-slide-up">
        <p className="text-xs uppercase tracking-[0.35em] text-plasma">{t('splash.brand')}</p>
        <h1 className="mt-2 text-5xl font-semibold leading-none tracking-tight text-bone">
          {t('splash.title')}
        </h1>
        <p className="mt-4 max-w-sm text-base text-ghost">{t('splash.tagline')}</p>
        <p className="mt-2 text-xs text-muted">{firebaseModeLabel}</p>

        <form
          className="mt-8 space-y-3"
          noValidate
          onSubmit={(e) => {
            e.preventDefault()
            if (firebaseEnabled) void beginAuth()
            else beginLocal()
          }}
        >
          {(mode === 'signup' || !firebaseEnabled) && (
            <div>
              <Label>{t('splash.name')}</Label>
              <Input
                name="displayName"
                autoComplete="name"
                value={name}
                onChange={(e) => setName(e.target.value)}
                placeholder={t('splash.namePlaceholder')}
              />
            </div>
          )}
          <div>
            <Label>{t('splash.email')}</Label>
            <Input
              name="email"
              type="text"
              inputMode="email"
              autoComplete="email"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              placeholder={firebaseEnabled ? 'tu@email.com' : 'demo@hytro.local'}
            />
          </div>
          {firebaseEnabled && (
            <div>
              <Label>{t('splash.password')}</Label>
              <Input
                name="password"
                type="password"
                autoComplete={mode === 'signup' ? 'new-password' : 'current-password'}
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                placeholder={t('splash.passwordPlaceholder')}
              />
            </div>
          )}
          {error ? <p className="text-sm text-arterial">{error}</p> : null}
          <Button type="submit" className="relative z-20 w-full" size="lg" disabled={busy}>
            {firebaseEnabled
              ? mode === 'signup'
                ? t('splash.createAccount')
                : t('splash.signIn')
              : t('splash.startOnboarding')}
          </Button>
          {firebaseEnabled && (
            <>
              <Button
                type="button"
                variant="secondary"
                className="w-full"
                disabled={busy}
                onClick={() => setMode(mode === 'signup' ? 'login' : 'signup')}
              >
                {mode === 'signup' ? t('splash.haveAccount') : t('splash.createNewAccount')}
              </Button>
              {!isApiBackendConfigured() && (
                <Button
                  type="button"
                  variant="outline"
                  className="w-full"
                  disabled={busy}
                  onClick={() => {
                    setBusy(true)
                    void signInGoogle()
                      .then(() => navigate('/onboarding'))
                      .catch((e) =>
                        setError(e instanceof Error ? e.message : t('splash.errGoogle')),
                      )
                      .finally(() => setBusy(false))
                  }}
                >
                  {t('splash.continueGoogle')}
                </Button>
              )}
            </>
          )}
          <Button
            type="button"
            variant="outline"
            className="relative z-20 w-full"
            size="lg"
            onClick={beginDemo}
          >
            {t('splash.enterDemo')}
          </Button>
          <p className="text-center text-xs text-muted">
            {t('splash.demoHint', { name: DEMO_NAME, email: DEMO_EMAIL })}
            {firebaseEnabled ? t('splash.demoHintCloud') : t('splash.demoHintLocal')}
          </p>
          <div className="flex items-center justify-center gap-2">
            <select
              className="h-9 rounded-lg border border-border bg-bg-panel px-2 text-xs"
              value={locale}
              onChange={(e) => setLocale(e.target.value as typeof locale)}
              aria-label={t('settings.sectionLanguage')}
            >
              <option value="en">English</option>
              <option value="es">Español</option>
              <option value="fr">Français</option>
            </select>
          </div>
          <p className="text-center text-xs text-muted">
            <Link className="text-plasma underline" to="/legal/privacy">
              {t('splash.privacy')}
            </Link>
            {' · '}
            <Link className="text-plasma underline" to="/legal/terms">
              {t('splash.terms')}
            </Link>
          </p>
        </form>
      </div>
    </div>
  )
}
