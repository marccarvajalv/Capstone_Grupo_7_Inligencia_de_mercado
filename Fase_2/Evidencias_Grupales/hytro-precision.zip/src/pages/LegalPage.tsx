import { Link, useParams } from 'react-router-dom'
import { Button, Panel } from '../components/ui'
import { useI18n } from '../i18n'

export function LegalPage() {
  const { doc } = useParams()
  const { t } = useI18n()
  const isTerms = doc === 'terms'
  const title = isTerms ? t('legal.termsTitle') : t('legal.privacyTitle')
  const body = isTerms
    ? [t('legal.terms1'), t('legal.terms2'), t('legal.terms3'), t('legal.terms4')]
    : [
        t('legal.privacy1'),
        t('legal.privacy2'),
        t('legal.privacy3'),
        t('legal.privacy4'),
        t('legal.privacy5'),
      ]

  return (
    <div className="mx-auto flex min-h-dvh max-w-lg flex-col gap-4 px-5 py-10 animate-slide-up">
      <h1 className="text-2xl font-semibold text-bone">{title}</h1>
      <Panel className="space-y-3">
        {body.map((p) => (
          <p key={p.slice(0, 32)} className="text-sm text-ghost">
            {p}
          </p>
        ))}
      </Panel>
      <Link to="/">
        <Button className="w-full" variant="secondary">
          {t('legal.back')}
        </Button>
      </Link>
    </div>
  )
}
