import { useMemo, useState } from 'react'
import { Navigate, useNavigate } from 'react-router-dom'
import { Button, Input, Label, Panel, ToggleChip } from '../components/ui'
import { useI18n } from '../i18n'
import { getProtocol } from '../lib/protocols'
import { cmToIn, inToCm, kgToLb, lbToKg } from '../lib/utils'
import { useApp } from '../store/AppContext'
import type {
  EquipmentLevel,
  GarmentId,
  GoalArchetype,
  PhysicalProfile,
  WearableProvider,
} from '../types'

const ARCHETYPES: GoalArchetype[] = [
  'rehabilitation',
  'hypertrophy',
  'endurance',
  'general_fitness',
  'sport_specific',
]

const GARMENT_IDS: GarmentId[] = ['hytro_upper', 'hytro_lower', 'pneumatic', 'manual_band']
const EQUIPMENT_IDS: EquipmentLevel[] = ['bodyweight', 'bands_only', 'home_gym', 'full_gym']
const WEARABLE_IDS: WearableProvider[] = [
  'apple_health',
  'google_fit',
  'oura',
  'whoop',
  'garmin',
  'fitbit',
  'samsung',
]

export function OnboardingPage() {
  const {
    state,
    setOnboardingStep,
    saveProfile,
    submitScreening,
    saveGoal,
    saveEquipment,
    toggleDevice,
    completeOnboarding,
  } = useApp()
  const { t, locale, setLocale } = useI18n()
  const navigate = useNavigate()
  const step = state.user?.onboardingStep ?? 0
  const units = state.preferences.units

  const STEPS = [
    t('onboarding.stepProfile'),
    t('onboarding.stepMedical'),
    t('onboarding.stepGoal'),
    t('onboarding.stepKit'),
    t('onboarding.stepWearables'),
  ] as const

  const QUESTIONS = [
    { key: 'dvt' as const, label: t('onboarding.qDvt') },
    { key: 'highBloodPressure' as const, label: t('onboarding.qHbp') },
    { key: 'pregnant' as const, label: t('onboarding.qPregnant') },
    { key: 'recentSurgery' as const, label: t('onboarding.qSurgery') },
    { key: 'clottingDisorders' as const, label: t('onboarding.qClotting') },
  ]

  const garmentLabel = (id: GarmentId) =>
    ({
      hytro_upper: t('settings.garmentUpper'),
      hytro_lower: t('settings.garmentLower'),
      pneumatic: t('settings.garmentPneumatic'),
      manual_band: t('settings.garmentBand'),
    })[id]

  const equipmentLabel = (id: EquipmentLevel) =>
    ({
      bodyweight: t('settings.equipBodyweight'),
      bands_only: t('settings.equipBands'),
      home_gym: t('settings.equipHome'),
      full_gym: t('settings.equipFull'),
    })[id]

  const [profile, setProfile] = useState<PhysicalProfile>(
    state.profile ?? {
      gender: 'other',
      weightKg: 70,
      heightCm: 170,
      systolicMmHg: 120,
      diastolicMmHg: 80,
      limbCircumferences: {
        leftArmCm: 32,
        rightArmCm: 32,
        leftLegCm: 55,
        rightLegCm: 55,
      },
    },
  )
  const [med, setMed] = useState({
    dvt: false,
    highBloodPressure: false,
    pregnant: false,
    recentSurgery: false,
    clottingDisorders: false,
    physicianClearanceNote: '',
  })
  const [blockedModal, setBlockedModal] = useState(false)
  const [archetype, setArchetype] = useState<GoalArchetype>('hypertrophy')
  const [sport, setSport] = useState('')
  const [weekCount, setWeekCount] = useState(8)
  const [garments, setGarments] = useState<GarmentId[]>(
    state.equipment?.garments?.length ? state.equipment.garments : ['hytro_upper'],
  )
  const [equipment, setEquipment] = useState<EquipmentLevel[]>(
    state.equipment?.equipment?.length ? state.equipment.equipment : ['bodyweight'],
  )

  const canContinue = useMemo(() => {
    if (step === 0) {
      return (
        profile.weightKg >= 20 &&
        profile.heightCm >= 100 &&
        profile.systolicMmHg > profile.diastolicMmHg
      )
    }
    if (step === 2) {
      return archetype !== 'sport_specific' || sport.trim().length >= 2
    }
    if (step === 3) return garments.length > 0 && equipment.length > 0
    return true
  }, [step, profile, archetype, sport, garments, equipment])

  if (!state.user) return <Navigate to="/" replace />
  if (state.user.onboardingComplete) return <Navigate to="/app/home" replace />

  const goNext = () => {
    if (step === 0) {
      saveProfile(profile)
      setOnboardingStep(1)
      return
    }
    if (step === 1) {
      const record = submitScreening(med)
      if (!record.medicalClearance) {
        setBlockedModal(true)
        return
      }
      setOnboardingStep(2)
      return
    }
    if (step === 2) {
      const start = new Date()
      const end = new Date()
      end.setDate(end.getDate() + weekCount * 7)
      saveGoal({
        archetype,
        sport: archetype === 'sport_specific' ? sport : undefined,
        milestones: [
          {
            description: 'Completar sesiones BFR planificadas',
            targetValue: weekCount * 2,
            unit: 'sesiones',
            targetDate: end.toISOString(),
          },
        ],
        timeline: {
          startDate: start.toISOString(),
          endDate: end.toISOString(),
          weekCount,
        },
        constraints: [],
      })
      setOnboardingStep(3)
      return
    }
    if (step === 3) {
      saveEquipment({ garments, equipment })
      setOnboardingStep(4)
      return
    }
    completeOnboarding()
    navigate('/app/home')
  }

  return (
    <div className="mx-auto min-h-dvh max-w-lg px-4 py-6">
      <div className="flex items-start justify-between gap-2">
        <div>
          <p className="text-xs uppercase tracking-[0.25em] text-plasma">{t('onboarding.kicker')}</p>
          <h1 className="mt-1 text-2xl font-semibold">{t('onboarding.title')}</h1>
        </div>
        <select
          className="h-9 rounded-lg border border-border bg-bg-panel px-2 text-xs"
          value={locale}
          onChange={(e) => setLocale(e.target.value as typeof locale)}
          aria-label={t('settings.sectionLanguage')}
        >
          <option value="en">EN</option>
          <option value="es">ES</option>
          <option value="fr">FR</option>
        </select>
      </div>

      <div className="mt-5 grid grid-cols-5 gap-2">
        {STEPS.map((label, i) => (
          <div key={`${label}-${i}`} className="text-center">
            <div
              className={`h-1.5 rounded-full ${i <= step ? 'bg-plasma' : 'bg-white/10'}`}
            />
            <p className="mt-1 text-[10px] text-muted">{label}</p>
          </div>
        ))}
      </div>

      <div className="mt-6 animate-slide-up">
        {step === 0 && (
          <div className="space-y-3">
            <Panel>
              <p className="mb-3 text-sm text-ghost">
                {t('onboarding.unitsHint', {
                  units:
                    units === 'metric'
                      ? t('onboarding.unitsMetric')
                      : t('onboarding.unitsImperial'),
                })}
              </p>
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <Label>{t('onboarding.gender')}</Label>
                  <select
                    className="h-11 w-full rounded-xl border border-border bg-bg-panel px-3"
                    value={profile.gender}
                    onChange={(e) =>
                      setProfile({
                        ...profile,
                        gender: e.target.value as PhysicalProfile['gender'],
                      })
                    }
                  >
                    <option value="female">{t('onboarding.female')}</option>
                    <option value="male">{t('onboarding.male')}</option>
                    <option value="other">{t('onboarding.other')}</option>
                  </select>
                </div>
                <div>
                  <Label>
                    {t('onboarding.weight', { unit: units === 'metric' ? 'kg' : 'lb' })}
                  </Label>
                  <Input
                    type="number"
                    value={
                      units === 'metric'
                        ? profile.weightKg
                        : Math.round(kgToLb(profile.weightKg) * 10) / 10
                    }
                    onChange={(e) => {
                      const v = Number(e.target.value)
                      setProfile({
                        ...profile,
                        weightKg: units === 'metric' ? v : lbToKg(v),
                      })
                    }}
                  />
                </div>
                <div>
                  <Label>
                    {t('onboarding.height', { unit: units === 'metric' ? 'cm' : 'in' })}
                  </Label>
                  <Input
                    type="number"
                    value={
                      units === 'metric'
                        ? profile.heightCm
                        : Math.round(cmToIn(profile.heightCm) * 10) / 10
                    }
                    onChange={(e) => {
                      const v = Number(e.target.value)
                      setProfile({
                        ...profile,
                        heightCm: units === 'metric' ? v : inToCm(v),
                      })
                    }}
                  />
                </div>
                <div>
                  <Label>{t('onboarding.bp')}</Label>
                  <div className="flex gap-2">
                    <Input
                      type="number"
                      value={profile.systolicMmHg}
                      onChange={(e) =>
                        setProfile({ ...profile, systolicMmHg: Number(e.target.value) })
                      }
                    />
                    <Input
                      type="number"
                      value={profile.diastolicMmHg}
                      onChange={(e) =>
                        setProfile({ ...profile, diastolicMmHg: Number(e.target.value) })
                      }
                    />
                  </div>
                </div>
              </div>
            </Panel>
            <Panel>
              <p className="mb-2 text-sm font-medium">{t('onboarding.circumferences')}</p>
              <p className="mb-3 text-xs text-muted">{t('onboarding.circHint')}</p>
              {(
                [
                  ['leftArmCm', t('onboarding.leftArm')],
                  ['rightArmCm', t('onboarding.rightArm')],
                  ['leftLegCm', t('onboarding.leftLeg')],
                  ['rightLegCm', t('onboarding.rightLeg')],
                ] as const
              ).map(([key, label]) => (
                <div key={key} className="mb-2">
                  <Label>
                    {label} ({units === 'metric' ? 'cm' : 'in'})
                  </Label>
                  <Input
                    type="number"
                    value={
                      units === 'metric'
                        ? profile.limbCircumferences[key]
                        : Math.round(cmToIn(profile.limbCircumferences[key]) * 10) / 10
                    }
                    onChange={(e) => {
                      const v = Number(e.target.value)
                      setProfile({
                        ...profile,
                        limbCircumferences: {
                          ...profile.limbCircumferences,
                          [key]: units === 'metric' ? v : inToCm(v),
                        },
                      })
                    }}
                  />
                </div>
              ))}
            </Panel>
          </div>
        )}

        {step === 1 && (
          <Panel>
            <p className="mb-4 text-sm text-ghost">{t('onboarding.screeningHint')}</p>
            <div className="space-y-3">
              {QUESTIONS.map((q) => (
                <div
                  key={q.key}
                  className="flex items-center justify-between gap-3 rounded-xl border border-border px-3 py-3"
                >
                  <p className="text-sm text-bone">{q.label}</p>
                  <div className="flex gap-2">
                    <ToggleChip
                      selected={med[q.key] === false}
                      onClick={() => setMed({ ...med, [q.key]: false })}
                    >
                      {t('common.no')}
                    </ToggleChip>
                    <ToggleChip
                      selected={med[q.key] === true}
                      onClick={() => setMed({ ...med, [q.key]: true })}
                    >
                      {t('common.yes')}
                    </ToggleChip>
                  </div>
                </div>
              ))}
            </div>
          </Panel>
        )}

        {step === 2 && (
          <div className="space-y-3">
            <div className="grid gap-2">
              {ARCHETYPES.map((a) => {
                const p = getProtocol(a)
                return (
                  <ToggleChip key={a} selected={archetype === a} onClick={() => setArchetype(a)}>
                    <span className="block font-medium text-bone">{p.label}</span>
                    <span className="text-xs text-muted">
                      Esquema {p.repScheme.join('-')} · LOP {p.lopPercent[0]}–{p.lopPercent[1]}%
                    </span>
                  </ToggleChip>
                )
              })}
            </div>
            {archetype === 'sport_specific' && (
              <div>
                <Label>{t('settings.sport')}</Label>
                <Input value={sport} onChange={(e) => setSport(e.target.value)} />
              </div>
            )}
            <div>
              <Label>{t('settings.milestoneSessions')}</Label>
              <Input
                type="number"
                min={4}
                max={24}
                value={weekCount}
                onChange={(e) => setWeekCount(Number(e.target.value))}
              />
            </div>
          </div>
        )}

        {step === 3 && (
          <div className="space-y-4">
            <p className="text-sm text-ghost">{t('onboarding.kitHint')}</p>
            <div>
              <p className="mb-2 text-sm text-ghost">{t('onboarding.stepKit')}</p>
              <div className="grid grid-cols-2 gap-2">
                {GARMENT_IDS.map((id) => (
                  <ToggleChip
                    key={id}
                    selected={garments.includes(id)}
                    onClick={() =>
                      setGarments((prev) =>
                        prev.includes(id) ? prev.filter((x) => x !== id) : [...prev, id],
                      )
                    }
                  >
                    {garmentLabel(id)}
                  </ToggleChip>
                ))}
              </div>
            </div>
            <div>
              <p className="mb-2 text-sm text-ghost">{t('settings.sectionKit')}</p>
              <div className="grid grid-cols-2 gap-2">
                {EQUIPMENT_IDS.map((id) => (
                  <ToggleChip
                    key={id}
                    selected={equipment.includes(id)}
                    onClick={() =>
                      setEquipment((prev) => {
                        if (id === 'bodyweight')
                          return prev.includes('bodyweight') ? prev : [...prev, 'bodyweight']
                        return prev.includes(id)
                          ? prev.filter((x) => x !== id)
                          : [...prev, id]
                      })
                    }
                  >
                    {equipmentLabel(id)}
                  </ToggleChip>
                ))}
              </div>
            </div>
          </div>
        )}

        {step === 4 && (
          <div className="space-y-3">
            <p className="text-sm text-ghost">{t('onboarding.wearablesHint')}</p>
            <div className="grid gap-2">
              {WEARABLE_IDS.map((id) => {
                const device = state.devices.find((d) => d.provider === id)
                const connected = device?.status !== 'disconnected'
                return (
                  <ToggleChip key={id} selected={!!connected} onClick={() => toggleDevice(id)}>
                    <span className="flex items-center justify-between gap-2">
                      <span>{id.replace('_', ' ')}</span>
                      <span className="text-xs text-muted">
                        {connected ? t('settings.deviceMockOn') : t('settings.deviceOff')}
                      </span>
                    </span>
                  </ToggleChip>
                )
              })}
            </div>
          </div>
        )}
      </div>

      <div className="mt-8 flex gap-2">
        <Button
          variant="secondary"
          className="flex-1"
          disabled={step === 0}
          onClick={() => setOnboardingStep(Math.max(0, step - 1))}
        >
          {t('onboarding.back')}
        </Button>
        <Button className="flex-1" disabled={!canContinue} onClick={goNext}>
          {step === 4 ? t('onboarding.finish') : t('onboarding.next')}
        </Button>
      </div>

      {step === 4 && (
        <Button
          variant="ghost"
          className="mt-2 w-full"
          onClick={() => {
            completeOnboarding()
            navigate('/app/home')
          }}
        >
          {t('onboarding.skipWearables')}
        </Button>
      )}

      {blockedModal && (
        <div className="fixed inset-0 z-50 flex items-end justify-center bg-black/70 p-4 sm:items-center">
          <Panel className="w-full max-w-md border-arterial/50">
            <h2 className="text-lg font-semibold text-arterial">{t('banner.blockedTitle')}</h2>
            <p className="mt-2 text-sm text-ghost">{t('banner.blockedBody')}</p>
            <div className="mt-4 flex gap-2">
              <Button
                variant="secondary"
                className="flex-1"
                onClick={() => setBlockedModal(false)}
              >
                {t('onboarding.back')}
              </Button>
              <Button
                variant="danger"
                className="flex-1"
                onClick={() => {
                  setBlockedModal(false)
                  setOnboardingStep(2)
                }}
              >
                {t('onboarding.next')}
              </Button>
            </div>
          </Panel>
        </div>
      )}
    </div>
  )
}
