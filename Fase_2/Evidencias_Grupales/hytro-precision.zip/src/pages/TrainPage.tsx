import { useMemo, useState } from 'react'
import { useNavigate } from 'react-router-dom'
import { EXERCISES, filterExercisesForEquipment, rankByGoal } from '../data/exercises'
import { Badge, Button, Panel } from '../components/ui'
import { useI18n } from '../i18n'
import { getProtocol } from '../lib/protocols'
import { useApp } from '../store/AppContext'
import type { MuscleGroup } from '../types'
import { cn } from '../lib/utils'

const ZONES: { id: MuscleGroup; top: string; left: string; w: string; h: string }[] = [
  { id: 'shoulders', top: '12%', left: '28%', w: '44%', h: '8%' },
  { id: 'chest', top: '20%', left: '32%', w: '36%', h: '12%' },
  { id: 'arms', top: '22%', left: '12%', w: '16%', h: '28%' },
  { id: 'back', top: '22%', left: '72%', w: '16%', h: '28%' },
  { id: 'core', top: '34%', left: '34%', w: '32%', h: '14%' },
  { id: 'quads', top: '52%', left: '30%', w: '40%', h: '18%' },
  { id: 'posterior', top: '72%', left: '30%', w: '40%', h: '16%' },
]

export function TrainPage() {
  const { state, selectExercise, blocked } = useApp()
  const { t } = useI18n()
  const navigate = useNavigate()
  const [selected, setSelected] = useState<MuscleGroup | null>(null)
  const archetype = state.goal?.archetype ?? 'general_fitness'
  const protocol = getProtocol(archetype)

  const muscleLabel = (id: MuscleGroup) => t(`body.${id}`)

  const list = useMemo(() => {
    if (!selected) return []
    const filtered = filterExercisesForEquipment(
      EXERCISES,
      state.equipment?.equipment ?? ['bodyweight'],
    ).filter((e) => e.muscleGroup === selected)
    return rankByGoal(filtered, archetype)
  }, [selected, state.equipment.equipment, archetype])

  return (
    <div className="space-y-4 animate-slide-up">
      <div>
        <h2 className="text-xl font-semibold">{t('body.title')}</h2>
        <p className="text-sm text-ghost">
          {t('body.subtitle', { goal: protocol.shortLabel })}
        </p>
      </div>

      <Panel className="relative mx-auto aspect-[3/5] max-w-xs overflow-hidden bg-gradient-to-b from-[#1a2330] to-[#0d1117]">
        <div className="pointer-events-none absolute inset-6 rounded-[40%] border border-plasma/20" />
        <div className="pointer-events-none absolute left-1/2 top-[8%] h-[10%] w-[22%] -translate-x-1/2 rounded-full border border-white/20" />
        {ZONES.map((z) => {
          const priority = EXERCISES.filter((e) => e.muscleGroup === z.id).reduce(
            (max, e) => Math.max(max, e.goalRelevance[archetype]),
            0,
          )
          const stars = priority >= 9 ? '★★★' : priority >= 7 ? '★★' : '★'
          return (
            <button
              key={z.id}
              type="button"
              onClick={() => setSelected(z.id)}
              className={cn(
                'absolute rounded-2xl border transition',
                selected === z.id
                  ? 'border-plasma bg-plasma/30 shadow-[0_0_24px_rgba(0,212,255,0.35)]'
                  : 'border-plasma/30 bg-plasma/10 hover:bg-plasma/20',
              )}
              style={{ top: z.top, left: z.left, width: z.w, height: z.h }}
              aria-label={muscleLabel(z.id)}
            >
              <span className="block text-center text-[9px] leading-tight text-plasma">
                {muscleLabel(z.id)}
                <br />
                <span className="text-bio">{stars}</span>
              </span>
            </button>
          )
        })}
      </Panel>

      {selected && (
        <div className="fixed inset-x-0 bottom-16 z-40 mx-auto max-w-lg px-4">
          <Panel className="max-h-[45vh] overflow-auto border-plasma/40 shadow-2xl">
            <div className="mb-3 flex items-start justify-between gap-2">
              <div>
                <p className="font-medium">{muscleLabel(selected)}</p>
                <div className="mt-1 flex flex-wrap gap-2">
                  <Badge>
                    {t('body.protocol', { scheme: protocol.repScheme.join('-') })}
                  </Badge>
                  <Badge tone="muted">
                    {t('body.cuff', {
                      zone:
                        list[0]?.cuffZone === 'upper_body'
                          ? t('body.cuffArm')
                          : t('body.cuffThigh'),
                    })}
                  </Badge>
                </div>
              </div>
              <Button size="sm" variant="ghost" onClick={() => setSelected(null)}>
                {t('body.close')}
              </Button>
            </div>
            {list.length === 0 ? (
              <p className="text-sm text-muted">{t('body.empty')}</p>
            ) : (
              <ul className="space-y-2">
                {list.map((ex) => (
                  <li key={ex.id} className="rounded-xl border border-border px-3 py-2">
                    <div className="flex items-center justify-between gap-2">
                      <div>
                        <p className="text-sm font-medium">{ex.name}</p>
                        <p className="text-xs text-ghost">
                          {t('body.relevance', {
                            score: ex.goalRelevance[archetype],
                            diff: ex.difficulty,
                          })}
                        </p>
                      </div>
                      <Button
                        size="sm"
                        disabled={blocked}
                        onClick={() => {
                          selectExercise(ex.id)
                          navigate('/app/cuff')
                        }}
                      >
                        {t('body.start')}
                      </Button>
                    </div>
                  </li>
                ))}
              </ul>
            )}
          </Panel>
        </div>
      )}
    </div>
  )
}
