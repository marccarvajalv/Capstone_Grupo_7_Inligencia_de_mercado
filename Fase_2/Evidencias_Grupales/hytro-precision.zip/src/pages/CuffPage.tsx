import { useEffect, useRef, useState } from 'react'
import { useNavigate } from 'react-router-dom'
import { Badge, Button, Panel } from '../components/ui'
import { useI18n } from '../i18n'
import { assessProximalZoneLocal } from '../lib/aiPose'
import { playSafetyBeep } from '../lib/safetyAudio'
import { useApp } from '../store/AppContext'
import type { CrtAssessment, LimbType, ZoneStatus } from '../types'
import { cn } from '../lib/utils'

export function CuffPage() {
  const { addCuffCheck, blocked, state } = useApp()
  const { t } = useI18n()
  const navigate = useNavigate()
  const [step, setStep] = useState(0)
  const [limb, setLimb] = useState<LimbType>('left_arm')
  const [zoneStatus, setZoneStatus] = useState<ZoneStatus | null>(null)
  const [crtPhase, setCrtPhase] = useState<'idle' | 'press' | 'wait' | 'done'>('idle')
  const [crtSeconds, setCrtSeconds] = useState<number | null>(null)
  const [crtAssessment, setCrtAssessment] = useState<CrtAssessment | null>(null)
  const pressStarted = useRef<number | null>(null)
  const videoRef = useRef<HTMLVideoElement>(null)
  const [camError, setCamError] = useState(false)

  const limbs: { id: LimbType; label: string }[] = [
    { id: 'left_arm', label: t('cuff.leftArm') },
    { id: 'right_arm', label: t('cuff.rightArm') },
    { id: 'left_leg', label: t('cuff.leftLeg') },
    { id: 'right_leg', label: t('cuff.rightLeg') },
  ]

  useEffect(() => {
    let stream: MediaStream | null = null
    if (step !== 1) return
    navigator.mediaDevices
      ?.getUserMedia({ video: { facingMode: 'environment' }, audio: false })
      .then((s) => {
        stream = s
        if (videoRef.current) {
          videoRef.current.srcObject = s
          void videoRef.current.play()
        }
      })
      .catch(() => setCamError(true))
    return () => {
      stream?.getTracks().forEach((tr) => tr.stop())
    }
  }, [step])

  const assessCrt = (seconds: number): CrtAssessment => {
    if (seconds < 3) return 'too_loose'
    if (seconds <= 10) return 'ideal'
    return 'danger'
  }

  const finish = (assessment: CrtAssessment, seconds: number, zone: ZoneStatus) => {
    addCuffCheck({
      limbType: limb,
      zoneStatus: zone,
      crtSeconds: seconds,
      crtAssessment: assessment,
      garmentId: state.equipment?.garments?.[0],
    })
    setCrtAssessment(assessment)
    setCrtSeconds(seconds)
    setCrtPhase('done')
    setStep(3)
    if (assessment === 'danger') playSafetyBeep(3)
  }

  const zoneLabel =
    zoneStatus === 'in_safe_zone'
      ? t('cuff.zoneSafe')
      : zoneStatus === 'too_low'
        ? t('cuff.zoneLow')
        : t('cuff.zoneNone')

  const crtLabel =
    crtAssessment === 'ideal'
      ? t('cuff.crtIdeal')
      : crtAssessment === 'too_loose'
        ? t('cuff.crtLoose')
        : t('cuff.crtDanger')

  return (
    <div className={cn('animate-slide-up', step === 1 && '-mx-4 -mt-4')}>
      {step === 0 && (
        <div className="space-y-4 px-0">
          <h2 className="text-xl font-semibold">{t('cuff.title')}</h2>
          <p className="text-sm text-ghost">{t('cuff.intro')}</p>
          <div className="grid grid-cols-2 gap-2">
            {limbs.map((l) => (
              <button
                key={l.id}
                type="button"
                onClick={() => setLimb(l.id)}
                className={cn(
                  'rounded-xl border px-3 py-3 text-sm',
                  limb === l.id ? 'border-plasma bg-plasma/15' : 'border-border',
                )}
              >
                {l.label}
              </button>
            ))}
          </div>
          <Button className="w-full" onClick={() => setStep(1)}>
            {t('cuff.openCamera')}
          </Button>
        </div>
      )}

      {step === 1 && (
        <div className="relative min-h-[80dvh] bg-black">
          {!camError ? (
            <video
              ref={videoRef}
              className="absolute inset-0 h-full w-full object-cover"
              muted
              playsInline
            />
          ) : (
            <div className="absolute inset-0 bg-gradient-to-b from-[#1b2430] to-black" />
          )}
          <div className="absolute inset-0 bg-black/35" />
          <div className="absolute left-1/2 top-[18%] h-[55%] w-[42%] -translate-x-1/2 rounded-[40%] border-2 border-dashed border-white/50" />
          <div className="absolute left-[20%] right-[20%] h-0.5 bg-plasma/80 animate-scan shadow-[0_0_12px_#00D4FF]" />
          <div className="absolute left-[22%] top-[22%] h-[12%] w-[18%] rounded-lg border-2 border-bio bg-bio/20" />
          <p className="absolute left-4 top-4 rounded-lg bg-black/50 px-2 py-1 text-xs text-bio">
            {t('cuff.safeZone')}
          </p>
          {camError && (
            <p className="absolute inset-x-4 top-16 text-center text-sm text-ghost">
              {t('cuff.camUnavailable')}
            </p>
          )}
          <div className="absolute inset-x-4 bottom-6 space-y-2">
            <p className="text-center text-sm text-bone">{t('cuff.zoneQuestion')}</p>
            <div className="grid grid-cols-3 gap-2">
              <Button
                variant="secondary"
                onClick={() => {
                  const ai = assessProximalZoneLocal({ proximalScore: 0.86 })
                  setZoneStatus(ai.zoneStatus as ZoneStatus)
                  setStep(2)
                }}
              >
                {t('cuff.yes')}
              </Button>
              <Button
                variant="outline"
                onClick={() => {
                  const ai = assessProximalZoneLocal({ proximalScore: 0.5 })
                  setZoneStatus(ai.zoneStatus as ZoneStatus)
                  setStep(2)
                }}
              >
                {t('cuff.tooLow')}
              </Button>
              <Button
                variant="ghost"
                onClick={() => {
                  const ai = assessProximalZoneLocal({ proximalScore: 0.2 })
                  setZoneStatus(ai.zoneStatus as ZoneStatus)
                  setStep(2)
                }}
              >
                {t('cuff.cantSee')}
              </Button>
              <Button
                className="col-span-3"
                variant="outline"
                onClick={() => {
                  const score = 0.55 + Math.random() * 0.4
                  const ai = assessProximalZoneLocal({ proximalScore: score })
                  setZoneStatus(ai.zoneStatus as ZoneStatus)
                  setStep(2)
                }}
              >
                {t('cuff.autoAi')}
              </Button>
            </div>
          </div>
        </div>
      )}

      {step === 2 && zoneStatus && (
        <div className="space-y-4">
          <h2 className="text-xl font-semibold">{t('cuff.crtTitle')}</h2>
          <p className="text-sm text-ghost">{t('cuff.crtHint')}</p>
          <Panel className="flex min-h-48 flex-col items-center justify-center">
            {crtPhase === 'idle' && (
              <Button
                size="lg"
                onClick={() => {
                  setCrtPhase('press')
                  pressStarted.current = null
                }}
              >
                {t('cuff.startCrt')}
              </Button>
            )}
            {crtPhase === 'press' && (
              <button
                type="button"
                className="flex h-36 w-36 items-center justify-center rounded-full border-4 border-plasma bg-plasma/20 text-sm"
                onPointerDown={() => {
                  pressStarted.current = performance.now()
                }}
                onPointerUp={() => {
                  setCrtPhase('wait')
                  pressStarted.current = performance.now()
                }}
              >
                {t('cuff.pressing')}
              </button>
            )}
            {crtPhase === 'wait' && (
              <button
                type="button"
                className="flex h-36 w-36 animate-pulse-ring items-center justify-center rounded-full border-4 border-bio bg-bio/20 text-center text-sm"
                onClick={() => {
                  const start = pressStarted.current ?? performance.now()
                  const seconds = Math.max(0.5, (performance.now() - start) / 1000)
                  const assessment = assessCrt(seconds)
                  finish(assessment, Number(seconds.toFixed(1)), zoneStatus)
                }}
              >
                {t('cuff.releaseTap')}
              </button>
            )}
          </Panel>
        </div>
      )}

      {step === 3 && crtAssessment && (
        <div className="space-y-4">
          <h2 className="text-xl font-semibold">{t('cuff.resultTitle')}</h2>
          <Panel>
            <Badge
              tone={
                crtAssessment === 'ideal'
                  ? 'bio'
                  : crtAssessment === 'danger'
                    ? 'arterial'
                    : 'plasma'
              }
            >
              {crtLabel}
            </Badge>
            <p className="num mt-3 text-3xl">
              {t('cuff.crt', { seconds: crtSeconds ?? 0, assessment: crtLabel })}
            </p>
            <p className="mt-2 text-sm text-ghost">{t('cuff.zone', { status: zoneLabel })}</p>
          </Panel>
          <div className="flex gap-2">
            <Button
              variant="secondary"
              className="flex-1"
              onClick={() => {
                setStep(0)
                setCrtPhase('idle')
                setZoneStatus(null)
                setCrtAssessment(null)
              }}
            >
              {t('cuff.repeat')}
            </Button>
            <Button
              className="flex-1"
              disabled={crtAssessment === 'danger' || blocked}
              onClick={() => navigate('/app/workout')}
            >
              {t('cuff.goWorkout')}
            </Button>
          </div>
        </div>
      )}
    </div>
  )
}
