import { useEffect, useMemo, useState } from 'react'
import { useNavigate, useSearchParams } from 'react-router-dom'
import { EXERCISES } from '../data/exercises'
import { Badge, Button, Panel } from '../components/ui'
import { useI18n } from '../i18n'
import {
  FINISHER_SECONDS,
  OCCLUSION_LIMIT_SECONDS,
  OCCLUSION_WARN_SECONDS,
  PROTEIN_WINDOW_SECONDS,
  getProtocol,
} from '../lib/protocols'
import { estimateLopMmHg, recommendedPressureForGoal } from '../lib/lop'
import { playSafetyBeep } from '../lib/safetyAudio'
import { clamp, formatDuration } from '../lib/utils'
import { useApp } from '../store/AppContext'
import type { WorkoutSet } from '../types'

const CRT_DANGER_SECONDS = 10

const TEMPO_PHASES = 4

export function WorkoutPage() {
  const { state, blocked, addSession, startProteinWindow, selectExercise } = useApp()
  const { t } = useI18n()
  const [params] = useSearchParams()
  const navigate = useNavigate()
  const isFinisher = params.get('finisher') === '1'

  const exercise =
    EXERCISES.find((e) => e.id === state.selectedExerciseId) ??
    EXERCISES.find((e) => e.muscleGroup === 'quads') ??
    EXERCISES[0]

  const archetype = state.goal?.archetype ?? 'general_fitness'
  const protocol = getProtocol(archetype)

  const pressure = useMemo(() => {
    const circ =
      exercise.cuffZone === 'upper_body'
        ? state.profile?.limbCircumferences.leftArmCm ?? 32
        : state.profile?.limbCircumferences.leftLegCm ?? 55
    const lop = estimateLopMmHg({
      systolic: state.profile?.systolicMmHg ?? 120,
      diastolic: state.profile?.diastolicMmHg ?? 80,
      circumferenceCm: circ,
      limbType: exercise.cuffZone,
    })
    return recommendedPressureForGoal(lop.lopMmHg, archetype)
  }, [exercise, state.profile, archetype])

  const [running, setRunning] = useState(false)
  const [setIndex, setSetIndex] = useState(0)
  const [reps, setReps] = useState(0)
  const [tempoPhase, setTempoPhase] = useState(0)
  const [, setPhaseMs] = useState(0)
  const [elapsed, setElapsed] = useState(0)
  const [restLeft, setRestLeft] = useState(0)
  const [tension, setTension] = useState(70)
  const [hr, setHr] = useState(110)
  const [setsLog, setSetsLog] = useState<WorkoutSet[]>([])
  const [setStartedAt, setSetStartedAt] = useState<number | null>(null)
  const [done, setDone] = useState(false)
  const [warn18, setWarn18] = useState(false)
  const [crtBlocked, setCrtBlocked] = useState(false)
  const [hrAlert, setHrAlert] = useState(false)

  const targets = isFinisher ? [999] : protocol.repScheme
  const targetReps = targets[setIndex] ?? targets[targets.length - 1]
  const maxHr = Math.round(220 - 30)
  const hrDanger = hr >= maxHr * 0.8
  const lastCrt = state.cuffChecks[0]?.crtSeconds
  const crtIsDanger =
    state.cuffChecks[0]?.crtAssessment === 'danger' ||
    (typeof lastCrt === 'number' && lastCrt > CRT_DANGER_SECONDS)

  useEffect(() => {
    if (!running || done) return
    let acc = 0
    const id = window.setInterval(() => {
      acc += 250
      setHr((h) => clamp(h + (Math.random() * 4 - 1.5), 90, maxHr))
      setTension((tn) => clamp(tn + (Math.random() * 6 - 2.5), 25, 98))
      if (acc >= 1000) {
        acc = 0
        setElapsed((e) => e + 1)
        setRestLeft((r) => (r > 0 ? r - 1 : 0))
      }
      if (restLeft > 0) return
      if (!isFinisher) {
        setPhaseMs((ms) => {
          const next = ms + 250
          const limit = protocol.tempoSeconds[tempoPhase] * 1000
          if (next >= limit) {
            setTempoPhase((p) => (p + 1) % TEMPO_PHASES)
            return 0
          }
          return next
        })
      }
    }, 250)
    return () => window.clearInterval(id)
  }, [running, done, restLeft, tempoPhase, protocol.tempoSeconds, isFinisher, maxHr])

  useEffect(() => {
    if (elapsed === OCCLUSION_WARN_SECONDS) setWarn18(true)
    if (elapsed >= OCCLUSION_LIMIT_SECONDS && running) {
      finishWorkout(true)
    }
    if (isFinisher && elapsed >= FINISHER_SECONDS && running) {
      finishWorkout(false)
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [elapsed])

  useEffect(() => {
    if (hrDanger && running) {
      setHrAlert(true)
      playSafetyBeep(3)
    }
  }, [hrDanger, running])

  const tensionTone =
    tension > 80 ? 'text-bio' : tension >= 40 ? 'text-plasma' : 'text-arterial'

  function commitSet(nextRest: number) {
    const duration = setStartedAt
      ? Math.max(1, Math.round((Date.now() - setStartedAt) / 1000))
      : 30
    const entry: WorkoutSet = {
      setNumber: setIndex + 1,
      reps,
      durationSeconds: duration,
      restSeconds: nextRest,
      targetReps: isFinisher ? reps : targetReps,
    }
    setSetsLog((prev) => [...prev, entry])
    return entry
  }

  function finishWorkout(forced = false) {
    setRunning(false)
    setDone(true)
    const finalSets =
      setsLog.length > 0
        ? setsLog
        : [
            {
              setNumber: 1,
              reps,
              durationSeconds: elapsed || 1,
              restSeconds: 0,
              targetReps: isFinisher ? reps : targetReps,
            },
          ]
    addSession({
      exerciseId: exercise.id,
      exerciseName: isFinisher ? t('workout.finisherSessionName') : exercise.name,
      muscleGroup: exercise.muscleGroup,
      sets: finalSets,
      totalDurationSeconds: elapsed || 1,
      avgHeartRate: Math.round(hr),
      maxHeartRate: Math.round(Math.max(hr, maxHr * 0.7)),
      avgTensionScore: Math.round(tension),
      pressureMmhg: pressure.targetMmHg,
      crtSeconds: state.cuffChecks[0]?.crtSeconds,
      type: isFinisher ? 'finisher' : 'standard',
      goalArchetype: archetype,
    })
    startProteinWindow(PROTEIN_WINDOW_SECONDS)
    if (forced) setWarn18(true)
  }

  if (blocked) {
    return (
      <Panel>
        <h2 className="text-lg font-semibold text-arterial">{t('workout.blockedTitle')}</h2>
        <p className="mt-2 text-sm text-ghost">{t('workout.blockedBody')}</p>
        <Button className="mt-4" onClick={() => navigate('/app/settings')}>
          {t('workout.goScreening')}
        </Button>
      </Panel>
    )
  }

  if (done) {
    return (
      <div className="space-y-4 animate-slide-up">
        <h2 className="text-xl font-semibold">{t('workout.sessionLogged')}</h2>
        <Panel>
          <p className="text-sm text-ghost">{isFinisher ? t('workout.finisher') : exercise.name}</p>
          <p className="num mt-2 text-3xl">{formatDuration(elapsed)}</p>
          <p className="mt-2 text-sm">
            {t('workout.summarySets', {
              sets: setsLog.length || 1,
              tension: Math.round(tension),
              pressure: pressure.targetMmHg,
            })}
          </p>
          <p className="mt-2 text-sm text-bio">{t('workout.proteinWindow')}</p>
        </Panel>
        <Button
          className="w-full"
          onClick={() => {
            selectExercise(null)
            navigate('/app/progress')
          }}
        >
          {t('workout.viewProgress')}
        </Button>
      </div>
    )
  }

  return (
    <div className="space-y-4 animate-slide-up">
      <div className="flex items-start justify-between gap-2">
        <div>
          <h2 className="text-xl font-semibold">
            {isFinisher ? t('workout.finisherTitle') : exercise.name}
          </h2>
          <p className="text-sm text-ghost">
            {protocol.label} · {pressure.percentLabel}
          </p>
        </div>
        <Badge tone={hrDanger ? 'arterial' : 'plasma'}>
          {t('workout.hr', { hr: Math.round(hr) })}
        </Badge>
      </div>

      {(crtBlocked || crtIsDanger) && (
        <Panel className="border-arterial/50 bg-arterial/10">
          <p className="text-sm text-arterial">
            {t('workout.crtDanger', { seconds: CRT_DANGER_SECONDS })}
          </p>
        </Panel>
      )}
      {hrAlert && (
        <Panel className="border-arterial/50 bg-arterial/10">
          <p className="text-sm text-arterial">{t('workout.hrAlert', { maxHr })}</p>
        </Panel>
      )}
      {warn18 && (
        <Panel className="border-arterial/50 bg-arterial/10">
          <p className="text-sm text-arterial">{t('workout.occlusionWarn')}</p>
        </Panel>
      )}
      <p className="text-[11px] text-muted">{t('workout.lopDisclaimer')}</p>

      <Panel className="flex flex-col items-center py-6">
        <div className="relative flex h-40 w-40 items-center justify-center">
          <svg className="absolute inset-0 -rotate-90" viewBox="0 0 100 100">
            <circle cx="50" cy="50" r="42" stroke="var(--hytro-border)" strokeWidth="8" fill="none" />
            <circle
              cx="50"
              cy="50"
              r="42"
              stroke={tension > 80 ? 'var(--hytro-bio)' : tension >= 40 ? 'var(--hytro-plasma)' : 'var(--hytro-arterial)'}
              strokeWidth="8"
              fill="none"
              strokeDasharray={`${(tension / 100) * 264} 264`}
              strokeLinecap="round"
            />
          </svg>
          <div className="text-center">
            <p className={`num text-3xl ${tensionTone}`}>{Math.round(tension)}</p>
            <p className="text-[10px] text-muted">{t('workout.tension')}</p>
          </div>
        </div>
        <p className="num mt-4 text-4xl text-bone">{formatDuration(elapsed)}</p>
        <p className="text-xs text-muted">
          {t('workout.targetPressure', {
            target: pressure.targetMmHg,
            min: pressure.minMmHg,
            max: pressure.maxMmHg,
          })}
        </p>
      </Panel>

      {!isFinisher && (
        <Panel>
          <div className="mb-2 flex items-center justify-between text-sm">
            <span>
              {t('workout.setLabel', {
                current: setIndex + 1,
                total: protocol.repScheme.length,
              })}
            </span>
            <span className="num">
              {t('workout.reps', { reps, target: targetReps })}
            </span>
          </div>
          <div className="grid grid-cols-4 gap-2">
            {protocol.tempoLabels.map((label, i) => (
              <div
                key={label + i}
                className={`rounded-lg border px-2 py-3 text-center text-xs ${
                  running && restLeft === 0 && tempoPhase === i
                    ? 'border-plasma bg-plasma/20 text-plasma'
                    : 'border-border text-muted'
                }`}
              >
                {label}
                <div className="num mt-1 text-bone">{protocol.tempoSeconds[i]}s</div>
              </div>
            ))}
          </div>
          {restLeft > 0 && (
            <p className="mt-3 text-center text-sm text-plasma">
              {t('workout.rest', { seconds: restLeft })}
            </p>
          )}
        </Panel>
      )}

      <div className="grid grid-cols-2 gap-2">
        {!running ? (
          <Button
            className="col-span-2"
            size="lg"
            disabled={crtBlocked}
            onClick={() => {
              if (crtIsDanger) {
                setCrtBlocked(true)
                playSafetyBeep(3)
                return
              }
              setCrtBlocked(false)
              setRunning(true)
              setSetStartedAt(Date.now())
            }}
          >
            {t('workout.start')}
          </Button>
        ) : (
          <>
            {!isFinisher && (
              <Button
                variant="secondary"
                onClick={() => setReps((r) => r + 1)}
                disabled={restLeft > 0}
              >
                {t('workout.plusRep')}
              </Button>
            )}
            {!isFinisher && (
              <Button
                variant="outline"
                disabled={restLeft > 0}
                onClick={() => {
                  commitSet(protocol.restSeconds)
                  if (setIndex >= protocol.repScheme.length - 1) {
                    finishWorkout()
                    return
                  }
                  setSetIndex((i) => i + 1)
                  setReps(0)
                  setRestLeft(protocol.restSeconds)
                  setSetStartedAt(Date.now())
                }}
              >
                {t('workout.nextSet')}
              </Button>
            )}
            <Button
              variant="danger"
              className="col-span-2"
              onClick={() => finishWorkout()}
            >
              {t('workout.finish')}
            </Button>
          </>
        )}
      </div>
    </div>
  )
}
