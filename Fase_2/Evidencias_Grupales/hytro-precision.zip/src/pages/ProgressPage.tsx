import { useMemo, useState } from 'react'
import { Link } from 'react-router-dom'
import { Badge, Button, Input, Label, Panel, ProgressBar, SectionTitle } from '../components/ui'
import { useI18n } from '../i18n'
import { estimateLopMmHg, recommendedPressureForGoal } from '../lib/lop'
import { getProtocol } from '../lib/protocols'
import { useApp } from '../store/AppContext'
import type { LimbRegion } from '../types'

export function ProgressPage() {
  const { state } = useApp()
  const { t, locale } = useI18n()
  const archetype = state.goal?.archetype ?? 'general_fitness'
  const protocol = getProtocol(archetype)
  const [detailId, setDetailId] = useState<string | null>(null)

  const stats = useMemo(() => {
    const sessions = state.sessions
    const totalVolume = sessions.reduce(
      (sum, s) => sum + s.sets.reduce((a, set) => a + set.reps, 0),
      0,
    )
    const avgTempo =
      sessions.length === 0
        ? 0
        : Math.round(
            sessions.reduce((sum, s) => sum + (s.avgTensionScore || 0), 0) / sessions.length,
          )
    const formAccuracy =
      sessions.length === 0
        ? 0
        : Math.round(
            sessions.reduce((sum, s) => {
              const hit = s.sets.filter((set) => set.reps >= set.targetReps * 0.9).length
              return sum + (s.sets.length ? (hit / s.sets.length) * 100 : 0)
            }, 0) / sessions.length,
          )
    return {
      totalSessions: sessions.length,
      totalVolume,
      avgTempo,
      formAccuracy,
    }
  }, [state.sessions])

  const target = state.goal?.milestones[0]?.targetValue ?? 16
  const progressPct = Math.min(100, Math.round((stats.totalSessions / target) * 100))
  const detail = state.sessions.find((s) => s.id === detailId)

  const [sys, setSys] = useState(state.profile?.systolicMmHg ?? 120)
  const [dia, setDia] = useState(state.profile?.diastolicMmHg ?? 80)
  const [circ, setCirc] = useState(state.profile?.limbCircumferences.leftArmCm ?? 32)
  const [limb, setLimb] = useState<LimbRegion>('upper_body')
  const lop = estimateLopMmHg({
    systolic: sys,
    diastolic: dia,
    circumferenceCm: circ,
    limbType: limb,
  })
  const rec = recommendedPressureForGoal(lop.lopMmHg, archetype)

  return (
    <div className="space-y-4 animate-slide-up">
      <SectionTitle
        title={t('progress.title')}
        subtitle={t('progress.protocol', { label: protocol.shortLabel })}
      />

      <Panel>
        <div className="flex items-center justify-between">
          <p className="text-sm text-ghost">{t('progress.goalProgress')}</p>
          <span className="num text-plasma">{progressPct}%</span>
        </div>
        <div className="mt-2">
          <ProgressBar value={progressPct} />
        </div>
        <p className="mt-2 text-xs text-muted">
          {state.goal?.milestones[0]?.description ?? t('progress.sessionsMilestone')} ·{' '}
          {stats.totalSessions}/{target}
        </p>
      </Panel>

      <div className="grid grid-cols-2 gap-2">
        {[
          [t('progress.sessions'), stats.totalSessions],
          [t('progress.volume'), stats.totalVolume],
          [t('progress.avgTension'), `${stats.avgTempo}%`],
          [t('progress.formAccuracy'), `${stats.formAccuracy}%`],
        ].map(([label, value]) => (
          <Panel key={label as string}>
            <p className="text-xs text-muted">{label}</p>
            <p className="num mt-1 text-2xl">{value}</p>
          </Panel>
        ))}
      </div>

      <Panel>
        <div className="mb-3 flex items-center justify-between">
          <p className="font-medium">{t('progress.lopTitle')}</p>
          <Badge>Loenneke</Badge>
        </div>
        <div className="grid grid-cols-2 gap-2">
          <div>
            <Label>{t('progress.sbp')}</Label>
            <Input type="number" value={sys} onChange={(e) => setSys(Number(e.target.value))} />
          </div>
          <div>
            <Label>{t('progress.dbp')}</Label>
            <Input type="number" value={dia} onChange={(e) => setDia(Number(e.target.value))} />
          </div>
          <div>
            <Label>{t('progress.circumference')}</Label>
            <Input type="number" value={circ} onChange={(e) => setCirc(Number(e.target.value))} />
          </div>
          <div>
            <Label>{t('progress.limb')}</Label>
            <select
              className="h-11 w-full rounded-xl border border-border bg-bg-panel px-3"
              value={limb}
              onChange={(e) => setLimb(e.target.value as LimbRegion)}
            >
              <option value="upper_body">{t('progress.upper')}</option>
              <option value="lower_body">{t('progress.lower')}</option>
            </select>
          </div>
        </div>
        <div className="mt-4 rounded-xl border border-plasma/30 bg-plasma/10 p-3">
          <p className="text-sm text-ghost">{t('progress.estimatedLop')}</p>
          <p className="num text-3xl text-plasma">{lop.lopMmHg} mmHg</p>
          <p className="mt-1 text-sm">
            {t('progress.recommended')}: {rec.targetMmHg} mmHg ({rec.percentLabel})
          </p>
          <p className="mt-2 text-xs text-muted">{lop.disclaimer}</p>
        </div>
      </Panel>

      <Panel>
        <p className="mb-2 font-medium">{t('progress.history')}</p>
        {state.sessions.length === 0 ? (
          <p className="text-sm text-muted">{t('progress.noSessions')}</p>
        ) : (
          <ul className="space-y-2">
            {state.sessions.map((s) => (
              <li key={s.id}>
                <button
                  type="button"
                  className="flex w-full items-center justify-between rounded-xl border border-border px-3 py-2 text-left text-sm hover:border-plasma/40"
                  onClick={() => setDetailId(s.id)}
                >
                  <span>
                    {s.exerciseName}
                    <span className="mt-0.5 block text-xs text-muted">
                      {new Date(s.createdAt).toLocaleString(locale)}
                    </span>
                  </span>
                  <span className="num text-ghost">{Math.round(s.totalDurationSeconds / 60)}m</span>
                </button>
              </li>
            ))}
          </ul>
        )}
      </Panel>

      <Panel>
        <p className="mb-2 font-medium">{t('cuff.title')}</p>
        {state.cuffChecks.length === 0 ? (
          <p className="text-sm text-muted">{t('progress.noSessions')}</p>
        ) : (
          <ul className="space-y-2 text-sm">
            {state.cuffChecks.slice(0, 5).map((c) => (
              <li key={c.id} className="flex justify-between">
                <span>{c.limbType.replace('_', ' ')}</span>
                <Badge
                  tone={
                    c.crtAssessment === 'ideal'
                      ? 'bio'
                      : c.crtAssessment === 'danger'
                        ? 'arterial'
                        : 'plasma'
                  }
                >
                  {c.crtAssessment ?? c.zoneStatus}
                </Badge>
              </li>
            ))}
          </ul>
        )}
        <Link to="/app/cuff" className="mt-3 inline-block text-sm text-plasma">
          Nuevo Cuff Check →
        </Link>
      </Panel>

      {detail && (
        <div className="fixed inset-0 z-50 flex items-end bg-black/70 p-4 sm:items-center sm:justify-center">
          <Panel className="w-full max-w-md">
            <h3 className="font-semibold">{detail.exerciseName}</h3>
            <p className="text-xs text-muted">{new Date(detail.createdAt).toLocaleString(locale)}</p>
            <ul className="mt-3 space-y-2 text-sm">
              {detail.sets.map((set) => (
                <li key={set.setNumber} className="flex justify-between border-b border-border/50 py-1">
                  <span>Set {set.setNumber}</span>
                  <span className="num">
                    {set.reps}/{set.targetReps} · {set.durationSeconds}s
                  </span>
                </li>
              ))}
            </ul>
            <p className="mt-3 text-sm text-ghost">
              FC media {detail.avgHeartRate ?? '—'} · Tensión {detail.avgTensionScore}% · Presión{' '}
              {detail.pressureMmhg} mmHg
            </p>
            <Button className="mt-4 w-full" variant="secondary" onClick={() => setDetailId(null)}>
              {t('common.close')}
            </Button>
          </Panel>
        </div>
      )}
    </div>
  )
}
