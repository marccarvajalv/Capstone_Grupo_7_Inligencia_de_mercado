import type { GoalArchetype } from '../types'

export interface BfrProtocol {
  archetype: GoalArchetype
  label: string
  shortLabel: string
  repScheme: number[]
  restSeconds: number
  lopPercent: [number, number]
  tempoSeconds: [number, number, number, number]
  tempoLabels: [string, string, string, string]
  progressionNote: string
  accent: string
  recommendationTone: (readiness: number) => string
}

const TEMPO: [number, number, number, number] = [2, 2, 2, 2]
const TEMPO_LABELS: [string, string, string, string] = [
  'SUBIR',
  'MANTENER',
  'BAJAR',
  'MANTENER',
]

export const GOAL_PROTOCOLS: Record<GoalArchetype, BfrProtocol> = {
  rehabilitation: {
    archetype: 'rehabilitation',
    label: 'Rehabilitación',
    shortLabel: 'Rehab',
    repScheme: [20, 10, 10, 10],
    restSeconds: 45,
    lopPercent: [40, 50],
    tempoSeconds: TEMPO,
    tempoLabels: TEMPO_LABELS,
    progressionNote: 'Prioriza control y rango seguro. Progresa carga solo si no hay dolor.',
    accent: '#00E676',
    recommendationTone: (r) =>
      r >= 70
        ? 'Listo para una sesión suave de rehabilitación. Mantén presión baja.'
        : r >= 40
          ? 'Readiness moderada: reduce volumen y prioriza técnica.'
          : 'Recuperación baja: considera movilidad sin oclusión hoy.',
  },
  hypertrophy: {
    archetype: 'hypertrophy',
    label: 'Hipertrofia',
    shortLabel: 'Hipertrofia',
    repScheme: [30, 15, 15, 15],
    restSeconds: 30,
    lopPercent: [60, 80],
    tempoSeconds: TEMPO,
    tempoLabels: TEMPO_LABELS,
    progressionNote: 'Añade 1–2 reps o +2.5% carga semanal si completas el esquema.',
    accent: '#00D4FF',
    recommendationTone: (r) =>
      r >= 70
        ? 'Buen día para volumen BFR. Mantén el tempo y la tensión.'
        : r >= 40
          ? 'Moderado: usa el extremo inferior del rango LOP.'
          : 'Baja readiness: acorta a 3 sets o elige finisher de 5 min.',
  },
  endurance: {
    archetype: 'endurance',
    label: 'Resistencia',
    shortLabel: 'Resistencia',
    repScheme: [15, 15, 15, 15],
    restSeconds: 20,
    lopPercent: [40, 50],
    tempoSeconds: TEMPO,
    tempoLabels: TEMPO_LABELS,
    progressionNote: 'Reduce descanso 5s cada 2 semanas si la calidad se mantiene.',
    accent: '#7C9CFF',
    recommendationTone: (r) =>
      r >= 70
        ? 'Excelente para densificar densidades cortas con BFR.'
        : r >= 40
          ? 'Mantén densidades moderadas y controla la FC.'
          : 'Prioriza recuperación; evita oclusión prolongada.',
  },
  general_fitness: {
    archetype: 'general_fitness',
    label: 'Fitness general',
    shortLabel: 'Fitness',
    repScheme: [30, 15, 15, 15],
    restSeconds: 35,
    lopPercent: [50, 60],
    tempoSeconds: TEMPO,
    tempoLabels: TEMPO_LABELS,
    progressionNote: 'Alterna grupos musculares y registra consistencia semanal.',
    accent: '#00D4FF',
    recommendationTone: (r) =>
      r >= 70
        ? 'Listo para una sesión equilibrada de cuerpo completo.'
        : r >= 40
          ? 'Sesión corta y enfocada: un grupo muscular basta.'
          : 'Hoy prioriza movilidad y Cuff Check sin workout intenso.',
  },
  sport_specific: {
    archetype: 'sport_specific',
    label: 'Específico de deporte',
    shortLabel: 'Deporte',
    repScheme: [30, 15, 15, 15],
    restSeconds: 30,
    lopPercent: [50, 70],
    tempoSeconds: TEMPO,
    tempoLabels: TEMPO_LABELS,
    progressionNote: 'Alinea ejercicios con el patrón de movimiento de tu deporte.',
    accent: '#FFB020',
    recommendationTone: (r) =>
      r >= 70
        ? 'Buen día para transferir fuerza específica con BFR.'
        : r >= 40
          ? 'Enfócate en el patrón principal; reduce volumen accesorio.'
          : 'Recuperación primero: técnica sin oclusión o finisher suave.',
  },
}

export function getProtocol(archetype: GoalArchetype) {
  return GOAL_PROTOCOLS[archetype]
}

/** Límite duro de seguridad: 20 min de oclusión continua. */
export const OCCLUSION_LIMIT_SECONDS = 20 * 60
export const OCCLUSION_WARN_SECONDS = 18 * 60
export const PROTEIN_WINDOW_SECONDS = 30 * 60
export const FINISHER_SECONDS = 5 * 60
