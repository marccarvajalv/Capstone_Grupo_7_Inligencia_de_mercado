import { EXERCISES } from '../data/exercises'
import {
  EXERCISE_CACHE_KEY,
  EXERCISE_CATALOG_VERSION,
  STORAGE_KEY,
  type AppState,
  type EquipmentInventory,
  type UserPreferences,
} from '../types'
import { todayIso, uid } from './utils'

export const defaultPreferences = (): UserPreferences => ({
  units: 'metric',
  notifications: {
    cycles: true,
    calories: true,
    recovery: true,
    activity: true,
    nutrition: true,
    goals: true,
  },
  quietHours: { enabled: false, start: '22:00', end: '07:00' },
})

export const defaultEquipment = (): EquipmentInventory => ({
  garments: ['hytro_upper'],
  equipment: ['bodyweight'],
  updatedAt: todayIso(),
})

export function createEmptyState(): AppState {
  return {
    user: null,
    profile: null,
    medicalHistory: [],
    goal: null,
    goalHistory: [],
    equipment: defaultEquipment(),
    devices: [
      { provider: 'apple_health', status: 'disconnected' },
      { provider: 'google_fit', status: 'disconnected' },
      { provider: 'oura', status: 'disconnected' },
      { provider: 'whoop', status: 'disconnected' },
      { provider: 'garmin', status: 'disconnected' },
      { provider: 'fitbit', status: 'disconnected' },
      { provider: 'samsung', status: 'disconnected' },
    ],
    sessions: [],
    cuffChecks: [],
    notifications: [
      {
        id: uid('notif'),
        category: 'goal',
        title: 'Bienvenido a Hytro Precision',
        description: 'Completa el onboarding para desbloquear entrenamientos BFR seguros.',
        read: false,
        createdAt: todayIso(),
      },
    ],
    preferences: defaultPreferences(),
    selectedExerciseId: null,
    proteinTimerEndsAt: null,
  }
}

export function loadState(): AppState {
  try {
    const raw = localStorage.getItem(STORAGE_KEY)
    if (!raw) return createEmptyState()
    const parsed = JSON.parse(raw) as AppState
    return {
      ...createEmptyState(),
      ...parsed,
      preferences: { ...defaultPreferences(), ...parsed.preferences },
      equipment: parsed.equipment ?? defaultEquipment(),
      devices: parsed.devices?.length ? parsed.devices : createEmptyState().devices,
    }
  } catch {
    return createEmptyState()
  }
}

export function saveState(state: AppState) {
  localStorage.setItem(STORAGE_KEY, JSON.stringify(state))
}

export function ensureExerciseCache() {
  const cached = localStorage.getItem(EXERCISE_CACHE_KEY)
  if (cached) {
    try {
      const parsed = JSON.parse(cached) as { version: string }
      if (parsed.version === EXERCISE_CATALOG_VERSION) return
    } catch {
      /* refresh */
    }
  }
  localStorage.setItem(
    EXERCISE_CACHE_KEY,
    JSON.stringify({ version: EXERCISE_CATALOG_VERSION, exercises: EXERCISES }),
  )
}

export function clearAllData() {
  localStorage.removeItem(STORAGE_KEY)
  localStorage.removeItem(EXERCISE_CACHE_KEY)
}

export function latestClearance(state: AppState): boolean {
  const latest = state.medicalHistory[0]
  return Boolean(latest?.medicalClearance)
}

export function isTrainingBlocked(state: AppState): boolean {
  if (!state.medicalHistory.length) return true
  return !latestClearance(state)
}
