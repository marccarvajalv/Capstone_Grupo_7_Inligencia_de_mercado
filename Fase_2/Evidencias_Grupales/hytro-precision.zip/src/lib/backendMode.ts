import { getFirebaseMode, isFirebaseConfigured } from './firebase'
import { getApiBase, isApiBackendConfigured } from './apiClient'

export type BackendMode = 'demo' | 'api' | 'emulator' | 'cloud'

/** Priority: explicit API base > Firebase emulator/cloud > demo */
export function getBackendMode(): BackendMode {
  if (isApiBackendConfigured()) return 'api'
  if (!isFirebaseConfigured()) return 'demo'
  const fb = getFirebaseMode()
  if (fb === 'emulator') return 'emulator'
  if (fb === 'cloud') return 'cloud'
  return 'demo'
}

export function isCloudSyncEnabled() {
  const m = getBackendMode()
  return m === 'api' || m === 'emulator' || m === 'cloud'
}

export function backendModeLabel(): string {
  const m = getBackendMode()
  if (m === 'api') return `API productiva (${getApiBase()})`
  if (m === 'emulator') return 'Firebase emuladores'
  if (m === 'cloud') return 'Firebase cloud'
  return 'Modo demo (sin backend)'
}
