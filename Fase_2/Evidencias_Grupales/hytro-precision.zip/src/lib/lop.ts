import type { GoalArchetype, LimbRegion } from '../types'

/**
 * Estimación de LOP (Limb Occlusion Pressure) inspirada en Loenneke et al.
 * Fuente de referencia: ecuaciones predictivas de presión de oclusión arterial
 * usadas comúnmente en literatura BFR (circunferencia + presión sistólica).
 * No sustituye medición Doppler clínica.
 */
export function estimateLopMmHg(params: {
  systolic: number
  diastolic: number
  circumferenceCm: number
  limbType: LimbRegion
}): { lopMmHg: number; dialSetting: number; disclaimer: string } {
  const { systolic, diastolic, circumferenceCm, limbType } = params

  // Ecuaciones predictivas simplificadas (Loenneke-style):
  // Upper: LOP ≈ 0.514*circ + 0.220*SBP + 34.5  (ajuste brazo)
  // Lower: LOP ≈ 0.399*circ + 0.493*SBP + 5.4 + 0.15*(SBP-DBP)
  let lop: number
  if (limbType === 'upper_body') {
    lop = 0.514 * circumferenceCm + 0.22 * systolic + 0.05 * diastolic + 34.461
  } else {
    lop = 0.399 * circumferenceCm + 0.493 * systolic + 0.12 * (systolic - diastolic) + 5.443
  }

  const lopMmHg = Math.round(clamp(lop, 80, 300))
  const dialSetting = Math.round(clamp(((lopMmHg - 80) / (250 - 80)) * 9 + 1, 1, 10))

  return {
    lopMmHg,
    dialSetting,
    disclaimer:
      'Estimación orientativa según fórmula predictiva tipo Loenneke. No reemplaza medición clínica con Doppler. Usa presión conservadora y detén ante dolor, hormigueo o decoloración.',
  }
}

function clamp(n: number, min: number, max: number) {
  return Math.min(max, Math.max(min, n))
}

export function recommendedPressureForGoal(
  lopMmHg: number,
  archetype: GoalArchetype,
): { minMmHg: number; maxMmHg: number; targetMmHg: number; percentLabel: string } {
  const ranges: Record<GoalArchetype, [number, number]> = {
    rehabilitation: [0.4, 0.5],
    hypertrophy: [0.6, 0.8],
    endurance: [0.4, 0.5],
    general_fitness: [0.5, 0.6],
    sport_specific: [0.5, 0.7],
  }
  const [lo, hi] = ranges[archetype]
  const minMmHg = Math.round(lopMmHg * lo)
  const maxMmHg = Math.round(lopMmHg * hi)
  return {
    minMmHg,
    maxMmHg,
    targetMmHg: Math.round((minMmHg + maxMmHg) / 2),
    percentLabel: `${Math.round(lo * 100)}–${Math.round(hi * 100)}% LOP`,
  }
}
