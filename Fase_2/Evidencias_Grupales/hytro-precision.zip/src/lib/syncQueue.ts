/** Offline mutation queue — localStorage backed (contract-compatible). */

import { todayIso, uid } from './utils'

export const SYNC_QUEUE_KEY = 'hytro.sync.queue.v1'

export type SyncOp = 'set' | 'merge' | 'delete'

export interface SyncQueueItem {
  id: string
  /** Relative path under users/{uid}/… or '' for user root */
  relativePath: string
  op: SyncOp
  payload: Record<string, unknown> | null
  clientTimestamp: string
  retries: number
}

export function loadQueue(): SyncQueueItem[] {
  try {
    const raw = localStorage.getItem(SYNC_QUEUE_KEY)
    if (!raw) return []
    return JSON.parse(raw) as SyncQueueItem[]
  } catch {
    return []
  }
}

function saveQueue(items: SyncQueueItem[]) {
  localStorage.setItem(SYNC_QUEUE_KEY, JSON.stringify(items))
}

export function enqueueSync(
  relativePath: string,
  op: SyncOp,
  payload: Record<string, unknown> | null,
) {
  const items = loadQueue()
  items.push({
    id: uid('op'),
    relativePath,
    op,
    payload,
    clientTimestamp: todayIso(),
    retries: 0,
  })
  saveQueue(items)
}

export function clearQueue() {
  localStorage.removeItem(SYNC_QUEUE_KEY)
}

export function replaceQueue(items: SyncQueueItem[]) {
  saveQueue(items)
}
