import type { AppNotification, GoalArchetype, UserPreferences } from '../types'

const MAX_PER_DAY = 5

/** Map notification category → preference key */
const PREF_KEY: Record<AppNotification['category'], keyof UserPreferences['notifications']> = {
  cycle: 'cycles',
  calories: 'calories',
  recovery: 'recovery',
  activity: 'activity',
  nutrition: 'nutrition',
  goal: 'goals',
}

/** Categories allowed per goal archetype (Alloxentric #20) */
const GOAL_FILTER: Record<GoalArchetype, AppNotification['category'][]> = {
  rehabilitation: ['recovery', 'activity', 'goal', 'nutrition'],
  hypertrophy: ['cycle', 'calories', 'nutrition', 'goal', 'activity'],
  endurance: ['activity', 'recovery', 'calories', 'goal'],
  general_fitness: ['cycle', 'calories', 'recovery', 'activity', 'nutrition', 'goal'],
  sport_specific: ['activity', 'recovery', 'goal', 'cycle', 'nutrition'],
}

function startOfDayIso() {
  const d = new Date()
  d.setHours(0, 0, 0, 0)
  return d.toISOString()
}

export function canEnqueueNotification(
  existing: AppNotification[],
  next: Pick<AppNotification, 'category'>,
  preferences: UserPreferences,
  archetype: GoalArchetype = 'general_fitness',
): boolean {
  const prefKey = PREF_KEY[next.category]
  if (prefKey && preferences.notifications[prefKey] === false) return false
  const allowed = GOAL_FILTER[archetype] || GOAL_FILTER.general_fitness
  if (!allowed.includes(next.category)) return false
  const dayStart = startOfDayIso()
  const todayCount = existing.filter((n) => n.createdAt >= dayStart).length
  return todayCount < MAX_PER_DAY
}
