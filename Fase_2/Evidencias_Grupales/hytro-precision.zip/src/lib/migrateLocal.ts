/**
 * One-shot migration: localStorage AppState → Firestore for authenticated uid.
 * Marker: users/{uid}.migratedFromLocalAt
 */

import { doc, getDoc } from 'firebase/firestore'
import type { AppState } from '../types'
import { STORAGE_KEY } from '../types'
import { apiMigrateLocal, isApiBackendConfigured } from './apiClient'
import { getFirestoreDb } from './firebase'
import { pushFullState } from './firestoreSync'
import { loadState } from './storage'

const MIGRATION_FLAG_KEY = 'hytro.migrated.uids.v1'

function migratedUids(): Set<string> {
  try {
    const raw = localStorage.getItem(MIGRATION_FLAG_KEY)
    return new Set(raw ? (JSON.parse(raw) as string[]) : [])
  } catch {
    return new Set()
  }
}

function markMigratedLocally(uid: string) {
  const set = migratedUids()
  set.add(uid)
  localStorage.setItem(MIGRATION_FLAG_KEY, JSON.stringify([...set]))
}

export async function migrateLocalToCloudIfNeeded(
  uid: string,
  currentLocal: AppState,
): Promise<{ migrated: boolean; reason: string }> {
  if (migratedUids().has(uid)) {
    return { migrated: false, reason: 'already-local-flag' }
  }

  const raw = localStorage.getItem(STORAGE_KEY)
  if (!raw) return { migrated: false, reason: 'no-local-data' }

  const local = currentLocal.user ? currentLocal : loadState()
  const hasSubstance =
    Boolean(local.profile) ||
    local.medicalHistory.length > 0 ||
    Boolean(local.goal) ||
    local.sessions.length > 0 ||
    local.cuffChecks.length > 0 ||
    (local.user?.onboardingComplete ?? false)

  if (!hasSubstance) {
    markMigratedLocally(uid)
    return { migrated: false, reason: 'empty-local' }
  }

  const toPush: AppState = {
    ...local,
    user: local.user
      ? {
          ...local.user,
          id: uid,
        }
      : {
          id: uid,
          email: '',
          displayName: 'Atleta',
          onboardingComplete: false,
          onboardingStep: 0,
          createdAt: new Date().toISOString(),
        },
  }

  if (isApiBackendConfigured()) {
    const result = await apiMigrateLocal(toPush)
    if (result.migrated || result.reason === 'already-cloud') markMigratedLocally(uid)
    return result
  }

  const db = getFirestoreDb()
  if (!db) return { migrated: false, reason: 'no-firestore' }

  const userSnap = await getDoc(doc(db, 'users', uid))
  if (userSnap.exists() && userSnap.data().migratedFromLocalAt) {
    markMigratedLocally(uid)
    return { migrated: false, reason: 'already-cloud' }
  }

  await pushFullState(uid, toPush)
  markMigratedLocally(uid)
  return { migrated: true, reason: 'ok' }
}
