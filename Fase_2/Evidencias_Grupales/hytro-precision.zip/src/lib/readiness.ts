import type { ConnectedDevice, GoalArchetype } from '../types'
import { getProtocol } from './protocols'
import { clamp } from './utils'

export interface ReadinessBreakdown {
  hrv: number
  sleep: number
  rhr: number
  spo2: number
  muscleRecovery: number
  total: number
  level: 'ALTO' | 'MODERADO' | 'BAJO'
  recommendation: string
}

/** Genera métricas mock deterministas a partir de dispositivos conectados + fecha. */
export function computeReadiness(
  devices: ConnectedDevice[],
  archetype: GoalArchetype,
  seedOffset = 0,
): ReadinessBreakdown {
  const connected = devices.filter((d) => d.status === 'connected' || d.status === 'mock')
  const base = connected.length > 0 ? 62 : 48
  const bonus = Math.min(18, connected.length * 4)
  const dayFactor = (new Date().getDate() + seedOffset) % 7

  const hrv = clamp(base + bonus + dayFactor - 4, 20, 98)
  const sleep = clamp(base + bonus - dayFactor + 2, 20, 98)
  const rhr = clamp(base + bonus / 2 + 5, 20, 98)
  const spo2 = clamp(88 + connected.length * 1.5 + (dayFactor % 3), 85, 99)
  const muscleRecovery = clamp(base + dayFactor * 2, 20, 98)

  const total = Math.round(
    hrv * 0.25 + sleep * 0.25 + rhr * 0.25 + spo2 * 0.15 + muscleRecovery * 0.1,
  )

  const level = total >= 70 ? 'ALTO' : total >= 40 ? 'MODERADO' : 'BAJO'
  const recommendation = getProtocol(archetype).recommendationTone(total)

  return { hrv, sleep, rhr, spo2, muscleRecovery, total, level, recommendation }
}
