/** Firebase bootstrap — demo | emulator | cloud. */

import { initializeApp, type FirebaseApp } from 'firebase/app'
import {
  connectAuthEmulator,
  getAuth,
  GoogleAuthProvider,
  type Auth,
} from 'firebase/auth'
import { connectFirestoreEmulator, getFirestore, type Firestore } from 'firebase/firestore'

export type FirebaseMode = 'cloud' | 'emulator' | 'demo'

export const EMULATOR_HOST_KEY = 'hytro.emulator.host'

const requiredKeys = [
  'VITE_FIREBASE_API_KEY',
  'VITE_FIREBASE_AUTH_DOMAIN',
  'VITE_FIREBASE_PROJECT_ID',
  'VITE_FIREBASE_APP_ID',
] as const

function readConfig() {
  return {
    apiKey: import.meta.env.VITE_FIREBASE_API_KEY as string | undefined,
    authDomain: import.meta.env.VITE_FIREBASE_AUTH_DOMAIN as string | undefined,
    projectId: import.meta.env.VITE_FIREBASE_PROJECT_ID as string | undefined,
    storageBucket: import.meta.env.VITE_FIREBASE_STORAGE_BUCKET as string | undefined,
    messagingSenderId: import.meta.env.VITE_FIREBASE_MESSAGING_SENDER_ID as string | undefined,
    appId: import.meta.env.VITE_FIREBASE_APP_ID as string | undefined,
  }
}

/** Host for Auth :9099 and Firestore :8080 (override via Settings / localStorage). */
export function getEmulatorHost(): string {
  try {
    const fromLs = localStorage.getItem(EMULATOR_HOST_KEY)?.trim()
    if (fromLs) return fromLs
  } catch {
    /* SSR / private mode */
  }
  return (import.meta.env.VITE_FIREBASE_EMULATOR_HOST as string | undefined)?.trim() || '127.0.0.1'
}

export function setEmulatorHost(host: string) {
  localStorage.setItem(EMULATOR_HOST_KEY, host.trim())
}

export function getFirebaseMode(): FirebaseMode {
  if (import.meta.env.VITE_FIREBASE_USE_EMULATOR === 'true') return 'emulator'
  const cfg = readConfig()
  const ok = requiredKeys.every((k) => Boolean(import.meta.env[k]))
  if (!ok || !cfg.apiKey || cfg.apiKey === 'REPLACE_ME') return 'demo'
  return 'cloud'
}

export function isFirebaseConfigured() {
  return getFirebaseMode() !== 'demo'
}

let app: FirebaseApp | null = null
let auth: Auth | null = null
let db: Firestore | null = null
let authEmulatorConnected = false
let firestoreEmulatorConnected = false

export function getFirebaseApp(): FirebaseApp | null {
  if (!isFirebaseConfigured()) return null
  if (app) return app
  const cfg = readConfig()
  // Emulator accepts any non-empty config; cloud needs real project values.
  app = initializeApp({
    apiKey: cfg.apiKey || 'demo-api-key',
    authDomain: cfg.authDomain || 'demo-hytro.firebaseapp.com',
    projectId: cfg.projectId || 'demo-hytro',
    storageBucket: cfg.storageBucket || undefined,
    messagingSenderId: cfg.messagingSenderId || undefined,
    appId: cfg.appId || '1:0:web:demo',
  })
  return app
}

export function getFirebaseAuth(): Auth | null {
  const a = getFirebaseApp()
  if (!a) return null
  if (!auth) {
    auth = getAuth(a)
    connectAuthEmulatorIfNeeded(auth)
  }
  return auth
}

export function getFirestoreDb(): Firestore | null {
  const a = getFirebaseApp()
  if (!a) return null
  if (!db) {
    db = getFirestore(a)
    connectFirestoreEmulatorIfNeeded(db)
  }
  return db
}

function connectAuthEmulatorIfNeeded(a: Auth) {
  if (getFirebaseMode() !== 'emulator' || authEmulatorConnected) return
  const host = getEmulatorHost()
  try {
    connectAuthEmulator(a, `http://${host}:9099`, { disableWarnings: true })
    authEmulatorConnected = true
  } catch {
    /* already connected (HMR) */
    authEmulatorConnected = true
  }
}

function connectFirestoreEmulatorIfNeeded(f: Firestore) {
  if (getFirebaseMode() !== 'emulator' || firestoreEmulatorConnected) return
  const host = getEmulatorHost()
  try {
    connectFirestoreEmulator(f, host, 8080)
    firestoreEmulatorConnected = true
  } catch {
    firestoreEmulatorConnected = true
  }
}

export const googleProvider = new GoogleAuthProvider()

export function firebaseModeLabel(): string {
  const m = getFirebaseMode()
  if (m === 'demo') return 'Modo demo (sin Firebase)'
  if (m === 'emulator') return `Firebase emuladores (${getEmulatorHost()})`
  return 'Firebase cloud'
}
