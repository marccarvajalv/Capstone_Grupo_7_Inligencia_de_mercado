/** REST backend client (productive shared API /api/v1 + legacy aliases). */

import type { AppState } from '../types'
import { loadQueue, replaceQueue, type SyncQueueItem } from './syncQueue'
import { getSecureSync, hydrateAuthTokens, setSecure } from './secureStore'

export const API_TOKEN_KEY = 'hytro.api.token'
export const API_REFRESH_KEY = 'hytro.api.refresh'
export const API_BASE_KEY = 'hytro.api.base'

export function getApiBase(): string {
  try {
    const fromLs = localStorage.getItem(API_BASE_KEY)?.trim()
    if (fromLs) return fromLs.replace(/\/$/, '')
  } catch {
    /* ignore */
  }
  const env = (import.meta.env.VITE_API_BASE as string | undefined)?.trim()
  return env ? env.replace(/\/$/, '') : ''
}

export function setApiBase(url: string) {
  localStorage.setItem(API_BASE_KEY, url.trim().replace(/\/$/, ''))
}

export function isApiBackendConfigured() {
  return Boolean(getApiBase())
}

export function getApiToken(): string | null {
  return getSecureSync(API_TOKEN_KEY)
}

export function getRefreshToken(): string | null {
  return getSecureSync(API_REFRESH_KEY)
}

export function setApiToken(token: string | null) {
  void setSecure(API_TOKEN_KEY, token)
}

export function setRefreshToken(token: string | null) {
  void setSecure(API_REFRESH_KEY, token)
}

/** Cargar tokens desde Keystore nativo antes de hidratar sesión. */
export async function hydrateApiTokens() {
  await hydrateAuthTokens([API_TOKEN_KEY, API_REFRESH_KEY])
}

function extractError(data: unknown, status: number): string {
  if (data && typeof data === 'object') {
    const d = data as {
      error?: string | { message?: string; code?: string }
      message?: string
    }
    // Alloxentric: { error: "CODE", message, details }
    if (typeof d.error === 'string') {
      return d.message ? `${d.error}: ${d.message}` : d.error
    }
    // Legacy nested
    if (d.error && typeof d.error === 'object' && d.error.message) {
      return d.error.code ? `${d.error.code}: ${d.error.message}` : d.error.message
    }
  }
  return `API ${status}`
}

const DEFAULT_TIMEOUT_MS = 12_000

async function apiFetch<T>(
  path: string,
  init: RequestInit & { auth?: boolean; timeoutMs?: number; _retried?: boolean } = {},
): Promise<T> {
  const base = getApiBase()
  if (!base) throw new Error('API base no configurada')
  const headers = new Headers(init.headers)
  headers.set('Content-Type', 'application/json')
  if (!headers.has('X-Client-Id')) {
    headers.set(
      'X-Client-Id',
      localStorage.getItem('hytro.clientId') ||
        (import.meta.env.VITE_CLIENT_ID as string | undefined) ||
        'client_demo',
    )
  }
  if (init.auth !== false) {
    const token = getApiToken()
    if (token) headers.set('Authorization', `Bearer ${token}`)
  }

  const timeoutMs = init.timeoutMs ?? DEFAULT_TIMEOUT_MS
  const controller = new AbortController()
  const timer = window.setTimeout(() => controller.abort(), timeoutMs)
  try {
    const res = await fetch(`${base}${path}`, {
      ...init,
      headers,
      signal: init.signal ?? controller.signal,
    })
    const data = (await res.json().catch(() => ({}))) as T & {
      error?: string | { message?: string; code?: string }
    }
    if (res.status === 401 && init.auth !== false && !init._retried) {
      const refreshed = await tryRefresh()
      if (refreshed) {
        return apiFetch<T>(path, { ...init, _retried: true })
      }
    }
    if (!res.ok) throw new Error(extractError(data, res.status))
    return data
  } catch (e) {
    if (e instanceof DOMException && e.name === 'AbortError') {
      throw new Error('Tiempo de espera agotado con el backend')
    }
    throw e
  } finally {
    window.clearTimeout(timer)
  }
}

async function tryRefresh(): Promise<boolean> {
  const refreshToken = getRefreshToken()
  const base = getApiBase()
  if (!refreshToken || !base) return false
  try {
    const res = await fetch(`${base}/api/v1/auth/refresh`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ refreshToken }),
    })
    const data = (await res.json()) as {
      accessToken?: string
      token?: string
      refreshToken?: string
    }
    if (!res.ok) {
      setApiToken(null)
      setRefreshToken(null)
      return false
    }
    setApiToken(data.accessToken || data.token || null)
    if (data.refreshToken) setRefreshToken(data.refreshToken)
    return true
  } catch {
    return false
  }
}

type ApiUser = NonNullable<AppState['user']>

function storeAuth(data: {
  token?: string
  accessToken?: string
  refreshToken?: string
  user: ApiUser
}) {
  setApiToken(data.accessToken || data.token || null)
  if (data.refreshToken) setRefreshToken(data.refreshToken)
}

export async function apiSignup(email: string, password: string, displayName: string) {
  const data = await apiFetch<{
    token?: string
    accessToken?: string
    refreshToken?: string
    verifyEmailToken?: string
    user: ApiUser
  }>('/api/v1/auth/register', {
    method: 'POST',
    auth: false,
    body: JSON.stringify({ email, password, displayName }),
  })
  storeAuth(data)
  // Capstone: auto-verificar con token de registro (SMTP no disponible)
  if (data.verifyEmailToken) {
    try {
      await apiFetch('/api/v1/auth/verify-email', {
        method: 'POST',
        auth: false,
        body: JSON.stringify({ token: data.verifyEmailToken }),
      })
      if (data.user) data.user = { ...data.user, emailVerified: true } as ApiUser
    } catch {
      /* usuario puede verificar luego */
    }
  }
  return data
}

export async function apiLogin(email: string, password: string) {
  const data = await apiFetch<{
    token?: string
    accessToken?: string
    refreshToken?: string
    user: ApiUser
  }>('/api/v1/auth/login', {
    method: 'POST',
    auth: false,
    body: JSON.stringify({ email, password }),
  })
  storeAuth(data)
  return data
}

export async function apiMe() {
  return apiFetch<{ user: NonNullable<AppState['user']> }>('/api/v1/auth/me')
}

export async function apiPullState(): Promise<Partial<AppState>> {
  const raw = await apiFetch<Partial<AppState> & { equipment?: AppState['equipment'] | null }>(
    '/api/v1/sync/pull',
  )
  return {
    ...raw,
    medicalHistory: raw.medicalHistory ?? [],
    goalHistory: raw.goalHistory ?? [],
    sessions: raw.sessions ?? [],
    cuffChecks: raw.cuffChecks ?? [],
    notifications: raw.notifications ?? [],
    devices: raw.devices ?? [],
    equipment: raw.equipment ?? undefined,
    profile: raw.profile ?? null,
    goal: raw.goal ?? null,
  }
}

export async function apiFlushQueue(): Promise<{ flushed: number; failed: number }> {
  const queue = loadQueue()
  if (!queue.length) return { flushed: 0, failed: 0 }
  try {
    await apiFetch<{ ok: boolean; applied: number }>('/api/v1/sync/push', {
      method: 'POST',
      body: JSON.stringify({ items: queue }),
    })
    replaceQueue([])
    return { flushed: queue.length, failed: 0 }
  } catch {
    const bumped = queue.map((q: SyncQueueItem) => ({ ...q, retries: q.retries + 1 }))
    replaceQueue(bumped)
    return { flushed: 0, failed: queue.length }
  }
}

export async function apiMigrateLocal(state: AppState) {
  return apiFetch<{ migrated: boolean; reason: string }>('/api/v1/migrate', {
    method: 'PUT',
    body: JSON.stringify({ state }),
  })
}

export async function apiDeleteAccount(confirmation: string) {
  return apiFetch<{ ok: boolean }>('/api/v1/users/me', {
    method: 'DELETE',
    body: JSON.stringify({ confirmation }),
  })
}

export async function apiLogout() {
  const refreshToken = getRefreshToken()
  try {
    if (refreshToken) {
      await apiFetch('/api/v1/auth/logout', {
        method: 'POST',
        auth: false,
        body: JSON.stringify({ refreshToken }),
      })
    }
  } finally {
    setApiToken(null)
    setRefreshToken(null)
  }
}

export async function apiHealth() {
  return apiFetch<{ ok: boolean; service: string }>('/health', { auth: false })
}
