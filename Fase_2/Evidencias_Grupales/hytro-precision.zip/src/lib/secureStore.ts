/**
 * Almacenamiento de tokens (K-03 / H-03).
 * Decisión: (a) Keystore/Keychain nativo en APK vía capacitor-secure-storage-plugin.
 * En navegador web (sin Capacitor) cae a localStorage — solo desarrollo.
 */

const memory = new Map<string, string>()

type SecurePlugin = {
  set: (opts: { key: string; value: string }) => Promise<unknown>
  get: (opts: { key: string }) => Promise<{ value: string }>
  remove: (opts: { key: string }) => Promise<unknown>
}

function isNativePlatform(): boolean {
  try {
    const w = window as unknown as {
      Capacitor?: { isNativePlatform?: () => boolean }
    }
    return Boolean(w.Capacitor?.isNativePlatform?.())
  } catch {
    return false
  }
}

function getNativePlugin(): SecurePlugin | null {
  try {
    const w = window as unknown as {
      Capacitor?: { Plugins?: Record<string, unknown> }
    }
    if (!isNativePlatform()) return null
    const fromCap = w.Capacitor?.Plugins?.SecureStoragePlugin as SecurePlugin | undefined
    if (fromCap && typeof fromCap.set === 'function' && typeof fromCap.get === 'function') {
      return fromCap
    }
  } catch {
    /* ignore */
  }
  return null
}

async function loadPluginModule(): Promise<SecurePlugin | null> {
  const native = getNativePlugin()
  if (native) return native
  try {
    const mod = await import('capacitor-secure-storage-plugin')
    const plugin = mod.SecureStoragePlugin as unknown as SecurePlugin
    if (plugin && typeof plugin.set === 'function' && typeof plugin.get === 'function') {
      return plugin
    }
  } catch {
    /* web / not linked */
  }
  return null
}

let pluginPromise: Promise<SecurePlugin | null> | null = null
function plugin() {
  if (!pluginPromise) pluginPromise = loadPluginModule()
  return pluginPromise
}

export function getSecureSync(key: string): string | null {
  if (memory.has(key)) return memory.get(key) ?? null
  try {
    return localStorage.getItem(key)
  } catch {
    return null
  }
}

export async function hydrateSecureKey(key: string): Promise<string | null> {
  const p = await plugin()
  if (p) {
    try {
      const { value } = await p.get({ key })
      if (typeof value === 'string') {
        memory.set(key, value)
        return value
      }
    } catch {
      /* missing key */
    }
  }
  const fallback = getSecureSync(key)
  if (fallback) memory.set(key, fallback)
  return fallback
}

export async function setSecure(key: string, value: string | null): Promise<void> {
  if (!value) {
    memory.delete(key)
    try {
      localStorage.removeItem(key)
    } catch {
      /* ignore */
    }
    const p = await plugin()
    if (p) {
      try {
        await p.remove({ key })
      } catch {
        /* ignore */
      }
    }
    return
  }
  memory.set(key, value)
  try {
    localStorage.setItem(key, value)
  } catch {
    /* ignore */
  }
  const p = await plugin()
  if (p) {
    try {
      await p.set({ key, value })
      if (isNativePlatform()) {
        try {
          localStorage.removeItem(key)
        } catch {
          /* ignore */
        }
      }
    } catch {
      /* keep localStorage fallback */
    }
  }
}

export async function hydrateAuthTokens(keys: string[]): Promise<void> {
  await Promise.all(keys.map((k) => hydrateSecureKey(k)))
}

export function secureStorageMode(): 'keystore' | 'localStorage' {
  return isNativePlatform() ? 'keystore' : 'localStorage'
}
