/**
 * Firestore push/pull for Hytro contract v1.
 * @see docs/hytro-firestore-contract.md
 */

import {
  collection,
  doc,
  getDoc,
  getDocs,
  setDoc,
  writeBatch,
  type Firestore,
} from 'firebase/firestore'
import type { AppState, ConnectedDevice, LocalUser } from '../types'
import { createEmptyState, defaultEquipment, defaultPreferences } from './storage'
import { apiFlushQueue, apiPullState, isApiBackendConfigured } from './apiClient'
import { isCloudSyncEnabled } from './backendMode'
import { getFirestoreDb } from './firebase'
import { enqueueSync, loadQueue, replaceQueue, type SyncQueueItem } from './syncQueue'
import { todayIso } from './utils'

function userRef(db: Firestore, uid: string) {
  return doc(db, 'users', uid)
}

export function enqueueStateMutation(
  kind:
    | 'user'
    | 'profile'
    | 'screening'
    | 'goal'
    | 'equipment'
    | 'device'
    | 'session'
    | 'cuff'
    | 'notification',
  payload: Record<string, unknown>,
  id?: string,
) {
  if (!isCloudSyncEnabled()) return
  switch (kind) {
    case 'user':
      enqueueSync('', 'merge', { ...payload, updatedAt: todayIso() })
      break
    case 'profile':
      enqueueSync('profile/current', 'set', { ...payload, updatedAt: todayIso() })
      break
    case 'screening':
      enqueueSync(`medicalScreenings/${id ?? payload.id}`, 'set', {
        ...payload,
        updatedAt: (payload.submittedAt as string) || todayIso(),
      })
      break
    case 'goal':
      enqueueSync(`goals/${id ?? payload.id}`, 'set', {
        ...payload,
        updatedAt: todayIso(),
      })
      break
    case 'equipment':
      enqueueSync('equipment/current', 'set', { ...payload, updatedAt: todayIso() })
      break
    case 'device':
      enqueueSync(`devices/${payload.provider}`, 'set', {
        ...payload,
        updatedAt: todayIso(),
      })
      break
    case 'session':
      enqueueSync(`workoutSessions/${id ?? payload.id}`, 'set', {
        ...payload,
        updatedAt: todayIso(),
      })
      break
    case 'cuff':
      enqueueSync(`cuffChecks/${id ?? payload.id}`, 'set', {
        ...payload,
        updatedAt: todayIso(),
      })
      break
    case 'notification':
      enqueueSync(`notifications/${id ?? payload.id}`, 'set', {
        ...payload,
        updatedAt: todayIso(),
      })
      break
  }
}

async function applyQueueItem(db: Firestore, uid: string, item: SyncQueueItem) {
  const path = item.relativePath
    ? doc(db, 'users', uid, ...item.relativePath.split('/'))
    : userRef(db, uid)

  if (item.op === 'delete') {
    // soft: skip deletes in v1
    return
  }
  await setDoc(path, item.payload ?? {}, { merge: item.op === 'merge' })
}

export async function flushSyncQueue(uid: string): Promise<{ flushed: number; failed: number }> {
  if (isApiBackendConfigured()) {
    if (!navigator.onLine) return { flushed: 0, failed: 0 }
    return apiFlushQueue()
  }
  const db = getFirestoreDb()
  if (!db || !navigator.onLine) return { flushed: 0, failed: 0 }

  const queue = loadQueue()
  if (!queue.length) return { flushed: 0, failed: 0 }

  const remaining: SyncQueueItem[] = []
  let flushed = 0
  let failed = 0

  for (const item of queue) {
    try {
      await applyQueueItem(db, uid, item)
      flushed++
    } catch {
      failed++
      remaining.push({ ...item, retries: item.retries + 1 })
    }
  }
  replaceQueue(remaining)
  return { flushed, failed }
}

export async function pullCloudState(uid: string): Promise<Partial<AppState> | null> {
  if (isApiBackendConfigured()) {
    try {
      return await apiPullState()
    } catch {
      return null
    }
  }
  const db = getFirestoreDb()
  if (!db) return null

  const userSnap = await getDoc(userRef(db, uid))
  if (!userSnap.exists()) return null

  const u = userSnap.data()
  const profileSnap = await getDoc(doc(db, 'users', uid, 'profile', 'current'))
  const equipmentSnap = await getDoc(doc(db, 'users', uid, 'equipment', 'current'))

  const [screenings, goals, devices, sessions, cuffs, notifs] = await Promise.all([
    getDocs(collection(db, 'users', uid, 'medicalScreenings')),
    getDocs(collection(db, 'users', uid, 'goals')),
    getDocs(collection(db, 'users', uid, 'devices')),
    getDocs(collection(db, 'users', uid, 'workoutSessions')),
    getDocs(collection(db, 'users', uid, 'cuffChecks')),
    getDocs(collection(db, 'users', uid, 'notifications')),
  ])

  const medicalHistory = (
    screenings.docs.map((d) => ({ id: d.id, ...d.data() })) as AppState['medicalHistory']
  ).sort((a, b) => a.submittedAt < b.submittedAt ? 1 : -1)

  const goalDocs = goals.docs.map((d) => ({
    id: d.id,
    ...d.data(),
  })) as AppState['goalHistory']
  const active = goalDocs.find((g) => g.isActive) ?? null
  const goalHistory = goalDocs.filter((g) => !g.isActive)

  const deviceMap = new Map(
    devices.docs.map((d) => [d.id, { ...(d.data() as ConnectedDevice) }]),
  )
  const baseDevices = createEmptyState().devices.map((d) => deviceMap.get(d.provider) ?? d)

  const sessionsList = (
    sessions.docs.map((d) => ({ id: d.id, ...d.data() })) as AppState['sessions']
  ).sort((a, b) => (a.createdAt < b.createdAt ? 1 : -1))

  const cuffList = (
    cuffs.docs.map((d) => ({ id: d.id, ...d.data() })) as AppState['cuffChecks']
  ).sort((a, b) => (a.createdAt < b.createdAt ? 1 : -1))

  const notifications = (
    notifs.docs.map((d) => ({ id: d.id, ...d.data() })) as AppState['notifications']
  ).sort((a, b) => (a.createdAt < b.createdAt ? 1 : -1))

  const user: LocalUser = {
    id: uid,
    email: String(u.email ?? ''),
    displayName: String(u.displayName ?? 'Atleta'),
    onboardingComplete: Boolean(u.onboardingComplete),
    onboardingStep: Number(u.onboardingStep ?? 0),
    createdAt: String(u.createdAt ?? todayIso()),
  }

  return {
    user,
    profile: profileSnap.exists()
      ? (profileSnap.data() as AppState['profile'])
      : null,
    medicalHistory,
    goal: active,
    goalHistory,
    equipment: equipmentSnap.exists()
      ? (equipmentSnap.data() as AppState['equipment'])
      : defaultEquipment(),
    devices: baseDevices,
    sessions: sessionsList,
    cuffChecks: cuffList,
    notifications: notifications.length ? notifications : createEmptyState().notifications,
    preferences: { ...defaultPreferences(), ...(u.preferences as object) },
    proteinTimerEndsAt: (u.proteinTimerEndsAt as string | null) ?? null,
  }
}

export async function ensureUserDoc(
  uid: string,
  seed: { email: string; displayName: string },
) {
  if (isApiBackendConfigured()) return
  const db = getFirestoreDb()
  if (!db) return
  const ref = userRef(db, uid)
  const snap = await getDoc(ref)
  if (snap.exists()) return
  await setDoc(ref, {
    email: seed.email,
    displayName: seed.displayName,
    onboardingComplete: false,
    onboardingStep: 0,
    createdAt: todayIso(),
    updatedAt: todayIso(),
    preferences: defaultPreferences(),
  })
}

/** Push full local AppState to cloud (used by migration + first hydrate). */
export async function pushFullState(uid: string, state: AppState) {
  const db = getFirestoreDb()
  if (!db || !state.user) return

  const batch = writeBatch(db)
  const now = todayIso()

  batch.set(
    userRef(db, uid),
    {
      email: state.user.email,
      displayName: state.user.displayName,
      onboardingComplete: state.user.onboardingComplete,
      onboardingStep: state.user.onboardingStep,
      createdAt: state.user.createdAt,
      updatedAt: now,
      preferences: state.preferences,
      proteinTimerEndsAt: state.proteinTimerEndsAt,
      migratedFromLocalAt: now,
    },
    { merge: true },
  )

  if (state.profile) {
    batch.set(doc(db, 'users', uid, 'profile', 'current'), {
      ...state.profile,
      updatedAt: now,
    })
  }

  batch.set(doc(db, 'users', uid, 'equipment', 'current'), {
    ...state.equipment,
    updatedAt: state.equipment.updatedAt || now,
  })

  for (const s of state.medicalHistory) {
    batch.set(doc(db, 'users', uid, 'medicalScreenings', s.id), {
      ...s,
      updatedAt: s.submittedAt,
    })
  }

  const goals = [
    ...(state.goal ? [state.goal] : []),
    ...state.goalHistory,
  ]
  for (const g of goals) {
    batch.set(doc(db, 'users', uid, 'goals', g.id), {
      ...g,
      updatedAt: g.createdAt,
    })
  }

  for (const d of state.devices) {
    batch.set(doc(db, 'users', uid, 'devices', d.provider), {
      ...d,
      updatedAt: now,
    })
  }

  for (const sess of state.sessions) {
    batch.set(doc(db, 'users', uid, 'workoutSessions', sess.id), {
      ...sess,
      updatedAt: sess.createdAt,
    })
  }

  for (const c of state.cuffChecks) {
    batch.set(doc(db, 'users', uid, 'cuffChecks', c.id), {
      ...c,
      updatedAt: c.createdAt,
    })
  }

  for (const n of state.notifications) {
    batch.set(doc(db, 'users', uid, 'notifications', n.id), {
      ...n,
      updatedAt: n.createdAt,
    })
  }

  await batch.commit()
}
