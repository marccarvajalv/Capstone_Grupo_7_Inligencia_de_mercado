/** Política de contraseña alineada a especificación Capstone (C-03). */
export function validatePassword(password: string): string | null {
  if (password.length < 8) return 'Mínimo 8 caracteres'
  if (!/[A-Z]/.test(password)) return 'Debe incluir una mayúscula'
  if (!/[a-z]/.test(password)) return 'Debe incluir una minúscula'
  if (!/\d/.test(password)) return 'Debe incluir un dígito'
  return null
}
