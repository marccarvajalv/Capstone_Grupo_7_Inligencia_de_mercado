import { StrictMode } from 'react'
import { createRoot } from 'react-dom/client'
import { BrowserRouter, HashRouter } from 'react-router-dom'
import './index.css'
import App from './App.tsx'
import { I18nProvider } from './i18n'
import { AppProvider } from './store/AppContext'
import { ThemeProvider } from './theme'

/** Capacitor / file-like shells need HashRouter; normal web keeps clean paths. */
const isNativeShell =
  import.meta.env.VITE_ROUTER_HASH === 'true' ||
  Boolean(
    (window as unknown as { Capacitor?: { isNativePlatform?: () => boolean } }).Capacitor
      ?.isNativePlatform?.() ||
      (window as unknown as { Capacitor?: unknown }).Capacitor,
  )

const Router = isNativeShell ? HashRouter : BrowserRouter

createRoot(document.getElementById('root')!).render(
  <StrictMode>
    <Router>
      <ThemeProvider>
        <I18nProvider>
          <AppProvider>
            <App />
          </AppProvider>
        </I18nProvider>
      </ThemeProvider>
    </Router>
  </StrictMode>,
)
