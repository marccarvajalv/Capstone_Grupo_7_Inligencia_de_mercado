import { NavLink, Outlet, useLocation } from 'react-router-dom'
import {
  Activity,
  Armchair,
  Home,
  Map,
  Settings,
  Dumbbell,
} from 'lucide-react'
import { useI18n } from '../i18n'
import { cn } from '../lib/utils'
import { useApp } from '../store/AppContext'
import { MedicalBlockBanner } from './MedicalBlockBanner'
import { ProteinTimer } from './ProteinTimer'

export function AppShell() {
  const location = useLocation()
  const hideNav = location.pathname.startsWith('/app/cuff')
  const { state } = useApp()
  const { t } = useI18n()

  const tabs = [
    { to: '/app/home', label: t('nav.home'), icon: Home },
    { to: '/app/train', label: t('nav.body'), icon: Map },
    { to: '/app/cuff', label: t('nav.cuff'), icon: Armchair },
    { to: '/app/workout', label: t('nav.workout'), icon: Dumbbell },
    { to: '/app/progress', label: t('nav.progress'), icon: Activity },
  ]

  return (
    <div className="mx-auto flex min-h-dvh w-full max-w-lg flex-col">
      <header className="sticky top-0 z-30 flex items-center justify-between border-b border-border/60 bg-bg/90 px-4 py-3 backdrop-blur">
        <div>
          <p className="text-[10px] uppercase tracking-[0.2em] text-plasma">{t('shell.brand')}</p>
          <p className="text-sm text-ghost">
            {t('shell.hello', { name: state.user?.displayName ?? t('common.athlete') })}
          </p>
        </div>
        <NavLink
          to="/app/settings"
          className="rounded-xl border border-border p-2 text-ghost hover:text-bone"
          aria-label={t('nav.settings')}
        >
          <Settings className="h-5 w-5" />
        </NavLink>
      </header>

      <MedicalBlockBanner />
      <ProteinTimer />

      <main className={cn('flex-1 px-4 py-4', !hideNav && 'pb-24')}>
        <Outlet />
      </main>

      {!hideNav ? (
        <nav className="fixed bottom-0 left-0 right-0 z-40 border-t border-border/70 bg-bg/95 backdrop-blur">
          <div className="mx-auto grid max-w-lg grid-cols-5 px-1 pb-[env(safe-area-inset-bottom)] pt-1">
            {tabs.map(({ to, label, icon: Icon }) => (
              <NavLink
                key={to}
                to={to}
                className={({ isActive }) =>
                  cn(
                    'flex flex-col items-center gap-1 rounded-xl px-1 py-2 text-[10px]',
                    isActive ? 'text-plasma' : 'text-muted hover:text-ghost',
                  )
                }
              >
                <Icon className="h-5 w-5" />
                {label}
              </NavLink>
            ))}
          </div>
        </nav>
      ) : null}
    </div>
  )
}
