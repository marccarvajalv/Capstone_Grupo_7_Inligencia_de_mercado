import { AlertTriangle } from 'lucide-react'
import { Link } from 'react-router-dom'
import { useI18n } from '../i18n'
import { useApp } from '../store/AppContext'

export function MedicalBlockBanner() {
  const { blocked, state } = useApp()
  const { t } = useI18n()
  if (!state.user?.onboardingComplete) return null
  if (!blocked) return null

  return (
    <div className="mx-4 mt-3 flex items-start gap-3 rounded-xl border border-arterial/40 bg-arterial/10 px-3 py-3 text-sm animate-slide-up">
      <AlertTriangle className="mt-0.5 h-5 w-5 shrink-0 text-arterial" />
      <div className="flex-1">
        <p className="font-medium text-bone">{t('banner.blockedTitle')}</p>
        <p className="mt-1 text-ghost">{t('banner.blockedBody')}</p>
        <Link
          to="/app/settings"
          className="mt-2 inline-block text-plasma underline-offset-2 hover:underline"
        >
          {t('banner.openSettings')}
        </Link>
      </div>
    </div>
  )
}
