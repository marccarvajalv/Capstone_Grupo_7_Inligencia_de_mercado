import { useEffect, useState } from 'react'
import { useApp } from '../store/AppContext'
import { formatDuration } from '../lib/utils'
import { Button } from './ui'

export function ProteinTimer() {
  const { state, clearProteinWindow } = useApp()
  const [left, setLeft] = useState(0)

  useEffect(() => {
    if (!state.proteinTimerEndsAt) {
      setLeft(0)
      return
    }
    const tick = () => {
      const ms = new Date(state.proteinTimerEndsAt!).getTime() - Date.now()
      if (ms <= 0) {
        setLeft(0)
        clearProteinWindow()
        return
      }
      setLeft(Math.ceil(ms / 1000))
    }
    tick()
    const id = window.setInterval(tick, 1000)
    return () => window.clearInterval(id)
  }, [state.proteinTimerEndsAt, clearProteinWindow])

  if (!left) return null

  return (
    <div className="mx-4 mt-3 flex items-center justify-between rounded-xl border border-bio/30 bg-bio/10 px-3 py-2 text-sm animate-slide-up">
      <div>
        <p className="text-bio">Ventana de nutrición</p>
        <p className="num text-bone">{formatDuration(left)}</p>
      </div>
      <Button size="sm" variant="ghost" onClick={clearProteinWindow}>
        Cerrar
      </Button>
    </div>
  )
}
