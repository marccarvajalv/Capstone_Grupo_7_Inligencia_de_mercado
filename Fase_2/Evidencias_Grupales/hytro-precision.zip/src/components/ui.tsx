import { cn } from '../lib/utils'
import type { ButtonHTMLAttributes, InputHTMLAttributes, ReactNode } from 'react'

export function Button({
  className,
  variant = 'primary',
  size = 'md',
  ...props
}: ButtonHTMLAttributes<HTMLButtonElement> & {
  variant?: 'primary' | 'secondary' | 'danger' | 'ghost' | 'outline'
  size?: 'sm' | 'md' | 'lg'
}) {
  return (
    <button
      className={cn(
        'inline-flex items-center justify-center gap-2 rounded-xl font-medium transition active:scale-[0.98] disabled:pointer-events-none disabled:opacity-40',
        size === 'sm' && 'h-9 px-3 text-sm',
        size === 'md' && 'h-11 px-4 text-sm',
        size === 'lg' && 'h-12 px-5 text-base',
        variant === 'primary' && 'bg-plasma text-bg hover:brightness-110',
        variant === 'secondary' && 'bg-bg-panel text-bone border border-border hover:border-plasma/40',
        variant === 'danger' && 'bg-arterial text-white hover:brightness-110',
        variant === 'ghost' && 'bg-transparent text-ghost hover:text-bone hover:bg-white/5',
        variant === 'outline' && 'border border-plasma/50 text-plasma hover:bg-plasma/10',
        className,
      )}
      {...props}
    />
  )
}

export function Input({
  className,
  ...props
}: InputHTMLAttributes<HTMLInputElement>) {
  return (
    <input
      className={cn(
        'h-11 w-full rounded-xl border border-border bg-bg-panel px-3 text-bone outline-none placeholder:text-muted focus:border-plasma/60',
        className,
      )}
      {...props}
    />
  )
}

export function Label({ children, className }: { children: ReactNode; className?: string }) {
  return <label className={cn('mb-1.5 block text-sm text-ghost', className)}>{children}</label>
}

export function Panel({
  children,
  className,
}: {
  children: ReactNode
  className?: string
}) {
  return (
    <div
      className={cn(
        'rounded-2xl border border-border/80 bg-bg-panel/80 p-4 backdrop-blur-sm',
        className,
      )}
    >
      {children}
    </div>
  )
}

export function SectionTitle({
  title,
  subtitle,
}: {
  title: string
  subtitle?: string
}) {
  return (
    <div className="mb-4">
      <h2 className="text-xl font-semibold tracking-tight text-bone">{title}</h2>
      {subtitle ? <p className="mt-1 text-sm text-ghost">{subtitle}</p> : null}
    </div>
  )
}

export function Badge({
  children,
  tone = 'plasma',
}: {
  children: ReactNode
  tone?: 'plasma' | 'bio' | 'arterial' | 'muted'
}) {
  return (
    <span
      className={cn(
        'inline-flex items-center rounded-md px-2 py-0.5 text-xs font-medium',
        tone === 'plasma' && 'bg-plasma/15 text-plasma',
        tone === 'bio' && 'bg-bio/15 text-bio',
        tone === 'arterial' && 'bg-arterial/15 text-arterial',
        tone === 'muted' && 'bg-white/5 text-ghost',
      )}
    >
      {children}
    </span>
  )
}

export function ProgressBar({ value, max = 100 }: { value: number; max?: number }) {
  const pct = Math.min(100, Math.round((value / max) * 100))
  return (
    <div className="h-2 w-full overflow-hidden rounded-full bg-white/10">
      <div
        className="h-full rounded-full bg-plasma transition-all duration-500"
        style={{ width: `${pct}%` }}
      />
    </div>
  )
}

export function ToggleChip({
  selected,
  onClick,
  children,
  disabled,
}: {
  selected: boolean
  onClick: () => void
  children: ReactNode
  disabled?: boolean
}) {
  return (
    <button
      type="button"
      disabled={disabled}
      onClick={onClick}
      className={cn(
        'rounded-xl border px-3 py-2 text-left text-sm transition',
        selected
          ? 'border-plasma bg-plasma/15 text-bone'
          : 'border-border bg-bg-elevated text-ghost hover:border-plasma/30',
        disabled && 'opacity-40',
      )}
    >
      {children}
    </button>
  )
}
