import {
  createContext,
  useCallback,
  useContext,
  useMemo,
  useState,
  type ReactNode,
} from 'react'
import en from './locales/en'
import es from './locales/es'
import fr from './locales/fr'
import type { Dict, Locale, TranslationParams } from './types'

const LOCALE_KEY = 'hytro.locale'
/** First launch / no preference → English (Alloxentric default). */
const DEFAULT_LOCALE: Locale = 'en'

const dictionaries: Record<Locale, Dict> = { en, es, fr }

const LOCALES: Locale[] = ['en', 'es', 'fr']

function isLocale(value: string | null): value is Locale {
  return value === 'en' || value === 'es' || value === 'fr'
}

function readStoredLocale(): Locale {
  try {
    const raw = localStorage.getItem(LOCALE_KEY)
    if (isLocale(raw)) return raw
  } catch {
    /* ignore */
  }
  return DEFAULT_LOCALE
}

function resolvePath(dict: Dict, path: string): string | undefined {
  const parts = path.split('.')
  let cur: string | Dict | undefined = dict
  for (const part of parts) {
    if (!cur || typeof cur === 'string') return undefined
    cur = cur[part]
  }
  return typeof cur === 'string' ? cur : undefined
}

function interpolate(template: string, params?: TranslationParams): string {
  if (!params) return template
  return template.replace(/\{(\w+)\}/g, (_, key: string) =>
    params[key] !== undefined ? String(params[key]) : `{${key}}`,
  )
}

interface I18nContextValue {
  locale: Locale
  setLocale: (locale: Locale) => void
  t: (key: string, params?: TranslationParams) => string
  locales: Locale[]
}

const I18nContext = createContext<I18nContextValue | null>(null)

export function I18nProvider({ children }: { children: ReactNode }) {
  const [locale, setLocaleState] = useState<Locale>(() => {
    const initial = readStoredLocale()
    try {
      document.documentElement.lang = initial
    } catch {
      /* ignore */
    }
    return initial
  })

  const setLocale = useCallback((next: Locale) => {
    setLocaleState(next)
    try {
      localStorage.setItem(LOCALE_KEY, next)
      document.documentElement.lang = next
    } catch {
      /* ignore */
    }
  }, [])

  const t = useCallback(
    (key: string, params?: TranslationParams) => {
      const fromActive = resolvePath(dictionaries[locale], key)
      const fromFallback = resolvePath(dictionaries.en, key)
      return interpolate(fromActive ?? fromFallback ?? key, params)
    },
    [locale],
  )

  const value = useMemo(
    () => ({ locale, setLocale, t, locales: LOCALES }),
    [locale, setLocale, t],
  )

  return <I18nContext.Provider value={value}>{children}</I18nContext.Provider>
}

export function useI18n() {
  const ctx = useContext(I18nContext)
  if (!ctx) throw new Error('useI18n must be used within I18nProvider')
  return ctx
}
