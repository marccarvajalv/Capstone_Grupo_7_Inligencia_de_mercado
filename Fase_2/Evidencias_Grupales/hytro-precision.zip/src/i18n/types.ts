export type Locale = 'en' | 'es' | 'fr'

export type Dict = {
  [key: string]: string | Dict
}

export type TranslationParams = Record<string, string | number>
