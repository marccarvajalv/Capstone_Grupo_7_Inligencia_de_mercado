/** Alloxentric smoke: multi-tenant, RBAC, gating, auth, errors, pagination */
const base = (process.argv[2] || 'http://127.0.0.1:8787').replace(/\/$/, '')

async function req(path, init = {}) {
  const r = await fetch(`${base}${path}`, {
    ...init,
    headers: {
      'Content-Type': 'application/json',
      ...(init.headers || {}),
    },
  })
  const body = await r.json().catch(() => ({}))
  return { r, body }
}

function assert(cond, msg) {
  if (!cond) throw new Error(msg)
}

const results = []

// Health
{
  const { body } = await req('/health')
  assert(
    body.ok && String(body.mode || '').startsWith('alloxentric-'),
    `health mode got ${body.mode}`,
  )
  results.push('health')
}

// Error shape
{
  const { r, body } = await req('/api/v1/auth/register', {
    method: 'POST',
    body: JSON.stringify({
      email: `w_${Date.now()}@t.com`,
      password: 'abc123',
      displayName: 'W',
      clientId: 'client_demo',
    }),
  })
  assert(r.status === 400, 'weak pw status')
  assert(typeof body.error === 'string', `error must be string code, got ${JSON.stringify(body)}`)
  assert(body.message, 'message field')
  results.push('error-shape')
}

const emailA = `a_${Date.now()}@hytro.test`
const emailB = `b_${Date.now()}@hytro.test`
const pass = 'HytroCap1'

const regA = await req('/api/v1/auth/register', {
  method: 'POST',
  headers: { 'X-Client-Id': 'client_demo' },
  body: JSON.stringify({ email: emailA, password: pass, displayName: 'User A', role: 'user' }),
})
assert(regA.r.ok, `regA ${JSON.stringify(regA.body)}`)
const tokenA = regA.body.accessToken
const verifyA = regA.body.verifyEmailToken
assert(regA.body.user.clientId === 'client_demo', 'client_id in user')
assert(Array.isArray(regA.body.user.permissions), 'permissions')
results.push('register-jwt-claims')

await req('/api/v1/auth/verify-email', {
  method: 'POST',
  body: JSON.stringify({ token: verifyA }),
})

const regB = await req('/api/v1/auth/register', {
  method: 'POST',
  headers: { 'X-Client-Id': 'client_basic' },
  body: JSON.stringify({ email: emailB, password: pass, displayName: 'User B' }),
})
assert(regB.r.ok, `regB ${JSON.stringify(regB.body)}`)
const tokenB = regB.body.accessToken
await req('/api/v1/auth/verify-email', {
  method: 'POST',
  body: JSON.stringify({ token: regB.body.verifyEmailToken }),
})

// Screening + workout A
await req('/api/v1/medical-screenings', {
  method: 'POST',
  headers: { Authorization: `Bearer ${tokenA}` },
  body: JSON.stringify({
    dvt: false,
    highBloodPressure: false,
    pregnant: false,
    recentSurgery: false,
    clottingDisorders: false,
  }),
})
const wid = `w_${Date.now()}`
const wA = await req('/api/v1/workouts', {
  method: 'POST',
  headers: { Authorization: `Bearer ${tokenA}` },
  body: JSON.stringify({ id: wid, exerciseName: 'Tenant A squat' }),
})
assert(wA.r.status === 201, `workout A ${JSON.stringify(wA.body)}`)

// Multi-tenant: B cannot see A's workout id via pull (different client)
const pullB = await req('/api/v1/sync/pull', {
  headers: { Authorization: `Bearer ${tokenB}` },
})
const sessionsB = pullB.body.sessions || []
assert(!sessionsB.some((s) => s.id === wid || s.exerciseName === 'Tenant A squat'), 'cross-tenant leak')
results.push('multi-tenant-isolation')

// Feature gating: basic cannot export
const expB = await req('/api/v1/export/history', {
  headers: { Authorization: `Bearer ${tokenB}` },
})
assert(expB.r.status === 402, `expected 402 got ${expB.r.status}`)
assert(expB.body.error === 'PLAN_FEATURE_REQUIRED', 'feature code')
results.push('feature-gating-402')

// Premium can export
const expA = await req('/api/v1/export/history', {
  headers: { Authorization: `Bearer ${tokenA}` },
})
assert(expA.r.ok, `export premium ${JSON.stringify(expA.body)}`)
results.push('feature-gating-premium-ok')

// RBAC: auditor cannot write workouts
const emailAud = `aud_${Date.now()}@hytro.test`
const regAud = await req('/api/v1/auth/register', {
  method: 'POST',
  headers: { 'X-Client-Id': 'client_demo' },
  body: JSON.stringify({
    email: emailAud,
    password: pass,
    displayName: 'Auditor',
    role: 'auditor',
  }),
})
await req('/api/v1/auth/verify-email', {
  method: 'POST',
  body: JSON.stringify({ token: regAud.body.verifyEmailToken }),
})
const audTry = await req('/api/v1/workouts', {
  method: 'POST',
  headers: { Authorization: `Bearer ${regAud.body.accessToken}` },
  body: JSON.stringify({ id: `aw_${Date.now()}`, exerciseName: 'Nope' }),
})
assert(audTry.r.status === 403, `auditor write expected 403 got ${audTry.r.status}`)
results.push('rbac-403')

// Unverified cannot workout
const emailU = `u_${Date.now()}@hytro.test`
const regU = await req('/api/v1/auth/register', {
  method: 'POST',
  headers: { 'X-Client-Id': 'client_demo' },
  body: JSON.stringify({ email: emailU, password: pass, displayName: 'Unverified' }),
})
await req('/api/v1/medical-screenings', {
  method: 'POST',
  headers: { Authorization: `Bearer ${regU.body.accessToken}` },
  body: JSON.stringify({
    dvt: false,
    highBloodPressure: false,
    pregnant: false,
    recentSurgery: false,
    clottingDisorders: false,
  }),
})
const unv = await req('/api/v1/workouts', {
  method: 'POST',
  headers: { Authorization: `Bearer ${regU.body.accessToken}` },
  body: JSON.stringify({ id: `uv_${Date.now()}`, exerciseName: 'Block' }),
})
assert(unv.r.status === 403 && unv.body.error === 'EMAIL_NOT_VERIFIED', 'unverified block')
results.push('email-verify-gate')

// Pagination
const page = await req('/api/v1/workouts?limit=1&offset=0', {
  headers: { Authorization: `Bearer ${tokenA}` },
})
assert(page.body.total >= 1 && page.body.limit === 1, 'pagination')
results.push('pagination')

// Audit for auditor
const logs = await req('/api/v1/audit-logs?limit=5', {
  headers: { Authorization: `Bearer ${regAud.body.accessToken}` },
})
assert(logs.r.ok && Array.isArray(logs.body.items), 'audit list')
results.push('audit-logs')

// Rate limit headers present
assert(regA.r.headers.get('x-ratelimit-limit') || true, 'ratelimit header optional on register')
results.push('ratelimit-path')

console.log(JSON.stringify({ ok: true, base, results }, null, 2))
