#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
SRC="${HYTRO_DATA_DIR:-$ROOT/server/data}/db.json"
DEST_DIR="${1:-$ROOT/server/backups}"
mkdir -p "$DEST_DIR"
STAMP=$(date -u +%Y%m%dT%H%M%SZ)
cp "$SRC" "$DEST_DIR/db-$STAMP.json"
echo "Backup: $DEST_DIR/db-$STAMP.json"
