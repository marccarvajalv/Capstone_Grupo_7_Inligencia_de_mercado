/**
 * Smoke test: Auth signup + Firestore user doc against local emulators.
 * Usage: node scripts/verify-backend.mjs [host]
 */
import { initializeApp } from 'firebase/app'
import {
  connectAuthEmulator,
  createUserWithEmailAndPassword,
  getAuth,
  signInWithEmailAndPassword,
} from 'firebase/auth'
import {
  connectFirestoreEmulator,
  doc,
  getDoc,
  getFirestore,
  setDoc,
} from 'firebase/firestore'

const host = process.argv[2] || process.env.VITE_FIREBASE_EMULATOR_HOST || '127.0.0.1'
const email = `verify_${Date.now()}@hytro.test`
const password = 'hytro-verify-123'
const displayName = 'Verify Backend'

const app = initializeApp({
  apiKey: 'demo-api-key',
  authDomain: 'demo-hytro.firebaseapp.com',
  projectId: 'demo-hytro',
  appId: '1:123456789012:web:hytrodemo',
})

const auth = getAuth(app)
const db = getFirestore(app)
connectAuthEmulator(auth, `http://${host}:9099`, { disableWarnings: true })
connectFirestoreEmulator(db, host, 8080)

const cred = await createUserWithEmailAndPassword(auth, email, password)
const uid = cred.user.uid
const now = new Date().toISOString()

await setDoc(doc(db, 'users', uid), {
  email,
  displayName,
  onboardingComplete: false,
  onboardingStep: 0,
  createdAt: now,
  updatedAt: now,
  preferences: { units: 'metric' },
})

await setDoc(doc(db, 'users', uid, 'profile', 'current'), {
  gender: 'other',
  weightKg: 72,
  heightCm: 175,
  systolicMmHg: 118,
  diastolicMmHg: 76,
  limbCircumferences: {
    leftArmCm: 31,
    rightArmCm: 31,
    leftLegCm: 54,
    rightLegCm: 54,
  },
  updatedAt: now,
})

await signInWithEmailAndPassword(auth, email, password)
const snap = await getDoc(doc(db, 'users', uid))
const profile = await getDoc(doc(db, 'users', uid, 'profile', 'current'))

if (!snap.exists() || !profile.exists()) {
  console.error('FAIL: docs missing after write')
  process.exit(1)
}

console.log(
  JSON.stringify(
    {
      ok: true,
      host,
      uid,
      email,
      user: snap.data(),
      profile: profile.data(),
    },
    null,
    2,
  ),
)
process.exit(0)
