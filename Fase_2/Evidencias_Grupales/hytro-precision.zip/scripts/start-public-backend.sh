#!/usr/bin/env bash
# Keep Capstone API up and expose a STABLE public hostname.
# Preferred: RENDER_URL / HYTRO_PUBLIC_URL (PaaS fijo).
# Fallback: localtunnel fixed subdomain hytro-precision-capstone.loca.lt
# Legacy: Cloudflare quick tunnel (URL cambia — no usar para cierre).
set -euo pipefail

ROOT="$(cd "$(dirname "$0")/.." && pwd)"
API_PORT="${PORT:-8787}"
JWT_SECRET="${HYTRO_JWT_SECRET:-hytro-capstone-prod-2026}"
URL_FILE="${HYTRO_URL_FILE:-/tmp/hytro-api-public-url.txt}"
LOG_DIR="${HYTRO_LOG_DIR:-/tmp/hytro-backend-logs}"
FIXED_LT_SUBDOMAIN="${HYTRO_LT_SUBDOMAIN:-hytro-precision-capstone}"
mkdir -p "$LOG_DIR" "$ROOT/server/data"

cd "$ROOT/server"
if [ ! -d node_modules ]; then
  npm install
fi

start_api() {
  if curl -sf "http://127.0.0.1:${API_PORT}/health" >/dev/null 2>&1; then
    echo "[keep-alive] API already up on :${API_PORT}"
    return 0
  fi
  echo "[keep-alive] starting API on :${API_PORT}"
  PORT="$API_PORT" HYTRO_JWT_SECRET="$JWT_SECRET" HYTRO_DATA_DIR="${HYTRO_DATA_DIR:-$ROOT/server/data}" \
    nohup npm start >"$LOG_DIR/api.log" 2>&1 &
  echo $! >"$LOG_DIR/api.pid"
  for _ in $(seq 1 40); do
    if curl -sf "http://127.0.0.1:${API_PORT}/health" >/dev/null 2>&1; then
      echo "[keep-alive] API ready"
      return 0
    fi
    sleep 0.5
  done
  echo "[keep-alive] API failed to start" >&2
  return 1
}

write_url() {
  local url="$1"
  echo "$url" | tee "$URL_FILE" "$ROOT/server/.public-url"
}

start_tunnel() {
  if [ -n "${RENDER_URL:-}" ]; then
    write_url "${RENDER_URL%/}"
    echo "[keep-alive] using RENDER_URL (host fijo)"
    return 0
  fi
  if [ -n "${HYTRO_PUBLIC_URL:-}" ]; then
    write_url "${HYTRO_PUBLIC_URL%/}"
    echo "[keep-alive] using HYTRO_PUBLIC_URL (host fijo)"
    return 0
  fi

  # Fixed-subdomain localtunnel (URL estable entre reinicios del proceso)
  if ! curl -sf -H "Bypass-Tunnel-Reminder: 1" \
    "https://${FIXED_LT_SUBDOMAIN}.loca.lt/health" >/dev/null 2>&1; then
    echo "[keep-alive] starting localtunnel subdomain=${FIXED_LT_SUBDOMAIN}"
    pkill -f "localtunnel.*${API_PORT}" 2>/dev/null || true
    npx --yes localtunnel --port "$API_PORT" --subdomain "$FIXED_LT_SUBDOMAIN" \
      >"$LOG_DIR/tunnel.log" 2>&1 &
    echo $! >"$LOG_DIR/tunnel.pid"
    sleep 3
  fi
  write_url "https://${FIXED_LT_SUBDOMAIN}.loca.lt"
  echo "[keep-alive] public URL: https://${FIXED_LT_SUBDOMAIN}.loca.lt"
}

ONCE="${1:-}"
start_api
start_tunnel

if [ "$ONCE" = "--once" ]; then
  exit 0
fi

echo "[keep-alive] watchdog running"
while true; do
  sleep 20
  start_api || true
  PUB=$(cat "$URL_FILE" 2>/dev/null || true)
  if [ -z "$PUB" ] || ! curl -sf -H "Bypass-Tunnel-Reminder: 1" "$PUB/health" >/dev/null 2>&1; then
    start_tunnel || true
  fi
done
