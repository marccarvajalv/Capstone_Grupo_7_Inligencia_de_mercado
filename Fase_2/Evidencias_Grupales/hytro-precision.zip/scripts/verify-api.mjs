/** Smoke against Capstone/Alloxentric API. Usage: node scripts/verify-api.mjs [baseUrl] */
const base = (process.argv[2] || process.env.VITE_API_BASE || 'http://127.0.0.1:8787').replace(
  /\/$/,
  '',
)

function assert(cond, msg) {
  if (!cond) throw new Error(msg)
}

function codeOf(body) {
  if (typeof body?.error === 'string') return body.error
  return body?.error?.code
}

let ipSeq = 0
async function json(path, init = {}) {
  ipSeq += 1
  const r = await fetch(`${base}${path}`, {
    ...init,
    headers: {
      'Content-Type': 'application/json',
      'X-Client-Id': 'client_demo',
      'X-Forwarded-For': `203.0.113.${(ipSeq % 200) + 1}`,
      ...(init.headers || {}),
    },
  })
  const body = await r.json().catch(() => ({}))
  return { r, body }
}

const health = await fetch(`${base}/health`).then((r) => r.json())
assert(health.ok, 'health failed')

const openapi = await fetch(`${base}/openapi.yaml`)
assert(openapi.ok, 'openapi.yaml missing')

{
  const { r } = await json('/api/v1/auth/register', {
    method: 'POST',
    body: JSON.stringify({
      email: `weak_${Date.now()}@hytro.test`,
      password: 'short',
      displayName: 'Weak',
    }),
  })
  assert(r.status === 400, `weak password should 400, got ${r.status}`)
}

const email = `capstone_${Date.now()}@hytro.test`
const password = 'HytroCap1'
const blockedEmail = `blocked_${Date.now()}@hytro.test`

const reg = await json('/api/v1/auth/register', {
  method: 'POST',
  body: JSON.stringify({ email, password, displayName: 'Capstone Tester' }),
})
assert(reg.r.ok, `register failed: ${JSON.stringify(reg.body)}`)
const accessToken = reg.body.accessToken || reg.body.token
assert(accessToken, 'missing access token')
if (reg.body.verifyEmailToken) {
  await json('/api/v1/auth/verify-email', {
    method: 'POST',
    body: JSON.stringify({ token: reg.body.verifyEmailToken }),
  })
}

await json('/api/v1/medical-screenings', {
  method: 'POST',
  headers: { Authorization: `Bearer ${accessToken}` },
  body: JSON.stringify({
    dvt: false,
    highBloodPressure: false,
    pregnant: false,
    recentSurgery: false,
    clottingDisorders: false,
  }),
})

const workoutId = `w_${Date.now()}`
const workout = await json('/api/v1/workouts', {
  method: 'POST',
  headers: { Authorization: `Bearer ${accessToken}` },
  body: JSON.stringify({ id: workoutId, exerciseName: 'Squat', totalDurationSeconds: 120 }),
})
assert(workout.r.status === 201, `workout create failed: ${JSON.stringify(workout.body)}`)

const dup = await json('/api/v1/workouts', {
  method: 'POST',
  headers: { Authorization: `Bearer ${accessToken}` },
  body: JSON.stringify({ id: workoutId, exerciseName: 'Squat' }),
})
assert(dup.r.status === 409, `expected DUPLICATE_WORKOUT 409, got ${dup.r.status}`)
assert(codeOf(dup.body) === 'DUPLICATE_WORKOUT', 'missing DUPLICATE_WORKOUT code')

const blockedReg = await json('/api/v1/auth/register', {
  method: 'POST',
  body: JSON.stringify({ email: blockedEmail, password, displayName: 'Blocked User' }),
})
const blockedToken = blockedReg.body.accessToken || blockedReg.body.token
if (blockedReg.body.verifyEmailToken) {
  await json('/api/v1/auth/verify-email', {
    method: 'POST',
    body: JSON.stringify({ token: blockedReg.body.verifyEmailToken }),
  })
}
await json('/api/v1/medical-screenings', {
  method: 'POST',
  headers: { Authorization: `Bearer ${blockedToken}` },
  body: JSON.stringify({
    dvt: true,
    highBloodPressure: false,
    pregnant: false,
    recentSurgery: false,
    clottingDisorders: false,
  }),
})
const blockedWorkout = await json('/api/v1/workouts', {
  method: 'POST',
  headers: { Authorization: `Bearer ${blockedToken}` },
  body: JSON.stringify({ id: `bw_${Date.now()}`, exerciseName: 'Should fail' }),
})
assert(blockedWorkout.r.status === 403, `expected medical 403, got ${blockedWorkout.r.status}`)
assert(codeOf(blockedWorkout.body) === 'MEDICAL_CLEARANCE_REQUIRED', 'missing MEDICAL code')

console.log(
  JSON.stringify(
    {
      ok: true,
      base,
      email,
      checks: [
        'health',
        'openapi',
        'password-policy',
        'register-verify',
        'medical-block-403',
        'duplicate-workout-409',
      ],
    },
    null,
    2,
  ),
)
