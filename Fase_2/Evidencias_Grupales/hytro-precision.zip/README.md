# Hytro Precision

App Capstone BFR (Vite + React + TypeScript + Tailwind) + Capacitor Android.  
API Hono en `server/` con contrato `/api/v1`.

**Hosting objetivo (jefatura):** GCP — Cloud Run + Firestore + Firebase Auth.  
Local/CI puede seguir en SQLite; producción/emulador usa Firestore.

## Arranque local (SQLite)

```bash
npm --prefix server install
HYTRO_PERSISTENCE=sqlite HYTRO_AUTH_PROVIDER=local npm run backend:api
npm run verify:alloxentric -- http://127.0.0.1:8787
```

## Firestore + Firebase Auth (Emulator Suite)

```bash
npm install
npm run backend                 # Auth :9099 · Firestore :8080
npm run backend:api:firestore   # API contra emuladores
npm run verify:alloxentric -- http://127.0.0.1:8787
```

## Cloud Run (Fase 1)

Requiere proyecto GCP con facturación + presupuesto.

```bash
export PROJECT_ID=tu-proyecto
export BILLING_ACCOUNT=billingAccounts/XXXXXX-XXXXXX-XXXXXX
export REGION=us-central1
bash infra/gcloud/bootstrap-project.sh
bash infra/gcloud/deploy.sh
npm run verify:alloxentric -- "$URL"
```

Manual completo: ver Agent Store `docs/hytro-manual-deployment-gcp.md`.

## Cliente / APK

```bash
echo "VITE_API_BASE=https://YOUR-SERVICE.run.app" > .env
echo "VITE_ROUTER_HASH=true" >> .env
npm install && npm run build
```

`VITE_API_BASE` se define **por build** (portable a cuenta Alloxentric).

## Scripts

| Comando | Uso |
|---|---|
| `npm run backend:api` | API SQLite |
| `npm run backend:api:firestore` | API + Emulator Auth/Firestore |
| `npm run verify:alloxentric` | Suite multi-tenant / RBAC / gating |
| `npm run deploy:gcp` | `infra/gcloud/deploy.sh` |
| `npm run lint` / `npm run build` | Calidad + web |

## Variables clave

| Variable | Valores |
|----------|---------|
| `HYTRO_PERSISTENCE` | `sqlite` \| `firestore` |
| `HYTRO_AUTH_PROVIDER` | `local` \| `firebase` |
| `PROJECT_ID` | Proyecto GCP / `demo-hytro` |
| `VITE_API_BASE` | URL pública de la API |

## Limitaciones

- Deploy real a `*.run.app` necesita titular de facturación (humano).
- BigQuery / Vertex fuera o pendientes según free tier.
- Túnel local = solo demo; no cumple PRD.
