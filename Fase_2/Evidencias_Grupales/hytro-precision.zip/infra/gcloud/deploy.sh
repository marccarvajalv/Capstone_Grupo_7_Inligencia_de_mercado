#!/usr/bin/env bash
# Deploy Hytro API to Cloud Run (portable — all IDs from env).
# Required: PROJECT_ID, REGION (default us-central1), ARTIFACT_REPO
set -euo pipefail

: "${PROJECT_ID:?Set PROJECT_ID}"
REGION="${REGION:-us-central1}"
SERVICE="${SERVICE:-hytro-api}"
ARTIFACT_REPO="${ARTIFACT_REPO:-hytro}"
IMAGE="${REGION}-docker.pkg.dev/${PROJECT_ID}/${ARTIFACT_REPO}/${SERVICE}:$(git rev-parse --short HEAD 2>/dev/null || echo latest)"

echo "==> Project ${PROJECT_ID} region ${REGION}"
gcloud config set project "${PROJECT_ID}"

gcloud services enable \
  run.googleapis.com \
  artifactregistry.googleapis.com \
  firestore.googleapis.com \
  firebase.googleapis.com \
  secretmanager.googleapis.com \
  logging.googleapis.com \
  monitoring.googleapis.com \
  storage.googleapis.com \
  --project "${PROJECT_ID}"

gcloud artifacts repositories describe "${ARTIFACT_REPO}" --location="${REGION}" >/dev/null 2>&1 || \
  gcloud artifacts repositories create "${ARTIFACT_REPO}" \
    --repository-format=docker --location="${REGION}" --description="Hytro images"

gcloud builds submit --tag "${IMAGE}" --project "${PROJECT_ID}"

GCS_BUCKET="${GCS_BUCKET:-${PROJECT_ID}-hytro-media}"
gcloud storage buckets describe "gs://${GCS_BUCKET}" >/dev/null 2>&1 || \
  gcloud storage buckets create "gs://${GCS_BUCKET}" --location="${REGION}" --uniform-bucket-level-access

gcloud run deploy "${SERVICE}" \
  --image "${IMAGE}" \
  --region "${REGION}" \
  --platform managed \
  --allow-unauthenticated \
  --min-instances=0 \
  --max-instances=3 \
  --cpu=1 \
  --memory=512Mi \
  --set-env-vars="HYTRO_PERSISTENCE=firestore,HYTRO_AUTH_PROVIDER=firebase,PROJECT_ID=${PROJECT_ID},GOOGLE_CLOUD_PROJECT=${PROJECT_ID},FIREBASE_PROJECT_ID=${PROJECT_ID},GCS_BUCKET=${GCS_BUCKET},HYTRO_DEFAULT_CLIENT=client_demo" \
  --project "${PROJECT_ID}"

URL="$(gcloud run services describe "${SERVICE}" --region "${REGION}" --format='value(status.url)')"
echo "Deployed: ${URL}"
echo "Health:   ${URL}/health"
echo "OpenAPI:  ${URL}/openapi.yaml"
