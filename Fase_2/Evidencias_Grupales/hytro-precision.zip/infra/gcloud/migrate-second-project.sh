#!/usr/bin/env bash
# Hito 3 rehearsal: recreate stack on a second project from env only.
set -euo pipefail

: "${PROJECT_ID:?Set PROJECT_ID (staging/rehearsal project)}"
: "${BILLING_ACCOUNT:?Set BILLING_ACCOUNT}"
REGION="${REGION:-us-central1}"
START="$(date -u +%s)"
LOG="${MIGRATE_LOG:-/tmp/hytro-migrate-rehearsal.log}"

{
  echo "=== Migration rehearsal $(date -u -Iseconds) → ${PROJECT_ID}"
  bash "$(dirname "$0")/bootstrap-project.sh"
  bash "$(dirname "$0")/deploy.sh"
  URL="$(gcloud run services describe hytro-api --region "${REGION}" --format='value(status.url)')"
  curl -sf "${URL}/health" | tee /tmp/hytro-health-rehearsal.json
  END="$(date -u +%s)"
  echo "ElapsedSeconds=$((END - START))"
} 2>&1 | tee "${LOG}"

echo "Wrote ${LOG}"
