#!/usr/bin/env bash
# One-time Fase 1 bootstrap (requires billing account linked to PROJECT_ID).
set -euo pipefail

: "${PROJECT_ID:?Set PROJECT_ID}"
: "${BILLING_ACCOUNT:?Set BILLING_ACCOUNT (billingAccounts/XXXXXX-XXXXXX-XXXXXX)}"
REGION="${REGION:-us-central1}"
BUDGET_AMOUNT="${BUDGET_AMOUNT:-10}"

echo "Creating/linking project ${PROJECT_ID}…"
gcloud projects describe "${PROJECT_ID}" >/dev/null 2>&1 || \
  gcloud projects create "${PROJECT_ID}" --name="Hytro Precision Fase 1"

gcloud billing projects link "${PROJECT_ID}" --billing-account="${BILLING_ACCOUNT}"

gcloud config set project "${PROJECT_ID}"
gcloud services enable \
  run.googleapis.com artifactregistry.googleapis.com firestore.googleapis.com \
  firebase.googleapis.com secretmanager.googleapis.com logging.googleapis.com \
  monitoring.googleapis.com storage.googleapis.com cloudbilling.googleapis.com \
  --project "${PROJECT_ID}"

# Firestore in Native mode (default DB only — free tier)
gcloud firestore databases describe --database='(default)' --project="${PROJECT_ID}" >/dev/null 2>&1 || \
  gcloud firestore databases create --location="${REGION}" --project="${PROJECT_ID}"

echo "Set a budget alert of ~USD ${BUDGET_AMOUNT} in console:"
echo "  https://console.cloud.google.com/billing/budgets?project=${PROJECT_ID}"
echo "Then run: PROJECT_ID=${PROJECT_ID} REGION=${REGION} bash infra/gcloud/deploy.sh"
