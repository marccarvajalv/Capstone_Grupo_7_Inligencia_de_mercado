# Infra GCP (Fase 1)

Scripts portables — **cero IDs hardcodeados**. Todo via `PROJECT_ID`, `REGION`, `BILLING_ACCOUNT`.

| Script | Uso |
|--------|-----|
| `gcloud/bootstrap-project.sh` | Crear/vincular billing, APIs, Firestore `(default)` |
| `gcloud/deploy.sh` | Build + Cloud Run `min-instances=0` + bucket |
| `gcloud/migrate-second-project.sh` | Ensayo Hito 3 en segundo proyecto |

Manual completo (Agent Store): `docs/hytro-manual-deployment-gcp.md`

```bash
export PROJECT_ID=...
export BILLING_ACCOUNT=billingAccounts/...
export REGION=us-central1
bash infra/gcloud/bootstrap-project.sh
bash infra/gcloud/deploy.sh
```
