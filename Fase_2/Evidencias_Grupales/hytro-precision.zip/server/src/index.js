import { serve } from '@hono/node-server'
import { readFileSync } from 'node:fs'
import { dirname, join } from 'node:path'
import { fileURLToPath } from 'node:url'
import { Hono } from 'hono'
import { cors } from 'hono/cors'
import bcrypt from 'bcryptjs'
import { SignJWT, jwtVerify } from 'jose'
import { randomUUID } from 'node:crypto'
import {
  dbPath,
  deleteDocsForUser,
  deleteRefresh,
  deleteRefreshForUser,
  getClient,
  getUserByEmail,
  getUserById,
  hitRate,
  initPersistence,
  insertAudit,
  insertUser,
  listAudit,
  listDocs,
  loadLoginAttempt,
  nowIso,
  persistenceInfo,
  persistenceMode,
  purgeDueUsers,
  saveEmailToken,
  saveLoginAttempt,
  saveRefresh,
  setDoc,
  takeRefresh,
  uid,
  updateUser,
  useEmailToken,
  getDoc,
} from './store.js'
import {
  firebaseCreateUser,
  firebaseSetClaims,
  firebaseSignIn,
  firebaseVerifyEmail,
  firebaseUpdatePassword,
  isFirebaseAuth,
  verifyFirebaseToken,
} from './firebaseAuth.js'
import { hasPermission, permissionsFor, ROLE_PERMISSIONS } from './rbac.js'
import { featuresForPlan, hasFeature } from './features.js'

const __dirname = dirname(fileURLToPath(import.meta.url))
const OPENAPI_YAML = readFileSync(join(__dirname, '..', 'openapi.yaml'), 'utf8')

const PORT = Number(process.env.PORT || 8787)
const JWT_SECRET = new TextEncoder().encode(
  process.env.HYTRO_JWT_SECRET || 'hytro-capstone-dev-secret-change-me',
)
const BCRYPT_COST = 12
const ACCESS_TTL = '15m'
const REFRESH_TTL_MS = 30 * 24 * 60 * 60 * 1000
const LOGIN_WINDOW_MS = 30 * 60 * 1000
const LOGIN_MAX = 10
const DEFAULT_CLIENT = process.env.HYTRO_DEFAULT_CLIENT || 'client_demo'

const app = new Hono()

app.use(
  '*',
  cors({
    origin: '*',
    allowHeaders: ['Content-Type', 'Authorization', 'X-Client-Id'],
    allowMethods: ['GET', 'POST', 'PUT', 'PATCH', 'DELETE', 'OPTIONS'],
    exposeHeaders: ['X-RateLimit-Limit', 'X-RateLimit-Remaining', 'X-RateLimit-Reset'],
  }),
)

/** Alloxentric error shape + brief legacy compat via details.legacy */
function err(c, status, code, message, details = {}) {
  return c.json({ error: code, message, details }, status)
}

function validatePassword(password) {
  if (password.length < 8) return 'Mínimo 8 caracteres'
  if (!/[A-Z]/.test(password)) return 'Debe incluir una mayúscula'
  if (!/[a-z]/.test(password)) return 'Debe incluir una minúscula'
  if (!/\d/.test(password)) return 'Debe incluir un dígito'
  return null
}

function clientIdFrom(c, body = {}) {
  return (
    c.req.header('X-Client-Id') ||
    body.clientId ||
    body.client_id ||
    DEFAULT_CLIENT
  )
}

function rateKey(kind, id) {
  return `${kind}:${id}`
}

function setRateHeaders(c, info) {
  c.header('X-RateLimit-Limit', String(info.limit))
  c.header('X-RateLimit-Remaining', String(info.remaining))
  c.header('X-RateLimit-Reset', String(info.reset))
}

function ipOf(c) {
  return (
    c.req.header('cf-connecting-ip') ||
    c.req.header('x-forwarded-for')?.split(',')[0]?.trim() ||
    '0.0.0.0'
  )
}

async function signAccess(user, client) {
  return new SignJWT({
    uid: user.id,
    email: user.email,
    displayName: user.display_name,
    client_id: user.client_id,
    role: user.role,
    plan: client.plan_tier,
    permissions: permissionsFor(user.role),
    features: featuresForPlan(client.plan_tier),
    email_verified: Boolean(user.email_verified),
    typ: 'access',
  })
    .setProtectedHeader({ alg: 'HS256' })
    .setIssuedAt()
    .setExpirationTime(ACCESS_TTL)
    .sign(JWT_SECRET)
}

async function issueRefresh(user) {
  const token = `${randomUUID()}.${randomUUID()}`
  await saveRefresh(token, user.id, user.client_id, Date.now() + REFRESH_TTL_MS)
  return token
}

async function authContext(c) {
  const header = c.req.header('Authorization') || ''
  const token = header.startsWith('Bearer ') ? header.slice(7) : ''
  if (!token) return null

  if (isFirebaseAuth()) {
    try {
      const decoded = await verifyFirebaseToken(token)
      const user = await getUserById(String(decoded.uid))
      if (!user) return null
      const claimClient = decoded.client_id || decoded.clientId
      if (claimClient && claimClient !== user.client_id) return null
      const client = await getClient(user.client_id)
      if (!client) return null
      return {
        user,
        client,
        payload: {
          uid: decoded.uid,
          client_id: user.client_id,
          role: decoded.role || user.role,
          plan: decoded.tier || client.plan_tier,
        },
      }
    } catch {
      return null
    }
  }

  try {
    const { payload } = await jwtVerify(token, JWT_SECRET)
    if (payload.typ && payload.typ !== 'access') return null
    const user = await getUserById(String(payload.uid))
    if (!user) return null
    if (payload.client_id && payload.client_id !== user.client_id) return null
    const client = await getClient(user.client_id)
    if (!client) return null
    return { user, client, payload }
  } catch {
    return null
  }
}

function publicUser(user, client) {
  let preferences = { units: 'metric' }
  try {
    preferences = JSON.parse(user.preferences_json || '{}')
  } catch {
    /* ignore */
  }
  return {
    id: user.id,
    email: user.email,
    displayName: user.display_name,
    clientId: user.client_id,
    role: user.role,
    plan: client.plan_tier,
    permissions: permissionsFor(user.role),
    features: featuresForPlan(client.plan_tier),
    emailVerified: Boolean(user.email_verified),
    onboardingComplete: Boolean(user.onboarding_complete),
    onboardingStep: Number(user.onboarding_step ?? 0),
    createdAt: user.created_at,
    updatedAt: user.updated_at,
    preferences,
    proteinTimerEndsAt: user.protein_timer_ends_at ?? null,
  }
}

function requirePerm(ctx, permission) {
  return hasPermission(ctx.user.role, permission)
}

function requireFeature(ctx, feature) {
  return hasFeature(ctx.client.plan_tier, feature)
}

async function audit(c, ctx, status, resource) {
  try {
    await insertAudit({
      id: uid(),
      client_id: ctx?.client?.id || clientIdFrom(c) || 'unknown',
      user_id: ctx?.user?.id,
      role: ctx?.user?.role,
      method: c.req.method,
      path: c.req.path,
      resource: resource || c.req.path,
      ip: ipOf(c),
      user_agent: c.req.header('user-agent') || '',
      status,
      success: status < 400,
      created_at: new Date().toISOString(),
    })
  } catch {
    /* never break request on audit */
  }
}

function checkLoginLock(email) {
  const key = email.toLowerCase()
  const now = Date.now()
  const row = loadLoginAttempt(email)
  let fails = []
  try {
    fails = JSON.parse(row.fails_json || '[]').filter((t) => now - t < LOGIN_WINDOW_MS)
  } catch {
    fails = []
  }
  if (row.locked_until && row.locked_until > now) {
    return { ok: false, row: { ...row, fails } }
  }
  if (fails.length >= LOGIN_MAX) {
    const locked_until = now + LOGIN_WINDOW_MS
    saveLoginAttempt(key, JSON.stringify(fails), locked_until)
    return { ok: false, row: { key, fails, locked_until } }
  }
  return { ok: true, row: { key, fails, locked_until: 0 } }
}

function recordLoginFail(email, row) {
  const fails = [...(row.fails || []), Date.now()]
  saveLoginAttempt(email.toLowerCase(), JSON.stringify(fails), row.locked_until || 0)
}

function clearLoginFails(email) {
  saveLoginAttempt(email.toLowerCase(), '[]', 0)
}

async function latestClearance(clientId, userId) {
  const list = (await listDocs(clientId, userId, 'medicalScreenings/')).sort((a, b) =>
    String(a.submittedAt || '') < String(b.submittedAt || '') ? 1 : -1,
  )
  if (!list.length) return { ok: false, reason: 'NO_SCREENING' }
  return { ok: Boolean(list[0].medicalClearance), latest: list[0] }
}

async function buildState(user, client) {
  const clientId = user.client_id
  const userId = user.id
  const root = (await getDoc(clientId, userId, '')) || {}
  const goals = await listDocs(clientId, userId, 'goals/')
  const active = goals.find((g) => g.isActive) ?? null
  return {
    user: publicUser(user, client),
    profile: await getDoc(clientId, userId, 'profile/current'),
    equipment: await getDoc(clientId, userId, 'equipment/current'),
    medicalHistory: (await listDocs(clientId, userId, 'medicalScreenings/')).sort((a, b) =>
      String(a.submittedAt || '') < String(b.submittedAt || '') ? 1 : -1,
    ),
    goal: active,
    goalHistory: goals.filter((g) => !g.isActive),
    devices: await listDocs(clientId, userId, 'devices/'),
    sessions: (await listDocs(clientId, userId, 'workoutSessions/')).sort((a, b) =>
      String(a.createdAt || '') < String(b.createdAt || '') ? 1 : -1,
    ),
    cuffChecks: (await listDocs(clientId, userId, 'cuffChecks/')).sort((a, b) =>
      String(a.createdAt || '') < String(b.createdAt || '') ? 1 : -1,
    ),
    notifications: (await listDocs(clientId, userId, 'notifications/')).sort((a, b) =>
      String(a.createdAt || '') < String(b.createdAt || '') ? 1 : -1,
    ),
    preferences: publicUser(user, client).preferences,
    proteinTimerEndsAt: user.protein_timer_ends_at ?? null,
    _root: root,
  }
}

function paginate(items, query) {
  let limit = Number(query.limit ?? 20)
  let offset = Number(query.offset ?? 0)
  if (!Number.isFinite(limit) || limit < 1) limit = 20
  if (limit > 100) limit = 100
  if (!Number.isFinite(offset) || offset < 0) offset = 0
  const total = items.length
  return { items: items.slice(offset, offset + limit), total, limit, offset }
}

app.get('/health', (c) => {
  const info = persistenceInfo()
  return c.json({
    ok: true,
    service: 'hytro-precision-api',
    mode: `alloxentric-${persistenceMode()}`,
    authProvider: isFirebaseAuth() ? 'firebase' : 'local',
    version: '2.1.0-gcp',
    db: info.detail || dbPath(),
    projectId: info.projectId || null,
    time: new Date().toISOString(),
  })
})

app.get('/openapi.yaml', (c) => {
  c.header('Content-Type', 'application/yaml; charset=utf-8')
  return c.body(OPENAPI_YAML)
})

app.get('/api/v1/rbac/matrix', (c) => c.json({ roles: ROLE_PERMISSIONS }))

async function registerHandler(c) {
  const body = await c.req.json().catch(() => ({}))
  const ip = ipOf(c)
  const clientId = clientIdFrom(c, body)
  const client = await getClient(clientId)
  if (!client) return err(c, 400, 'INVALID_CLIENT', 'client_id inválido')

  const email = String(body.email || '')
    .trim()
    .toLowerCase()
  const password = String(body.password || '')
  const displayName = String(body.displayName || email.split('@')[0] || 'Atleta').trim()
  const role = ROLES_SAFE(body.role)
  if (!email.includes('@')) return err(c, 400, 'INVALID_EMAIL', 'Email inválido')
  const pwErr = validatePassword(password)
  if (pwErr) return err(c, 400, 'WEAK_PASSWORD', pwErr)

  const signupRate = hitRate(rateKey('signup', ip), 5, 15 * 60 * 1000)
  setRateHeaders(c, signupRate)
  if (!signupRate.ok) {
    await audit(c, null, 429, 'auth/register')
    return err(c, 429, 'RATE_LIMITED', 'Máximo 5 registros por 15 min por IP')
  }

  if (await getUserByEmail(clientId, email)) {
    return err(c, 409, 'EMAIL_EXISTS', 'Ese email ya está registrado')
  }

  const now = nowIso()
  let id = uid()
  let accessToken
  let refreshToken
  let passwordHash = await bcrypt.hash(password, BCRYPT_COST)

  if (isFirebaseAuth()) {
    try {
      const created = await firebaseCreateUser({
        email,
        password,
        displayName,
        clientId,
        role,
        tier: client.plan_tier,
      })
      id = created.uid
      passwordHash = ''
      const session = await firebaseSignIn(email, password)
      accessToken = session.idToken
      refreshToken = session.refreshToken
    } catch (e) {
      const msg = String(e?.code || e?.message || e)
      if (msg.includes('EMAIL_EXISTS') || msg.includes('already')) {
        return err(c, 409, 'EMAIL_EXISTS', 'Ese email ya está registrado')
      }
      return err(c, 500, 'FIREBASE_AUTH_ERROR', msg)
    }
  }

  await insertUser({
    id,
    client_id: clientId,
    email,
    password_hash: passwordHash,
    display_name: displayName,
    role,
    email_verified: false,
    onboarding_complete: false,
    onboarding_step: 0,
    preferences: { units: 'metric' },
    created_at: now,
    updated_at: now,
    firebase_uid: id,
  })
  const user = await getUserById(id)
  await setDoc(clientId, id, '', {
    email,
    displayName,
    onboardingComplete: false,
    onboardingStep: 0,
    createdAt: now,
    updatedAt: now,
    preferences: { units: 'metric' },
    client_id: clientId,
  })

  const verifyToken = randomUUID()
  await saveEmailToken(verifyToken, id, 'verify', Date.now() + 24 * 60 * 60 * 1000)
  if (!isFirebaseAuth()) {
    accessToken = await signAccess(user, client)
    refreshToken = await issueRefresh(user)
  }
  await audit(c, { user, client }, 201, 'auth/register')
  return c.json(
    {
      accessToken,
      refreshToken,
      token: accessToken,
      user: publicUser(user, client),
      verifyEmailToken: verifyToken,
    },
    201,
  )
}

function ROLES_SAFE(role) {
  const r = String(role || 'user')
  return ['admin', 'auditor', 'trainer', 'user'].includes(r) ? r : 'user'
}

async function loginHandler(c) {
  const body = await c.req.json().catch(() => ({}))
  const ip = ipOf(c)
  const pub = hitRate(rateKey('public', ip), 20, 60 * 1000)
  setRateHeaders(c, pub)
  if (!pub.ok) return err(c, 429, 'RATE_LIMITED', 'Límite público 20 req/min por IP')

  const clientId = clientIdFrom(c, body)
  const email = String(body.email || '')
    .trim()
    .toLowerCase()
  const password = String(body.password || '')
  const lock = checkLoginLock(email)
  if (!lock.ok) {
    await audit(c, null, 429, 'auth/login')
    return err(c, 429, 'LOGIN_LOCKED', 'Demasiados intentos. Espera 30 minutos.')
  }
  const user = await getUserByEmail(clientId, email)
  const client = await getClient(clientId)

  if (isFirebaseAuth()) {
    if (!user || !client) {
      recordLoginFail(email, lock.row)
      await audit(c, null, 401, 'auth/login')
      return err(c, 401, 'INVALID_CREDENTIALS', 'Credenciales inválidas')
    }
    try {
      const session = await firebaseSignIn(email, password)
      clearLoginFails(email)
      await firebaseSetClaims(user.id, {
        clientId: user.client_id,
        role: user.role,
        tier: client.plan_tier,
      })
      // Re-sign so claims land on next token
      const refreshed = await firebaseSignIn(email, password)
      const userRate = hitRate(rateKey('user', user.id), 60, 60 * 1000)
      setRateHeaders(c, userRate)
      await audit(c, { user, client }, 200, 'auth/login')
      return c.json({
        accessToken: refreshed.idToken || session.idToken,
        refreshToken: refreshed.refreshToken || session.refreshToken,
        token: refreshed.idToken || session.idToken,
        user: publicUser(user, client),
      })
    } catch {
      recordLoginFail(email, lock.row)
      await audit(c, { user, client }, 401, 'auth/login')
      return err(c, 401, 'INVALID_CREDENTIALS', 'Credenciales inválidas')
    }
  }

  if (!user || !client || !(await bcrypt.compare(password, user.password_hash))) {
    recordLoginFail(email, lock.row)
    await audit(c, user && client ? { user, client } : null, 401, 'auth/login')
    return err(c, 401, 'INVALID_CREDENTIALS', 'Credenciales inválidas')
  }
  clearLoginFails(email)
  const userRate = hitRate(rateKey('user', user.id), 60, 60 * 1000)
  setRateHeaders(c, userRate)
  const accessToken = await signAccess(user, client)
  const refreshToken = await issueRefresh(user)
  await audit(c, { user, client }, 200, 'auth/login')
  return c.json({
    accessToken,
    refreshToken,
    token: accessToken,
    user: publicUser(user, client),
  })
}

const v1 = new Hono()

v1.post('/auth/register', registerHandler)
v1.post('/auth/login', loginHandler)

v1.post('/auth/verify-email', async (c) => {
  const body = await c.req.json().catch(() => ({}))
  const token = String(body.token || '')
  const row = await useEmailToken(token, 'verify')
  if (!row) return err(c, 400, 'INVALID_TOKEN', 'Token inválido o expirado')
  await updateUser(row.user_id, { email_verified: 1 })
  if (isFirebaseAuth()) {
    try {
      await firebaseVerifyEmail(row.user_id)
    } catch {
      /* profile flag still set */
    }
  }
  const user = await getUserById(row.user_id)
  const client = await getClient(user.client_id)
  await audit(c, { user, client }, 200, 'auth/verify-email')
  return c.json({ ok: true, user: publicUser(user, client) })
})

v1.post('/auth/forgot-password', async (c) => {
  const body = await c.req.json().catch(() => ({}))
  const clientId = clientIdFrom(c, body)
  const email = String(body.email || '')
    .trim()
    .toLowerCase()
  const user = await getUserByEmail(clientId, email)
  // Always 200 to avoid enumeration
  let resetToken = null
  if (user) {
    resetToken = randomUUID()
    await saveEmailToken(resetToken, user.id, 'reset', Date.now() + 60 * 60 * 1000)
    await audit(c, { user, client: await getClient(clientId) }, 200, 'auth/forgot-password')
  }
  return c.json({ ok: true, resetToken })
})

v1.post('/auth/reset-password', async (c) => {
  const body = await c.req.json().catch(() => ({}))
  const token = String(body.token || '')
  const password = String(body.password || '')
  const pwErr = validatePassword(password)
  if (pwErr) return err(c, 400, 'WEAK_PASSWORD', pwErr)
  const row = await useEmailToken(token, 'reset')
  if (!row) return err(c, 400, 'INVALID_TOKEN', 'Token inválido o expirado')
  if (isFirebaseAuth()) {
    await firebaseUpdatePassword(row.user_id, password)
    await updateUser(row.user_id, { password_hash: '' })
  } else {
    const hash = await bcrypt.hash(password, BCRYPT_COST)
    await updateUser(row.user_id, { password_hash: hash })
  }
  await deleteRefreshForUser(row.user_id)
  const user = await getUserById(row.user_id)
  await audit(c, { user, client: await getClient(user.client_id) }, 200, 'auth/reset-password')
  return c.json({ ok: true })
})

v1.post('/auth/oauth/google', async (c) => {
  // Capstone stub: accepts idToken/email from client after Google Sign-In
  const body = await c.req.json().catch(() => ({}))
  const clientId = clientIdFrom(c, body)
  const client = await getClient(clientId)
  if (!client) return err(c, 400, 'INVALID_CLIENT', 'client_id inválido')
  const email = String(body.email || '')
    .trim()
    .toLowerCase()
  const displayName = String(body.displayName || email.split('@')[0] || 'Atleta')
  if (!email.includes('@')) return err(c, 400, 'INVALID_EMAIL', 'Email inválido')
  let user = await getUserByEmail(clientId, email)
  if (!user) {
    const now = nowIso()
    const id = uid()
    await insertUser({
      id,
      client_id: clientId,
      email,
      password_hash: await bcrypt.hash(randomUUID(), BCRYPT_COST),
      display_name: displayName,
      role: 'user',
      email_verified: true,
      onboarding_complete: false,
      onboarding_step: 0,
      preferences: { units: 'metric' },
      created_at: now,
      updated_at: now,
    })
    user = await getUserById(id)
    await setDoc(clientId, id, '', {
      email,
      displayName,
      onboardingComplete: false,
      onboardingStep: 0,
      createdAt: now,
      updatedAt: now,
      preferences: { units: 'metric' },
    })
  } else if (!user.email_verified) {
    await updateUser(user.id, { email_verified: 1 })
    user = await getUserById(user.id)
  }
  const accessToken = await signAccess(user, client)
  const refreshToken = await issueRefresh(user)
  await audit(c, { user, client }, 200, 'auth/oauth/google')
  return c.json({
    accessToken,
    refreshToken,
    token: accessToken,
    user: publicUser(user, client),
    provider: 'google',
  })
})

v1.post('/auth/oauth/apple', async (c) => {
  // Same stub pattern; production needs Apple Developer
  const body = await c.req.json().catch(() => ({}))
  body.displayName = body.displayName || 'Apple User'
  // reuse google handler logic via internal call pattern
  c.req.json = async () => ({ ...body, email: body.email })
  // Fall through by duplicating minimal path:
  const clientId = clientIdFrom(c, body)
  const client = await getClient(clientId)
  if (!client) return err(c, 400, 'INVALID_CLIENT', 'client_id inválido')
  const email = String(body.email || '')
    .trim()
    .toLowerCase()
  if (!email.includes('@')) {
    return err(c, 501, 'APPLE_OAUTH_PENDING', 'Requiere Apple Developer Account; use email de prueba')
  }
  let user = await getUserByEmail(clientId, email)
  if (!user) {
    const now = nowIso()
    const id = uid()
    await insertUser({
      id,
      client_id: clientId,
      email,
      password_hash: await bcrypt.hash(randomUUID(), BCRYPT_COST),
      display_name: String(body.displayName || 'Apple User'),
      role: 'user',
      email_verified: true,
      onboarding_complete: false,
      onboarding_step: 0,
      preferences: { units: 'metric' },
      created_at: now,
      updated_at: now,
    })
    user = await getUserById(id)
  }
  const accessToken = await signAccess(user, client)
  const refreshToken = await issueRefresh(user)
  await audit(c, { user, client }, 200, 'auth/oauth/apple')
  return c.json({
    accessToken,
    refreshToken,
    token: accessToken,
    user: publicUser(user, client),
    provider: 'apple',
    note: 'Stub Capstone — producción requiere Apple Developer',
  })
})

v1.post('/auth/refresh', async (c) => {
  const body = await c.req.json().catch(() => ({}))
  const meta = await takeRefresh(String(body.refreshToken || ''))
  if (!meta) return err(c, 401, 'INVALID_REFRESH', 'Refresh token inválido o expirado')
  const user = await getUserById(meta.user_id)
  const client = user ? await getClient(user.client_id) : null
  if (!user || !client) return err(c, 401, 'INVALID_REFRESH', 'Usuario no encontrado')
  const accessToken = await signAccess(user, client)
  const refreshToken = await issueRefresh(user)
  return c.json({ accessToken, refreshToken, token: accessToken })
})

v1.post('/auth/logout', async (c) => {
  const body = await c.req.json().catch(() => ({}))
  if (body.refreshToken) await deleteRefresh(String(body.refreshToken))
  return c.json({ ok: true })
})

v1.get('/auth/me', async (c) => {
  const ctx = await authContext(c)
  if (!ctx) return err(c, 401, 'UNAUTHORIZED', 'No autorizado')
  const rate = hitRate(rateKey('user', ctx.user.id), 60, 60 * 1000)
  setRateHeaders(c, rate)
  return c.json({ user: publicUser(ctx.user, ctx.client) })
})

v1.delete('/users/me', async (c) => {
  const ctx = await authContext(c)
  if (!ctx) return err(c, 401, 'UNAUTHORIZED', 'No autorizado')
  if (!requirePerm(ctx, 'delete:account')) {
    await audit(c, ctx, 403, 'users/me')
    return err(c, 403, 'FORBIDDEN', 'Sin permiso delete:account')
  }
  const body = await c.req.json().catch(() => ({}))
  if (String(body.confirmation || '') !== 'ELIMINAR') {
    return err(c, 400, 'CONFIRMATION_REQUIRED', 'Escribe ELIMINAR para confirmar')
  }
  const purgeAfter = new Date(Date.now() + 30 * 24 * 60 * 60 * 1000).toISOString()
  await updateUser(ctx.user.id, { deleted_at: nowIso(), purge_after: purgeAfter })
  await deleteRefreshForUser(ctx.user.id)
  await audit(c, ctx, 200, 'users/me')
  return c.json({ ok: true, purged: false, purgeAfter, note: 'Purga definitiva dentro de 30 días' })
})

v1.get('/medical-screenings', async (c) => {
  const ctx = await authContext(c)
  if (!ctx) return err(c, 401, 'UNAUTHORIZED', 'No autorizado')
  if (!requirePerm(ctx, 'read:medical')) return err(c, 403, 'FORBIDDEN', 'Sin permiso')
  const page = paginate(await listDocs(ctx.user.client_id, ctx.user.id, 'medicalScreenings/'), c.req.query())
  return c.json(page)
})

v1.post('/medical-screenings', async (c) => {
  const ctx = await authContext(c)
  if (!ctx) return err(c, 401, 'UNAUTHORIZED', 'No autorizado')
  if (!requirePerm(ctx, 'write:medical')) {
    await audit(c, ctx, 403, 'medical-screenings')
    return err(c, 403, 'FORBIDDEN', 'Sin permiso write:medical')
  }
  const body = await c.req.json().catch(() => ({}))
  const id = body.id || uid()
  const flags = ['dvt', 'highBloodPressure', 'pregnant', 'recentSurgery', 'clottingDisorders']
  const any = flags.some((k) => Boolean(body[k]))
  const medicalClearance =
    typeof body.medicalClearance === 'boolean' ? body.medicalClearance : !any
  const now = nowIso()
  const payload = {
    ...body,
    id,
    medicalClearance,
    submittedAt: body.submittedAt || now,
    updatedAt: now,
    client_id: ctx.user.client_id,
  }
  await setDoc(ctx.user.client_id, ctx.user.id, `medicalScreenings/${id}`, payload)
  await audit(c, ctx, 201, `medicalScreenings/${id}`)
  return c.json({ item: payload }, 201)
})

v1.get('/goals', async (c) => {
  const ctx = await authContext(c)
  if (!ctx) return err(c, 401, 'UNAUTHORIZED', 'No autorizado')
  if (!requirePerm(ctx, 'read:goals')) return err(c, 403, 'FORBIDDEN', 'Sin permiso')
  return c.json(paginate(await listDocs(ctx.user.client_id, ctx.user.id, 'goals/'), c.req.query()))
})

v1.post('/goals', async (c) => {
  const ctx = await authContext(c)
  if (!ctx) return err(c, 401, 'UNAUTHORIZED', 'No autorizado')
  if (!requirePerm(ctx, 'write:goals')) return err(c, 403, 'FORBIDDEN', 'Sin permiso write:goals')
  const body = await c.req.json().catch(() => ({}))
  const id = body.id || uid()
  const now = nowIso()
  if (body.isActive !== false) {
    for (const g of await listDocs(ctx.user.client_id, ctx.user.id, 'goals/')) {
      if (g.isActive) {
        await setDoc(ctx.user.client_id, ctx.user.id, `goals/${g.id}`, { ...g, isActive: false })
      }
    }
  }
  const item = {
    ...body,
    id,
    isActive: body.isActive !== false,
    client_id: ctx.user.client_id,
    createdAt: body.createdAt || now,
    updatedAt: now,
  }
  await setDoc(ctx.user.client_id, ctx.user.id, `goals/${id}`, item)
  return c.json({ item }, 201)
})

v1.get('/equipment', async (c) => {
  const ctx = await authContext(c)
  if (!ctx) return err(c, 401, 'UNAUTHORIZED', 'No autorizado')
  return c.json({ item: await getDoc(ctx.user.client_id, ctx.user.id, 'equipment/current') })
})

v1.put('/equipment', async (c) => {
  const ctx = await authContext(c)
  if (!ctx) return err(c, 401, 'UNAUTHORIZED', 'No autorizado')
  const body = await c.req.json().catch(() => ({}))
  const item = { ...body, client_id: ctx.user.client_id, updatedAt: nowIso() }
  await setDoc(ctx.user.client_id, ctx.user.id, 'equipment/current', item)
  return c.json({ item })
})

v1.get('/workouts', async (c) => {
  const ctx = await authContext(c)
  if (!ctx) return err(c, 401, 'UNAUTHORIZED', 'No autorizado')
  if (!requirePerm(ctx, 'read:workouts')) return err(c, 403, 'FORBIDDEN', 'Sin permiso')
  return c.json(
    paginate(await listDocs(ctx.user.client_id, ctx.user.id, 'workoutSessions/'), c.req.query()),
  )
})

v1.get('/workouts/:id', async (c) => {
  const ctx = await authContext(c)
  if (!ctx) return err(c, 401, 'UNAUTHORIZED', 'No autorizado')
  const item = await getDoc(ctx.user.client_id, ctx.user.id, `workoutSessions/${c.req.param('id')}`)
  if (!item) return err(c, 404, 'NOT_FOUND', 'Workout no encontrado')
  return c.json({ item: { id: c.req.param('id'), ...item } })
})

v1.post('/workouts', async (c) => {
  const ctx = await authContext(c)
  if (!ctx) return err(c, 401, 'UNAUTHORIZED', 'No autorizado')
  if (!requirePerm(ctx, 'write:workouts')) {
    await audit(c, ctx, 403, 'workouts')
    return err(c, 403, 'FORBIDDEN', 'Sin permiso write:workouts')
  }
  if (!ctx.user.email_verified) {
    await audit(c, ctx, 403, 'workouts')
    return err(
      c,
      403,
      'EMAIL_NOT_VERIFIED',
      'Verifica tu email antes de iniciar entrenamientos',
    )
  }
  const clearance = await latestClearance(ctx.user.client_id, ctx.user.id)
  if (!clearance.ok) {
    await audit(c, ctx, 403, 'workouts')
    return err(
      c,
      403,
      'MEDICAL_CLEARANCE_REQUIRED',
      'Screening médico sin clearance; entrenamiento bloqueado',
    )
  }
  const body = await c.req.json().catch(() => ({}))
  const id = body.id || uid()
  if (await getDoc(ctx.user.client_id, ctx.user.id, `workoutSessions/${id}`)) {
    return err(c, 409, 'DUPLICATE_WORKOUT', 'Workout ya existe (idempotencia)')
  }
  const now = nowIso()
  const item = { ...body, id, client_id: ctx.user.client_id, createdAt: body.createdAt || now, updatedAt: now }
  await setDoc(ctx.user.client_id, ctx.user.id, `workoutSessions/${id}`, item)
  await audit(c, ctx, 201, `workoutSessions/${id}`)
  return c.json({ item }, 201)
})

v1.get('/cuff-checks', async (c) => {
  const ctx = await authContext(c)
  if (!ctx) return err(c, 401, 'UNAUTHORIZED', 'No autorizado')
  return c.json(paginate(await listDocs(ctx.user.client_id, ctx.user.id, 'cuffChecks/'), c.req.query()))
})

v1.post('/cuff-checks', async (c) => {
  const ctx = await authContext(c)
  if (!ctx) return err(c, 401, 'UNAUTHORIZED', 'No autorizado')
  const body = await c.req.json().catch(() => ({}))
  const id = body.id || uid()
  const now = nowIso()
  const item = { ...body, id, client_id: ctx.user.client_id, createdAt: body.createdAt || now, updatedAt: now }
  await setDoc(ctx.user.client_id, ctx.user.id, `cuffChecks/${id}`, item)
  return c.json({ item }, 201)
})

v1.get('/export/history', async (c) => {
  const ctx = await authContext(c)
  if (!ctx) return err(c, 401, 'UNAUTHORIZED', 'No autorizado')
  if (!requireFeature(ctx, 'export_history')) {
    await audit(c, ctx, 402, 'export/history')
    return err(c, 402, 'PLAN_FEATURE_REQUIRED', 'Exportación requiere plan premium', {
      feature: 'export_history',
      plan: ctx.client.plan_tier,
    })
  }
  if (!requirePerm(ctx, 'read:export')) return err(c, 403, 'FORBIDDEN', 'Sin permiso')
  const state = await buildState(ctx.user, ctx.client)
  return c.json({ exportedAt: nowIso(), sessions: state.sessions, cuffChecks: state.cuffChecks })
})

v1.post('/ai/pose-assess', async (c) => {
  const ctx = await authContext(c)
  if (!ctx) return err(c, 401, 'UNAUTHORIZED', 'No autorizado')
  if (!requireFeature(ctx, 'ai_module')) {
    await audit(c, ctx, 402, 'ai/pose-assess')
    return err(c, 402, 'PLAN_FEATURE_REQUIRED', 'Módulo IA requiere plan premium', {
      feature: 'ai_module',
      plan: ctx.client.plan_tier,
    })
  }
  if (!requirePerm(ctx, 'use:ai')) return err(c, 403, 'FORBIDDEN', 'Sin permiso use:ai')
  const body = await c.req.json().catch(() => ({}))
  // Heuristic Capstone model: proximal zone score from client landmarks
  const proximalScore = Number(body.proximalScore ?? body.score ?? 0.5)
  const inZone = proximalScore >= 0.72
  return c.json({
    model: 'hytro-proximal-heuristic-v1',
    proximalScore,
    zoneStatus: inZone ? 'in_safe_zone' : 'too_low',
    confidence: Math.min(0.99, Math.max(0.4, proximalScore)),
    precisionTarget: 0.85,
    note: 'Modelo on-device/heurístico Capstone; métrica en docs de impacto',
  })
})

v1.get('/devices', async (c) => {
  const ctx = await authContext(c)
  if (!ctx) return err(c, 401, 'UNAUTHORIZED', 'No autorizado')
  if (!requireFeature(ctx, 'wearables')) {
    return err(c, 402, 'PLAN_FEATURE_REQUIRED', 'Wearables requieren plan premium', {
      feature: 'wearables',
      plan: ctx.client.plan_tier,
    })
  }
  return c.json({ items: await listDocs(ctx.user.client_id, ctx.user.id, 'devices/') })
})

v1.get('/audit-logs', async (c) => {
  const ctx = await authContext(c)
  if (!ctx) return err(c, 401, 'UNAUTHORIZED', 'No autorizado')
  if (!requirePerm(ctx, 'read:audit-logs')) {
    await audit(c, ctx, 403, 'audit-logs')
    return err(c, 403, 'FORBIDDEN', 'Sin permiso read:audit-logs')
  }
  const limit = Number(c.req.query('limit') ?? 20)
  const offset = Number(c.req.query('offset') ?? 0)
  return c.json(await listAudit(ctx.user.client_id, { limit, offset }))
})

v1.get('/audit-logs/export', async (c) => {
  const ctx = await authContext(c)
  if (!ctx) return err(c, 401, 'UNAUTHORIZED', 'No autorizado')
  if (!requirePerm(ctx, 'export:audit-logs')) {
    await audit(c, ctx, 403, 'audit-logs/export')
    return err(c, 403, 'FORBIDDEN', 'Sin permiso export:audit-logs')
  }
  const data = await listAudit(ctx.user.client_id, { limit: 1000, offset: 0 })
  c.header('Content-Type', 'application/json')
  return c.json({ exportedAt: nowIso(), ...data, immutable: true })
})

v1.post('/sync/push', async (c) => {
  const ctx = await authContext(c)
  if (!ctx) return err(c, 401, 'UNAUTHORIZED', 'No autorizado')
  const body = await c.req.json().catch(() => ({}))
  const items = Array.isArray(body.items) ? body.items : []
  let applied = 0
  for (const item of items) {
    const relativePath = String(item.relativePath || '')
    const payload = item.payload && typeof item.payload === 'object' ? item.payload : {}
    if (item.op === 'delete') continue
    if (relativePath.startsWith('workoutSessions/')) {
      if (await getDoc(ctx.user.client_id, ctx.user.id, relativePath)) continue
      if (!ctx.user.email_verified) {
        return err(c, 403, 'EMAIL_NOT_VERIFIED', 'Email no verificado')
      }
      const clearance = await latestClearance(ctx.user.client_id, ctx.user.id)
      if (!clearance.ok) {
        return err(c, 403, 'MEDICAL_CLEARANCE_REQUIRED', 'Sin clearance')
      }
    }
    if (!relativePath) {
      await updateUser(ctx.user.id, {
        display_name: payload.displayName || ctx.user.display_name,
        onboarding_complete: Boolean(payload.onboardingComplete),
        onboarding_step: Number(payload.onboardingStep ?? ctx.user.onboarding_step),
        preferences_json: JSON.stringify(payload.preferences || { units: 'metric' }),
        protein_timer_ends_at: payload.proteinTimerEndsAt ?? ctx.user.protein_timer_ends_at,
      })
    }
    await setDoc(ctx.user.client_id, ctx.user.id, relativePath, {
      ...payload,
      client_id: ctx.user.client_id,
    })
    applied++
  }
  return c.json({ ok: true, applied })
})

v1.get('/sync/pull', async (c) => {
  const ctx = await authContext(c)
  if (!ctx) return err(c, 401, 'UNAUTHORIZED', 'No autorizado')
  return c.json(await buildState(ctx.user, ctx.client))
})

v1.put('/migrate', async (c) => {
  const ctx = await authContext(c)
  if (!ctx) return err(c, 401, 'UNAUTHORIZED', 'No autorizado')
  const body = await c.req.json().catch(() => ({}))
  const existing = await getDoc(ctx.user.client_id, ctx.user.id, '')
  if (existing?.migratedFromLocalAt) return c.json({ migrated: false, reason: 'already-cloud' })
  const state = body.state
  if (!state || typeof state !== 'object') return err(c, 400, 'STATE_REQUIRED', 'state requerido')
  const now = nowIso()
  const u = state.user || {}
  await setDoc(ctx.user.client_id, ctx.user.id, '', {
    email: u.email || ctx.user.email,
    displayName: u.displayName || ctx.user.display_name,
    onboardingComplete: Boolean(u.onboardingComplete),
    onboardingStep: Number(u.onboardingStep ?? 0),
    createdAt: u.createdAt || ctx.user.created_at,
    updatedAt: now,
    migratedFromLocalAt: now,
    preferences: state.preferences || { units: 'metric' },
    proteinTimerEndsAt: state.proteinTimerEndsAt ?? null,
    client_id: ctx.user.client_id,
  })
  if (state.profile) await setDoc(ctx.user.client_id, ctx.user.id, 'profile/current', state.profile)
  if (state.equipment) await setDoc(ctx.user.client_id, ctx.user.id, 'equipment/current', state.equipment)
  for (const s of state.medicalHistory || []) {
    if (s?.id) await setDoc(ctx.user.client_id, ctx.user.id, `medicalScreenings/${s.id}`, s)
  }
  for (const g of [state.goal, ...(state.goalHistory || [])].filter(Boolean)) {
    if (g?.id) await setDoc(ctx.user.client_id, ctx.user.id, `goals/${g.id}`, g)
  }
  for (const d of state.devices || []) {
    if (d?.provider) await setDoc(ctx.user.client_id, ctx.user.id, `devices/${d.provider}`, d)
  }
  for (const sess of state.sessions || []) {
    if (sess?.id) await setDoc(ctx.user.client_id, ctx.user.id, `workoutSessions/${sess.id}`, sess)
  }
  for (const ck of state.cuffChecks || []) {
    if (ck?.id) await setDoc(ctx.user.client_id, ctx.user.id, `cuffChecks/${ck.id}`, ck)
  }
  for (const n of state.notifications || []) {
    if (n?.id) await setDoc(ctx.user.client_id, ctx.user.id, `notifications/${n.id}`, n)
  }
  await updateUser(ctx.user.id, {
    onboarding_complete: Boolean(u.onboardingComplete),
    onboarding_step: Number(u.onboardingStep ?? 0),
    display_name: u.displayName || ctx.user.display_name,
  })
  return c.json({ migrated: true, reason: 'ok' })
})

app.route('/api/v1', v1)

// Legacy aliases
app.post('/auth/signup', registerHandler)
app.post('/auth/login', loginHandler)
app.get('/auth/me', async (c) => {
  const ctx = await authContext(c)
  if (!ctx) return err(c, 401, 'UNAUTHORIZED', 'No autorizado')
  return c.json({ user: publicUser(ctx.user, ctx.client) })
})
app.get('/v1/state', async (c) => {
  const ctx = await authContext(c)
  if (!ctx) return err(c, 401, 'UNAUTHORIZED', 'No autorizado')
  return c.json(await buildState(ctx.user, ctx.client))
})
app.post('/v1/sync', async (c) => {
  const ctx = await authContext(c)
  if (!ctx) return err(c, 401, 'UNAUTHORIZED', 'No autorizado')
  // delegate by reusing sync push logic via fetch-like call — inline minimal
  const body = await c.req.json().catch(() => ({}))
  const items = Array.isArray(body.items) ? body.items : []
  let applied = 0
  for (const item of items) {
    const relativePath = String(item.relativePath || '')
    const payload = item.payload && typeof item.payload === 'object' ? item.payload : {}
    if (item.op === 'delete') continue
    await setDoc(ctx.user.client_id, ctx.user.id, relativePath, {
      ...payload,
      client_id: ctx.user.client_id,
    })
    applied++
  }
  return c.json({ ok: true, applied })
})
app.put('/v1/migrate', async (c) => {
  // thin alias
  const ctx = await authContext(c)
  if (!ctx) return err(c, 401, 'UNAUTHORIZED', 'No autorizado')
  return err(c, 307, 'USE_API_V1', 'Usa PUT /api/v1/migrate')
})

await initPersistence()
await purgeDueUsers()
const info = persistenceInfo()
console.log(
  `[hytro-api] alloxentric-${persistenceMode()} auth=${isFirebaseAuth() ? 'firebase' : 'local'} listening on 0.0.0.0:${PORT} db=${info.detail || dbPath()}`,
)
serve({ fetch: app.fetch, hostname: '0.0.0.0', port: PORT })
