/** Feature gating by commercial plan (basic | premium) */

/** @type {Record<string, string[]>} */
export const PLAN_FEATURES = {
  basic: ['core_training', 'cuff_check', 'progress'],
  premium: [
    'core_training',
    'cuff_check',
    'progress',
    'wearables',
    'export_history',
    'ai_module',
  ],
}

export function featuresForPlan(planTier) {
  return PLAN_FEATURES[planTier] || PLAN_FEATURES.basic
}

export function hasFeature(planTier, feature) {
  return featuresForPlan(planTier).includes(feature)
}

/** Map API routes / actions → required feature flag */
export const FEATURE_GATES = {
  wearables: 'wearables',
  export: 'export_history',
  ai: 'ai_module',
}
