/**
 * Firebase Auth provider (Admin SDK + Auth REST for idToken).
 * Activated when HYTRO_AUTH_PROVIDER=firebase.
 */
import { getApps, initializeApp } from 'firebase-admin/app'
import { getAuth } from 'firebase-admin/auth'

const PROJECT_ID =
  process.env.PROJECT_ID ||
  process.env.GOOGLE_CLOUD_PROJECT ||
  process.env.GCLOUD_PROJECT ||
  process.env.FIREBASE_PROJECT_ID ||
  'demo-hytro'

const API_KEY = process.env.FIREBASE_WEB_API_KEY || process.env.VITE_FIREBASE_API_KEY || 'fake-api-key'

function ensureApp() {
  if (getApps().length) return
  initializeApp({ projectId: PROJECT_ID })
}

export function authProvider() {
  return (process.env.HYTRO_AUTH_PROVIDER || 'local').toLowerCase()
}

export function isFirebaseAuth() {
  return authProvider() === 'firebase'
}

function authBase() {
  if (process.env.FIREBASE_AUTH_EMULATOR_HOST) {
    const host = process.env.FIREBASE_AUTH_EMULATOR_HOST
    const prefix = host.startsWith('http') ? host : `http://${host}`
    return `${prefix}/identitytoolkit.googleapis.com/v1`
  }
  return 'https://identitytoolkit.googleapis.com/v1'
}

export function getAdminAuth() {
  ensureApp()
  return getAuth()
}

export async function firebaseCreateUser({ email, password, displayName, clientId, role, tier }) {
  const auth = getAdminAuth()
  const user = await auth.createUser({
    email,
    password,
    displayName,
    emailVerified: false,
  })
  await auth.setCustomUserClaims(user.uid, {
    client_id: clientId,
    role,
    tier,
  })
  return user
}

export async function firebaseSetClaims(uid, { clientId, role, tier }) {
  await getAdminAuth().setCustomUserClaims(uid, {
    client_id: clientId,
    role,
    tier,
  })
}

export async function firebaseDeleteUser(uid) {
  try {
    await getAdminAuth().deleteUser(uid)
  } catch {
    /* ignore */
  }
}

export async function firebaseSignIn(email, password) {
  const url = `${authBase()}/accounts:signInWithPassword?key=${encodeURIComponent(API_KEY)}`
  const res = await fetch(url, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ email, password, returnSecureToken: true }),
  })
  const body = await res.json().catch(() => ({}))
  if (!res.ok) {
    const code = body?.error?.message || 'AUTH_FAILED'
    const err = new Error(code)
    err.code = code
    throw err
  }
  return {
    idToken: body.idToken,
    refreshToken: body.refreshToken,
    localId: body.localId,
    expiresIn: body.expiresIn,
  }
}

export async function firebaseSignUp(email, password, displayName) {
  const url = `${authBase()}/accounts:signUp?key=${encodeURIComponent(API_KEY)}`
  const res = await fetch(url, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ email, password, displayName, returnSecureToken: true }),
  })
  const body = await res.json().catch(() => ({}))
  if (!res.ok) {
    const code = body?.error?.message || 'SIGNUP_FAILED'
    const err = new Error(code)
    err.code = code
    throw err
  }
  return {
    idToken: body.idToken,
    refreshToken: body.refreshToken,
    localId: body.localId,
  }
}

export async function verifyFirebaseToken(idToken) {
  return getAdminAuth().verifyIdToken(idToken, true)
}

export async function firebaseVerifyEmail(uid) {
  await getAdminAuth().updateUser(uid, { emailVerified: true })
}

export async function firebaseUpdatePassword(uid, password) {
  await getAdminAuth().updateUser(uid, { password })
}
