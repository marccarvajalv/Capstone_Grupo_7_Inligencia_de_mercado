/**
 * Firestore persistence for Cloud Run / Emulator Suite.
 * Same surface as db.js so index.js can switch via store.js.
 */
import { randomUUID } from 'node:crypto'
import { getApps, initializeApp } from 'firebase-admin/app'
import { getFirestore } from 'firebase-admin/firestore'

const PROJECT_ID =
  process.env.PROJECT_ID ||
  process.env.GOOGLE_CLOUD_PROJECT ||
  process.env.GCLOUD_PROJECT ||
  process.env.FIREBASE_PROJECT_ID ||
  'demo-hytro'

const rateBuckets = new Map()
const loginAttempts = new Map()

/** @type {FirebaseFirestore.Firestore | null} */
let db = null
let seeded = false

function ensureApp() {
  if (getApps().length) return
  // Emulator: projectId only. Cloud Run: ADC is picked up automatically by Admin SDK.
  initializeApp({ projectId: PROJECT_ID })
}

export function getDb() {
  if (db) return db
  ensureApp()
  db = getFirestore()
  return db
}

async function seed() {
  if (seeded) return
  const database = getDb()
  const demo = await database.collection('clients').doc('client_demo').get()
  if (!demo.exists) {
    const now = new Date().toISOString()
    await database.collection('clients').doc('client_demo').set({
      id: 'client_demo',
      name: 'Hytro Capstone Demo',
      plan_tier: 'premium',
      created_at: now,
    })
    await database.collection('clients').doc('client_basic').set({
      id: 'client_basic',
      name: 'Hytro Basic Tenant',
      plan_tier: 'basic',
      created_at: now,
    })
  }
  seeded = true
}

/** Sync-friendly bootstrap (awaited from store.initPersistence). */
export async function initPersistence() {
  getDb()
  await seed()
}

export function uid() {
  return randomUUID()
}

export function nowIso() {
  return new Date().toISOString()
}

function pathToId(path) {
  if (!path) return '_root'
  return path.replace(/\//g, '__')
}

function rowUser(id, data) {
  if (!data) return null
  return {
    id,
    client_id: data.client_id,
    email: data.email,
    password_hash: data.password_hash || '',
    display_name: data.display_name,
    role: data.role || 'user',
    email_verified: data.email_verified ? 1 : 0,
    onboarding_complete: data.onboarding_complete ? 1 : 0,
    onboarding_step: data.onboarding_step || 0,
    preferences_json:
      typeof data.preferences_json === 'string'
        ? data.preferences_json
        : JSON.stringify(data.preferences || { units: 'metric' }),
    protein_timer_ends_at: data.protein_timer_ends_at ?? null,
    purge_after: data.purge_after ?? null,
    deleted_at: data.deleted_at ?? null,
    created_at: data.created_at,
    updated_at: data.updated_at,
    firebase_uid: data.firebase_uid || id,
  }
}

export async function getClient(clientId) {
  await seed()
  const snap = await getDb().collection('clients').doc(clientId).get()
  if (!snap.exists) return null
  return { id: snap.id, ...snap.data() }
}

export async function getUserByEmail(clientId, email) {
  await seed()
  const q = await getDb()
    .collection('users')
    .where('client_id', '==', clientId)
    .where('email', '==', email.toLowerCase())
    .limit(5)
    .get()
  for (const doc of q.docs) {
    const u = rowUser(doc.id, doc.data())
    if (u && !u.deleted_at) return u
  }
  return null
}

export async function getUserById(id) {
  await seed()
  const snap = await getDb().collection('users').doc(id).get()
  if (!snap.exists) return null
  const u = rowUser(snap.id, snap.data())
  return u?.deleted_at ? null : u
}

export async function insertUser(user) {
  await seed()
  const payload = {
    client_id: user.client_id,
    email: user.email,
    password_hash: user.password_hash || '',
    display_name: user.display_name,
    role: user.role,
    email_verified: Boolean(user.email_verified),
    onboarding_complete: Boolean(user.onboarding_complete),
    onboarding_step: user.onboarding_step || 0,
    preferences_json: JSON.stringify(user.preferences || { units: 'metric' }),
    protein_timer_ends_at: null,
    purge_after: null,
    deleted_at: null,
    created_at: user.created_at,
    updated_at: user.updated_at,
    firebase_uid: user.firebase_uid || user.id,
  }
  await getDb().collection('users').doc(user.id).set(payload)
}

export async function updateUser(id, patch) {
  const u = await getUserById(id)
  if (!u) return null
  const next = {
    display_name: patch.display_name ?? u.display_name,
    role: patch.role ?? u.role,
    email_verified: patch.email_verified !== undefined ? Boolean(patch.email_verified) : Boolean(u.email_verified),
    onboarding_complete:
      patch.onboarding_complete !== undefined
        ? Boolean(patch.onboarding_complete)
        : Boolean(u.onboarding_complete),
    onboarding_step: patch.onboarding_step ?? u.onboarding_step,
    preferences_json:
      patch.preferences_json !== undefined
        ? typeof patch.preferences_json === 'string'
          ? patch.preferences_json
          : JSON.stringify(patch.preferences || { units: 'metric' })
        : u.preferences_json,
    protein_timer_ends_at:
      patch.protein_timer_ends_at !== undefined ? patch.protein_timer_ends_at : u.protein_timer_ends_at,
    password_hash: patch.password_hash ?? u.password_hash,
    purge_after: patch.purge_after !== undefined ? patch.purge_after : u.purge_after,
    deleted_at: patch.deleted_at !== undefined ? patch.deleted_at : u.deleted_at,
    updated_at: nowIso(),
  }
  await getDb().collection('users').doc(id).update(next)
  return getUserById(id)
}

export async function setDoc(clientId, userId, path, payload) {
  const id = pathToId(path)
  await getDb()
    .collection('users')
    .doc(userId)
    .collection('docs')
    .doc(id)
    .set({
      client_id: clientId,
      user_id: userId,
      path,
      payload,
      updated_at: nowIso(),
    })
}

export async function getDoc(clientId, userId, path) {
  const snap = await getDb()
    .collection('users')
    .doc(userId)
    .collection('docs')
    .doc(pathToId(path))
    .get()
  if (!snap.exists) return null
  const data = snap.data()
  if (data.client_id && data.client_id !== clientId) return null
  return data.payload ?? null
}

export async function listDocs(clientId, userId, prefix) {
  const snap = await getDb().collection('users').doc(userId).collection('docs').get()
  const out = []
  for (const doc of snap.docs) {
    const data = doc.data()
    if (data.client_id && data.client_id !== clientId) continue
    const path = data.path || ''
    if (!path.startsWith(prefix)) continue
    const payload = data.payload || {}
    const id = path.includes('/') ? path.split('/').pop() : path
    out.push({ id, ...payload })
  }
  return out
}

export async function deleteDocsForUser(clientId, userId) {
  const snap = await getDb().collection('users').doc(userId).collection('docs').get()
  const batch = getDb().batch()
  let n = 0
  for (const doc of snap.docs) {
    const data = doc.data()
    if (data.client_id && data.client_id !== clientId) continue
    batch.delete(doc.ref)
    n += 1
    if (n >= 400) {
      await batch.commit()
      n = 0
    }
  }
  if (n) await batch.commit()
}

export async function saveRefresh(token, userId, clientId, expiresAt) {
  await getDb().collection('refresh_tokens').doc(token).set({
    token,
    user_id: userId,
    client_id: clientId,
    expires_at: expiresAt,
  })
}

export async function takeRefresh(token) {
  const ref = getDb().collection('refresh_tokens').doc(token)
  const snap = await ref.get()
  if (!snap.exists) return null
  const row = snap.data()
  await ref.delete()
  if (row.expires_at < Date.now()) return null
  return row
}

export async function deleteRefresh(token) {
  await getDb().collection('refresh_tokens').doc(token).delete()
}

export async function deleteRefreshForUser(userId) {
  const snap = await getDb().collection('refresh_tokens').where('user_id', '==', userId).get()
  const batch = getDb().batch()
  snap.docs.forEach((d) => batch.delete(d.ref))
  if (!snap.empty) await batch.commit()
}

export async function saveEmailToken(token, userId, kind, expiresAt) {
  await getDb().collection('email_tokens').doc(token).set({
    token,
    user_id: userId,
    kind,
    expires_at: expiresAt,
    used_at: null,
  })
}

export async function useEmailToken(token, kind) {
  const ref = getDb().collection('email_tokens').doc(token)
  const snap = await ref.get()
  if (!snap.exists) return null
  const row = snap.data()
  if (row.kind !== kind || row.used_at || row.expires_at < Date.now()) return null
  await ref.update({ used_at: nowIso() })
  return row
}

export async function insertAudit(entry) {
  // Cloud Logging (structured) — retention/immutability managed in GCP, not in app collections.
  console.log(
    JSON.stringify({
      severity: entry.success ? 'INFO' : 'WARNING',
      message: 'hytro.audit',
      ...entry,
    }),
  )
  await getDb().collection('audit_logs').doc(entry.id).set(entry)
}

export async function listAudit(clientId, { limit = 20, offset = 0 } = {}) {
  const snap = await getDb().collection('audit_logs').where('client_id', '==', clientId).limit(200).get()
  const all = snap.docs
    .map((d) => ({ id: d.id, ...d.data() }))
    .sort((a, b) => String(b.created_at || '').localeCompare(String(a.created_at || '')))
  const items = all.slice(offset, offset + limit)
  return { items, total: all.length, limit, offset }
}

export async function purgeDueUsers() {
  const now = nowIso()
  const snap = await getDb().collection('users').where('deleted_at', '!=', null).limit(50).get()
  let n = 0
  for (const doc of snap.docs) {
    const data = doc.data()
    if (!data.purge_after || data.purge_after > now) continue
    await deleteDocsForUser(data.client_id, doc.id)
    await deleteRefreshForUser(doc.id)
    await doc.ref.delete()
    n += 1
  }
  return n
}

export function dbPath() {
  return `firestore://${PROJECT_ID}`
}

export function persistenceInfo() {
  return {
    mode: 'firestore',
    detail: dbPath(),
    emulator: Boolean(process.env.FIRESTORE_EMULATOR_HOST),
    projectId: PROJECT_ID,
  }
}

export function hitRate(key, limit, windowMs) {
  const now = Date.now()
  const row = rateBuckets.get(key)
  if (!row || now - row.window_start >= windowMs) {
    rateBuckets.set(key, { window_start: now, count: 1 })
    return { ok: true, limit, remaining: limit - 1, reset: Math.ceil((now + windowMs) / 1000) }
  }
  row.count += 1
  const reset = Math.ceil((row.window_start + windowMs) / 1000)
  if (row.count > limit) return { ok: false, limit, remaining: 0, reset }
  return { ok: true, limit, remaining: Math.max(0, limit - row.count), reset }
}

export function loadLoginAttempt(email) {
  const key = email.toLowerCase()
  return loginAttempts.get(key) || { key, fails_json: '[]', locked_until: 0 }
}

export function saveLoginAttempt(key, failsJson, lockedUntil) {
  loginAttempts.set(key, { key, fails_json: failsJson, locked_until: lockedUntil })
}
