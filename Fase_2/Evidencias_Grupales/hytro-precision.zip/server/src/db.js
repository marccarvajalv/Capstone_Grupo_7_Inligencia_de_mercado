import { DatabaseSync } from 'node:sqlite'
import { mkdirSync } from 'node:fs'
import { dirname, join } from 'node:path'
import { fileURLToPath } from 'node:url'
import { randomUUID } from 'node:crypto'

const __dirname = dirname(fileURLToPath(import.meta.url))
const DATA_DIR = process.env.HYTRO_DATA_DIR || join(__dirname, '..', 'data')
const DB_PATH = process.env.HYTRO_DB_PATH || join(DATA_DIR, 'hytro.sqlite')

mkdirSync(DATA_DIR, { recursive: true })

/** @type {DatabaseSync | null} */
let db = null

export function getDb() {
  if (db) return db
  db = new DatabaseSync(DB_PATH)
  db.exec('PRAGMA journal_mode = WAL;')
  db.exec('PRAGMA foreign_keys = ON;')
  migrate(db)
  seed(db)
  return db
}

function migrate(database) {
  database.exec(`
    CREATE TABLE IF NOT EXISTS clients (
      id TEXT PRIMARY KEY,
      name TEXT NOT NULL,
      plan_tier TEXT NOT NULL DEFAULT 'basic',
      created_at TEXT NOT NULL
    );

    CREATE TABLE IF NOT EXISTS users (
      id TEXT PRIMARY KEY,
      client_id TEXT NOT NULL REFERENCES clients(id),
      email TEXT NOT NULL,
      password_hash TEXT NOT NULL,
      display_name TEXT NOT NULL,
      role TEXT NOT NULL DEFAULT 'user',
      email_verified INTEGER NOT NULL DEFAULT 0,
      onboarding_complete INTEGER NOT NULL DEFAULT 0,
      onboarding_step INTEGER NOT NULL DEFAULT 0,
      preferences_json TEXT NOT NULL DEFAULT '{}',
      protein_timer_ends_at TEXT,
      purge_after TEXT,
      deleted_at TEXT,
      created_at TEXT NOT NULL,
      updated_at TEXT NOT NULL,
      UNIQUE(client_id, email)
    );

    CREATE TABLE IF NOT EXISTS refresh_tokens (
      token TEXT PRIMARY KEY,
      user_id TEXT NOT NULL REFERENCES users(id),
      client_id TEXT NOT NULL,
      expires_at INTEGER NOT NULL
    );

    CREATE TABLE IF NOT EXISTS email_tokens (
      token TEXT PRIMARY KEY,
      user_id TEXT NOT NULL REFERENCES users(id),
      kind TEXT NOT NULL,
      expires_at INTEGER NOT NULL,
      used_at TEXT
    );

    CREATE TABLE IF NOT EXISTS docs (
      client_id TEXT NOT NULL,
      user_id TEXT NOT NULL,
      path TEXT NOT NULL,
      payload_json TEXT NOT NULL,
      updated_at TEXT NOT NULL,
      PRIMARY KEY (client_id, user_id, path)
    );

    CREATE TABLE IF NOT EXISTS audit_logs (
      id TEXT PRIMARY KEY,
      client_id TEXT NOT NULL,
      user_id TEXT,
      role TEXT,
      method TEXT NOT NULL,
      path TEXT NOT NULL,
      resource TEXT,
      ip TEXT,
      user_agent TEXT,
      status INTEGER NOT NULL,
      success INTEGER NOT NULL,
      created_at TEXT NOT NULL
    );

    CREATE TABLE IF NOT EXISTS rate_buckets (
      key TEXT PRIMARY KEY,
      window_start INTEGER NOT NULL,
      count INTEGER NOT NULL
    );

    CREATE TABLE IF NOT EXISTS login_attempts (
      key TEXT PRIMARY KEY,
      fails_json TEXT NOT NULL,
      locked_until INTEGER NOT NULL DEFAULT 0
    );

    CREATE INDEX IF NOT EXISTS idx_docs_user ON docs(client_id, user_id);
    CREATE INDEX IF NOT EXISTS idx_audit_client ON audit_logs(client_id, created_at);
    CREATE INDEX IF NOT EXISTS idx_users_email ON users(email);
  `)
}

function seed(database) {
  const row = database.prepare('SELECT id FROM clients WHERE id = ?').get('client_demo')
  if (row) return
  const now = new Date().toISOString()
  database
    .prepare('INSERT INTO clients (id, name, plan_tier, created_at) VALUES (?, ?, ?, ?)')
    .run('client_demo', 'Hytro Capstone Demo', 'premium', now)
  database
    .prepare('INSERT INTO clients (id, name, plan_tier, created_at) VALUES (?, ?, ?, ?)')
    .run('client_basic', 'Hytro Basic Tenant', 'basic', now)
}

export function uid() {
  return randomUUID()
}

export function nowIso() {
  return new Date().toISOString()
}

export function getClient(clientId) {
  return getDb().prepare('SELECT * FROM clients WHERE id = ?').get(clientId) || null
}

export function getUserByEmail(clientId, email) {
  return getDb()
    .prepare('SELECT * FROM users WHERE client_id = ? AND email = ? AND deleted_at IS NULL')
    .get(clientId, email.toLowerCase())
}

export function getUserById(id) {
  return getDb().prepare('SELECT * FROM users WHERE id = ? AND deleted_at IS NULL').get(id)
}

export function insertUser(user) {
  getDb()
    .prepare(
      `INSERT INTO users (
        id, client_id, email, password_hash, display_name, role, email_verified,
        onboarding_complete, onboarding_step, preferences_json, created_at, updated_at
      ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
    )
    .run(
      user.id,
      user.client_id,
      user.email,
      user.password_hash,
      user.display_name,
      user.role,
      user.email_verified ? 1 : 0,
      user.onboarding_complete ? 1 : 0,
      user.onboarding_step || 0,
      JSON.stringify(user.preferences || { units: 'metric' }),
      user.created_at,
      user.updated_at,
    )
}

export function updateUser(id, patch) {
  const u = getUserById(id)
  if (!u) return null
  const next = { ...u, ...patch, updated_at: nowIso() }
  getDb()
    .prepare(
      `UPDATE users SET
        display_name = ?, role = ?, email_verified = ?, onboarding_complete = ?,
        onboarding_step = ?, preferences_json = ?, protein_timer_ends_at = ?,
        password_hash = ?, purge_after = ?, deleted_at = ?, updated_at = ?
      WHERE id = ?`,
    )
    .run(
      next.display_name,
      next.role,
      next.email_verified ? 1 : 0,
      next.onboarding_complete ? 1 : 0,
      next.onboarding_step || 0,
      typeof next.preferences_json === 'string'
        ? next.preferences_json
        : JSON.stringify(next.preferences || { units: 'metric' }),
      next.protein_timer_ends_at ?? null,
      next.password_hash,
      next.purge_after ?? null,
      next.deleted_at ?? null,
      next.updated_at,
      id,
    )
  return getUserById(id)
}

export function setDoc(clientId, userId, path, payload) {
  const payload_json = JSON.stringify(payload)
  const updated_at = nowIso()
  getDb()
    .prepare(
      `INSERT INTO docs (client_id, user_id, path, payload_json, updated_at)
       VALUES (?, ?, ?, ?, ?)
       ON CONFLICT(client_id, user_id, path) DO UPDATE SET
         payload_json = excluded.payload_json,
         updated_at = excluded.updated_at`,
    )
    .run(clientId, userId, path, payload_json, updated_at)
}

export function getDoc(clientId, userId, path) {
  const row = getDb()
    .prepare('SELECT payload_json FROM docs WHERE client_id = ? AND user_id = ? AND path = ?')
    .get(clientId, userId, path)
  return row ? JSON.parse(row.payload_json) : null
}

export function listDocs(clientId, userId, prefix) {
  const rows = getDb()
    .prepare(
      `SELECT path, payload_json FROM docs
       WHERE client_id = ? AND user_id = ? AND path LIKE ?`,
    )
    .all(clientId, userId, `${prefix}%`)
  return rows.map((r) => {
    const payload = JSON.parse(r.payload_json)
    const id = r.path.includes('/') ? r.path.split('/').pop() : r.path
    return { id, ...payload }
  })
}

export function deleteDocsForUser(clientId, userId) {
  getDb().prepare('DELETE FROM docs WHERE client_id = ? AND user_id = ?').run(clientId, userId)
}

export function saveRefresh(token, userId, clientId, expiresAt) {
  getDb()
    .prepare(
      'INSERT INTO refresh_tokens (token, user_id, client_id, expires_at) VALUES (?, ?, ?, ?)',
    )
    .run(token, userId, clientId, expiresAt)
}

export function takeRefresh(token) {
  const row = getDb().prepare('SELECT * FROM refresh_tokens WHERE token = ?').get(token)
  if (!row) return null
  getDb().prepare('DELETE FROM refresh_tokens WHERE token = ?').run(token)
  if (row.expires_at < Date.now()) return null
  return row
}

export function deleteRefresh(token) {
  getDb().prepare('DELETE FROM refresh_tokens WHERE token = ?').run(token)
}

export function deleteRefreshForUser(userId) {
  getDb().prepare('DELETE FROM refresh_tokens WHERE user_id = ?').run(userId)
}

export function saveEmailToken(token, userId, kind, expiresAt) {
  getDb()
    .prepare(
      'INSERT INTO email_tokens (token, user_id, kind, expires_at) VALUES (?, ?, ?, ?)',
    )
    .run(token, userId, kind, expiresAt)
}

export function useEmailToken(token, kind) {
  const row = getDb()
    .prepare('SELECT * FROM email_tokens WHERE token = ? AND kind = ?')
    .get(token, kind)
  if (!row || row.used_at || row.expires_at < Date.now()) return null
  getDb()
    .prepare('UPDATE email_tokens SET used_at = ? WHERE token = ?')
    .run(nowIso(), token)
  return row
}

export function insertAudit(entry) {
  getDb()
    .prepare(
      `INSERT INTO audit_logs (
        id, client_id, user_id, role, method, path, resource, ip, user_agent, status, success, created_at
      ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
    )
    .run(
      entry.id,
      entry.client_id,
      entry.user_id ?? null,
      entry.role ?? null,
      entry.method,
      entry.path,
      entry.resource ?? null,
      entry.ip ?? null,
      entry.user_agent ?? null,
      entry.status,
      entry.success ? 1 : 0,
      entry.created_at,
    )
}

export function listAudit(clientId, { limit = 20, offset = 0 } = {}) {
  const total = getDb()
    .prepare('SELECT COUNT(*) AS n FROM audit_logs WHERE client_id = ?')
    .get(clientId).n
  const items = getDb()
    .prepare(
      `SELECT * FROM audit_logs WHERE client_id = ?
       ORDER BY created_at DESC LIMIT ? OFFSET ?`,
    )
    .all(clientId, limit, offset)
  return { items, total, limit, offset }
}

export function purgeDueUsers() {
  const now = nowIso()
  const due = getDb()
    .prepare(
      `SELECT id, client_id FROM users
       WHERE deleted_at IS NOT NULL AND purge_after IS NOT NULL AND purge_after <= ?`,
    )
    .all(now)
  for (const u of due) {
    deleteDocsForUser(u.client_id, u.id)
    deleteRefreshForUser(u.id)
    getDb().prepare('DELETE FROM email_tokens WHERE user_id = ?').run(u.id)
    getDb().prepare('DELETE FROM users WHERE id = ?').run(u.id)
  }
  return due.length
}

export function dbPath() {
  return DB_PATH
}

export function persistenceInfo() {
  return { mode: 'sqlite', detail: DB_PATH }
}

/** Sliding window rate limiter backed by SQLite. */
export function hitRate(key, limit, windowMs) {
  const database = getDb()
  const now = Date.now()
  const row = database.prepare('SELECT * FROM rate_buckets WHERE key = ?').get(key)
  if (!row || now - row.window_start >= windowMs) {
    database
      .prepare(
        `INSERT INTO rate_buckets (key, window_start, count) VALUES (?, ?, 1)
         ON CONFLICT(key) DO UPDATE SET window_start = excluded.window_start, count = 1`,
      )
      .run(key, now)
    return { ok: true, limit, remaining: limit - 1, reset: Math.ceil((now + windowMs) / 1000) }
  }
  const count = row.count + 1
  database.prepare('UPDATE rate_buckets SET count = ? WHERE key = ?').run(count, key)
  const reset = Math.ceil((row.window_start + windowMs) / 1000)
  if (count > limit) return { ok: false, limit, remaining: 0, reset }
  return { ok: true, limit, remaining: Math.max(0, limit - count), reset }
}

export function loadLoginAttempt(email) {
  const key = email.toLowerCase()
  const row = getDb().prepare('SELECT * FROM login_attempts WHERE key = ?').get(key)
  if (!row) return { key, fails_json: '[]', locked_until: 0 }
  return row
}

export function saveLoginAttempt(key, failsJson, lockedUntil) {
  getDb()
    .prepare(
      `INSERT INTO login_attempts (key, fails_json, locked_until) VALUES (?, ?, ?)
       ON CONFLICT(key) DO UPDATE SET fails_json = excluded.fails_json, locked_until = excluded.locked_until`,
    )
    .run(key, failsJson, lockedUntil)
}
