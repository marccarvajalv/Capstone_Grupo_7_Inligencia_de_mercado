/**
 * Persistence switch:
 *   HYTRO_PERSISTENCE=sqlite     (default — local/CI)
 *   HYTRO_PERSISTENCE=firestore  (Cloud Run / Emulator Suite)
 *
 * All exports are async-safe (sqlite wrapped) so handlers can await uniformly.
 */
import * as sqlite from './db.js'
import * as firestore from './firestoreDb.js'

const MODE = (process.env.HYTRO_PERSISTENCE || 'sqlite').toLowerCase()
const impl = MODE === 'firestore' ? firestore : sqlite

export function persistenceMode() {
  return MODE === 'firestore' ? 'firestore' : 'sqlite'
}

export async function initPersistence() {
  if (MODE === 'firestore') {
    await firestore.initPersistence()
    return
  }
  sqlite.getDb()
  sqlite.purgeDueUsers()
}

async function call(name, ...args) {
  const fn = impl[name]
  const result = fn(...args)
  return result && typeof result.then === 'function' ? result : result
}

export const uid = (...a) => impl.uid(...a)
export const nowIso = (...a) => impl.nowIso(...a)
export const dbPath = (...a) => impl.dbPath(...a)
export const persistenceInfo = (...a) => impl.persistenceInfo(...a)
export const hitRate = (...a) => impl.hitRate(...a)
export const loadLoginAttempt = (...a) => impl.loadLoginAttempt(...a)
export const saveLoginAttempt = (...a) => impl.saveLoginAttempt(...a)

export const getDb = (...a) => call('getDb', ...a)
export const getClient = (...a) => call('getClient', ...a)
export const getUserByEmail = (...a) => call('getUserByEmail', ...a)
export const getUserById = (...a) => call('getUserById', ...a)
export const insertUser = (...a) => call('insertUser', ...a)
export const updateUser = (...a) => call('updateUser', ...a)
export const setDoc = (...a) => call('setDoc', ...a)
export const getDoc = (...a) => call('getDoc', ...a)
export const listDocs = (...a) => call('listDocs', ...a)
export const deleteDocsForUser = (...a) => call('deleteDocsForUser', ...a)
export const saveRefresh = (...a) => call('saveRefresh', ...a)
export const takeRefresh = (...a) => call('takeRefresh', ...a)
export const deleteRefresh = (...a) => call('deleteRefresh', ...a)
export const deleteRefreshForUser = (...a) => call('deleteRefreshForUser', ...a)
export const saveEmailToken = (...a) => call('saveEmailToken', ...a)
export const useEmailToken = (...a) => call('useEmailToken', ...a)
export const insertAudit = (...a) => call('insertAudit', ...a)
export const listAudit = (...a) => call('listAudit', ...a)
export const purgeDueUsers = (...a) => call('purgeDueUsers', ...a)
