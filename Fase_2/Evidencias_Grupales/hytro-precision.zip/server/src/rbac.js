/** RBAC Alloxentric — roles within a client_id */

export const ROLES = ['admin', 'auditor', 'trainer', 'user']

/** @type {Record<string, string[]>} */
export const ROLE_PERMISSIONS = {
  admin: [
    'read:users',
    'write:users',
    'read:goals',
    'write:goals',
    'read:workouts',
    'write:workouts',
    'read:medical',
    'write:medical',
    'read:equipment',
    'write:equipment',
    'read:cuff',
    'write:cuff',
    'read:audit-logs',
    'export:audit-logs',
    'read:export',
    'use:wearables',
    'use:ai',
    'delete:account',
  ],
  auditor: [
    'read:users',
    'read:goals',
    'read:workouts',
    'read:medical',
    'read:equipment',
    'read:cuff',
    'read:audit-logs',
    'export:audit-logs',
    'read:export',
  ],
  trainer: [
    'read:users',
    'read:goals',
    'write:goals',
    'read:workouts',
    'write:workouts',
    'read:medical',
    'read:equipment',
    'write:equipment',
    'read:cuff',
    'write:cuff',
    'use:wearables',
    'use:ai',
  ],
  user: [
    'read:goals',
    'write:goals',
    'read:workouts',
    'write:workouts',
    'read:medical',
    'write:medical',
    'read:equipment',
    'write:equipment',
    'read:cuff',
    'write:cuff',
    'use:wearables',
    'use:ai',
    'read:export',
    'delete:account',
  ],
}

export function permissionsFor(role) {
  return ROLE_PERMISSIONS[role] || ROLE_PERMISSIONS.user
}

export function hasPermission(role, permission) {
  const perms = permissionsFor(role)
  return perms.includes(permission) || perms.includes('*')
}
